// ============================================================
// logic.js
// All application state + business logic. NO DOM access here —
// this file should run unchanged in a Node test runner.
// Ported 1:1 from the old inline <script> in sub.html; math and
// control flow are unchanged, only reorganized and exported.
// ============================================================

const API_URL = "https://api.psychonautwiki.org";

const state = {
  currentSubstance: null,
  currentCommonDose: null,
  units: "",
  doseSequence: 0,
  addedDoses: [],
  baseDurations: { onset: 0, comeup: 0, peak: 0, offset: 0 },
  currentRoa: null,
  substanceColors: {},
  customColors: {}, // lowercased name -> color the account picked on Profile
};

/**
 * Read-only snapshot of state for ui.js to render from.
 * ui.js should never mutate the returned object directly —
 * all mutation goes through the functions below.
 */
export function getState() {
  return {
    currentSubstance: state.currentSubstance,
    currentCommonDose: state.currentCommonDose,
    units: state.units,
    addedDoses: state.addedDoses,
    baseDurations: state.baseDurations,
  };
}

// ------------------------------------------------------------
// GraphQL (unchanged from the old fetchGraphQL/getData/searchSuggestions)
// ------------------------------------------------------------

function fetchGraphQL(query, variables = {}) {
  return fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables }),
  }).then((response) => {
    if (!response.ok) throw new Error("Substance service unavailable");
    return response.json();
  });
}

/** Typeahead suggestions. Old name: searchSuggestions() (network part only). */
export async function searchSuggestions(name) {
  const query = `query Suggestions($name: String!) {
        substances(query: $name) { name }
    }`;
  const result = await fetchGraphQL(query, { name });
  return result?.data?.substances || [];
}

/**
 * Full substance lookup. Old name: getData() + the state-assignment
 * half of search(). Updates internal state and returns the same
 * shape the UI needs to render the substance panel.
 */
export async function fetchSubstanceData(name) {
  const query = `query Substance($name: String!) {
        substances(query: $name) {
            name
            images { thumb }
            summary
            addictionPotential
            uncertainInteractions { name }
            unsafeInteractions { name }
            dangerousInteractions { name }
            roas {
                name
                duration {
                    onset { min max units }
                    comeup { min max units }
                    peak { min max units }
                    offset { min max units }
                    total { min max units }
                }
                dose { units common { min } }
            }
        }
    }`;

  const result = await fetchGraphQL(query, { name });
  const substance = result?.data?.substances?.[0];
  const roa =
    substance?.roas?.find((item) => item.duration && item.dose?.common?.min) ||
    substance?.roas?.[0];

  if (!substance || !roa?.duration || !roa?.dose?.common?.min) {
    throw new Error("No usable dose and duration data was found for this substance.");
  }

  state.currentSubstance = substance;
  state.currentRoa = roa;
  state.currentCommonDose = Number(roa.dose.common.min);
  state.units = roa.dose.units || "";
  state.baseDurations = {
    onset: averageHours(roa.duration.onset),
    comeup: averageHours(roa.duration.comeup),
    peak: averageHours(roa.duration.peak),
    offset: averageHours(roa.duration.offset),
  };

  return {
    substance,
    roa,
    commonDose: state.currentCommonDose,
    units: state.units,
    durations: state.baseDurations,
  };
}

// ------------------------------------------------------------
// Pure time / curve math — byte-for-byte the same formulas as
// the original file. Do not "simplify" these without re-checking
// against old output; the shapes of the curves depend on them.
// ------------------------------------------------------------

export function averageHours(duration) {
  if (!duration) return 0;
  const average = (Number(duration.min || 0) + Number(duration.max || duration.min || 0)) / 2;
  if (duration.units === "minutes") return average / 60;
  if (duration.units === "seconds") return average / 3600;
  if (duration.units === "days") return average * 24;
  return average;
}

export function timeToHours(value) {
  if (!value) {
    const now = new Date();
    return now.getHours() + now.getMinutes() / 60;
  }
  const [hours, minutes] = value.split(":").map(Number);
  return hours + minutes / 60;
}

export function currentTimeValue() {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
}

/** profile = the substance's { base, commonDose }; defaults to the one loaded now. */
export function buildDoseCurve(startHour, doseAmount, releaseHours, profile = currentProfile()) {
  const intensity = doseAmount / profile.commonDose;
  const adjusted = {
    onset: profile.base.onset + releaseHours * 0.15,
    comeup: profile.base.comeup + releaseHours * 0.25,
    peak: profile.base.peak + releaseHours * 0.45,
    offset: profile.base.offset + releaseHours * 0.15,
  };
  const total = Object.values(adjusted).reduce((sum, value) => sum + value, 0);
  const step = Math.max(0.05, total / 650);
  const x = [startHour];
  const y = [0];
  let cursor = startHour;

  appendSegment(adjusted.onset, () => 0);
  appendSegment(adjusted.comeup, (progress) => progress * 100 * intensity);
  appendSegment(adjusted.peak, () => 100 * intensity);
  appendSegment(adjusted.offset, (progress) => (1 - progress) * 100 * intensity);

  function appendSegment(duration, valueAt) {
    if (duration <= 0) return;
    const count = Math.max(1, Math.ceil(duration / step));
    for (let index = 1; index <= count; index += 1) {
      const progress = index / count;
      x.push(cursor + duration * progress);
      y.push(Math.max(0, valueAt(progress)));
    }
    cursor += duration;
  }

  return { x, y };
}

export function formatChartTime(value) {
  const totalMinutes = Math.round(value * 60);
  const dayOffset = Math.floor(totalMinutes / 1440);
  const minutesInDay = ((totalMinutes % 1440) + 1440) % 1440;
  const hours = Math.floor(minutesInDay / 60);
  const minutes = minutesInDay % 60;
  const suffix = dayOffset > 0 ? ` +${dayOffset}d` : "";
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}${suffix}`;
}

function interpolateDose(dose, point) {
  if (point < dose.x[0] || point > dose.x[dose.x.length - 1]) return 0;
  let low = 0;
  let high = dose.x.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    if (dose.x[middle] === point) return dose.y[middle];
    if (dose.x[middle] < point) low = middle + 1;
    else high = middle - 1;
  }
  const right = Math.min(low, dose.x.length - 1);
  const left = Math.max(0, right - 1);
  const span = dose.x[right] - dose.x[left];
  if (!span) return dose.y[left];
  const progress = (point - dose.x[left]) / span;
  return dose.y[left] + (dose.y[right] - dose.y[left]) * progress;
}

function currentProfile() {
  return { base: { ...state.baseDurations }, commonDose: state.currentCommonDose };
}

// ------------------------------------------------------------
// State mutation — required functions
// ------------------------------------------------------------

/**
 * Old name: addDose() (state half only — DOM reads/toast moved to ui.js).
 * formulation = { key, label, releaseHours } — read from the DOM by ui.js
 * and passed in as plain data, same shape as the old selectedFormulation().
 * Throws Error with the same messages the old toasts showed, so ui.js can
 * catch and display them without duplicating validation rules.
 */
export function addDoseToState({ amount, time, formulation }) {
  if (!state.currentSubstance) {
    throw new Error("Select a substance before adding a dose.");
  }
  const numericAmount = Number(amount);
  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    throw new Error("Enter a dose greater than zero.");
  }
  if (!Number.isFinite(formulation.releaseHours) || formulation.releaseHours < 0) {
    throw new Error("Enter a valid release window.");
  }

  const doseTime = time || currentTimeValue();
  // Kept on the dose so it can be redrawn after an edit, even once another substance is loaded.
  const profile = currentProfile();
  const curve = buildDoseCurve(timeToHours(doseTime), numericAmount, formulation.releaseHours, profile);

  const dose = {
    id: ++state.doseSequence,
    x: curve.x,
    y: curve.y,
    time: doseTime,
    amount: numericAmount,
    unit: state.units,
    formulation: formulation.label,
    releaseHours: formulation.releaseHours,
    substance: state.currentSubstance.name,
    color: colorForSubstance(state.currentSubstance.name),
    profile,
  };

  state.addedDoses.push(dose);
  return dose;
}

/** Changes an added dose's amount and/or time and redraws its curve. */
export function updateDoseInState(id, { amount, time }) {
  const dose = state.addedDoses.find((item) => item.id === id);
  if (!dose) throw new Error("That dose is no longer on the timeline.");
  const numericAmount = Number(amount);
  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    throw new Error("Enter a dose greater than zero.");
  }
  if (!/^\d{1,2}:\d{2}$/.test(String(time || ""))) {
    throw new Error("Enter a time like 08:30.");
  }
  const curve = buildDoseCurve(timeToHours(time), numericAmount, dose.releaseHours, dose.profile);
  dose.amount = numericAmount;
  dose.time = time;
  dose.x = curve.x;
  dose.y = curve.y;
  return dose;
}

/**
 * Graph sessions ("Experiences"). A saved dose keeps the duration profile
 * it was drawn with, so an old session redraws exactly as it looked.
 */
export function snapshotDoses() {
  return state.addedDoses.map((dose) => ({
    substance: dose.substance,
    amount: dose.amount,
    unit: dose.unit || "",
    formulation: dose.formulation || "",
    releaseHours: dose.releaseHours || 0,
    time: dose.time,
    profile: { base: { ...dose.profile.base }, commonDose: dose.profile.commonDose },
  }));
}

/** A saved dose in a shape buildDoseCurve can draw, or null if it can't be drawn. */
function savedDose(raw) {
  if (!raw || typeof raw.substance !== "string" || !raw.substance.trim()) return null;
  const amount = Number(raw.amount);
  const releaseHours = Number(raw.releaseHours) || 0;
  const commonDose = Number(raw.profile?.commonDose);
  const base = {};
  for (const key of ["onset", "comeup", "peak", "offset"]) {
    base[key] = Number(raw.profile?.base?.[key]) || 0;
    if (base[key] < 0 || base[key] > 240) return null;
  }
  if (!(amount > 0) || !(commonDose > 0) || releaseHours < 0 || releaseHours > 48) return null;
  if (!/^\d{1,2}:\d{2}$/.test(String(raw.time || ""))) return null;
  return {
    substance: raw.substance.trim().slice(0, 80),
    amount,
    unit: String(raw.unit || "").slice(0, 12),
    formulation: String(raw.formulation || "").slice(0, 40),
    releaseHours,
    time: raw.time,
    profile: { base, commonDose },
  };
}

/** Replaces the timeline with a saved session's doses. Returns the doses drawn. */
export function loadDoses(list) {
  state.addedDoses = [];
  state.substanceColors = {};
  (Array.isArray(list) ? list : []).map(savedDose).filter(Boolean).forEach((saved) => {
    const curve = buildDoseCurve(timeToHours(saved.time), saved.amount, saved.releaseHours, saved.profile);
    state.addedDoses.push({
      ...saved,
      id: ++state.doseSequence,
      x: curve.x,
      y: curve.y,
      color: colorForSubstance(saved.substance),
    });
  });
  return state.addedDoses;
}

/** The colors a saved session's substances get once it is opened (same order rules as the graph). */
export function previewColors(names) {
  let next = 0;
  return names.map((name) => state.customColors[String(name).toLowerCase()] || SERIES_COLORS[next++ % SERIES_COLORS.length]);
}

/** A small summary curve per substance for a saved session, sampled at `points` steps. */
export function previewTimeline(list, points = 64) {
  const curves = (Array.isArray(list) ? list : []).map(savedDose).filter(Boolean).map((saved) => ({
    name: saved.substance,
    ...buildDoseCurve(timeToHours(saved.time), saved.amount, saved.releaseHours, saved.profile),
  }));
  if (!curves.length) return null;
  const start = Math.min(...curves.map((curve) => curve.x[0]));
  const end = Math.max(...curves.map((curve) => curve.x[curve.x.length - 1]));
  const span = end - start || 1;
  const xs = Array.from({ length: points }, (_, index) => start + (span * index) / (points - 1));
  const names = [...new Set(curves.map((curve) => curve.name))];
  const series = names.map((name) => {
    const mine = curves.filter((curve) => curve.name === name);
    return { name, y: xs.map((point) => mine.reduce((sum, curve) => sum + interpolateDose(curve, point), 0)) };
  });
  const peak = Math.max(1, ...series.flatMap((item) => item.y));
  return { names, series, peak, hours: end - start };
}

/** Old name: deleteDose(id) (state half only). */
export function removeDoseFromState(id) {
  state.addedDoses = state.addedDoses.filter((dose) => dose.id !== id);
}

/** Old name: resetGraph() (state half only). Matches old behavior:
 *  only clears addedDoses — currentSubstance/baseDurations persist. */
export function resetState() {
  state.addedDoses = [];
  state.substanceColors = {};
}

// ------------------------------------------------------------
// Combined timeline — identical math to the old drawChart()'s
// data-prep section (allX / combinedY / tick calc), just without
// the Plotly trace/layout objects, which now live in plot.js.
// ------------------------------------------------------------

// One colour per substance, in the order they were first added.
export const SERIES_COLORS = ["#a67cff", "#2dd4bf", "#fbbf24", "#f472b6", "#60a5fa", "#a3e635", "#fb923c", "#e879f9"];

/** Colors picked on Profile › Preferences, as [{ name, color }]. */
export function setCustomColors(list) {
  state.customColors = {};
  (list || []).forEach((item) => {
    if (item && typeof item.name === "string" && /^#[0-9a-f]{6}$/i.test(item.color || "")) {
      state.customColors[item.name.trim().toLowerCase()] = item.color;
    }
  });
  // Doses already on the timeline take the new colors too.
  state.addedDoses.forEach((dose) => { dose.color = colorForSubstance(dose.substance); });
}

/** The graph color a substance already has, without assigning a new one. */
export function peekColor(name) {
  return state.customColors[String(name).toLowerCase()] || state.substanceColors[name] || null;
}

export function colorForSubstance(name) {
  const custom = state.customColors[String(name).toLowerCase()];
  if (custom) return custom;
  if (!state.substanceColors[name]) {
    const used = Object.keys(state.substanceColors).length;
    state.substanceColors[name] = SERIES_COLORS[used % SERIES_COLORS.length];
  }
  return state.substanceColors[name];
}

/**
 * Returns one series per substance (its doses summed), all sampled on a
 * shared time axis so the lines line up, plus the hourly tick values.
 */
export function computeTimeline() {
  if (!state.addedDoses.length) return null;

  const allX = Array.from(
    new Set(state.addedDoses.flatMap((dose) => dose.x.map((value) => Number(value.toFixed(4)))))
  ).sort((a, b) => a - b);

  const names = [];
  state.addedDoses.forEach((dose) => {
    if (!names.includes(dose.substance)) names.push(dose.substance);
  });

  const series = names.map((name) => {
    const doses = state.addedDoses.filter((dose) => dose.substance === name);
    return {
      name,
      color: colorForSubstance(name),
      y: allX.map((point) => doses.reduce((sum, dose) => sum + interpolateDose(dose, point), 0)),
    };
  });

  const hoverTimes = allX.map(formatChartTime);
  const minimum = Math.floor(Math.min(...allX));
  const maximum = Math.ceil(Math.max(...allX));
  // One grid line per hour; only very long timelines (over 2 days) step wider.
  const span = maximum - minimum;
  const tickStep = span <= 48 ? 1 : Math.ceil(span / 24);
  const tickValues = [];
  for (let hour = minimum; hour <= maximum; hour += tickStep) tickValues.push(hour);

  return {
    x: allX,
    series,
    hoverTimes,
    tickValues,
    tickText: tickValues.map(formatChartTime),
  };
}
