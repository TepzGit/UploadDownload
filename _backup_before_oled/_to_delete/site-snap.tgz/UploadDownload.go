package main

import (
	"bytes"
	"compress/gzip"
	cryptorand "crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"html/template"
	"io"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	// Time zone data built in, so the calendar can use the visitor's zone on Windows too.
	_ "time/tzdata"
	"unicode"
	"unicode/utf8"

	// Pure-Go SQLite driver: builds on Windows without a C compiler (mattn/go-sqlite3 needs cgo + gcc).
	_ "modernc.org/sqlite"

	"golang.org/x/crypto/bcrypt"
)

var schema string = `
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
	originalUsername TEXT NOT NULL,
    password_hash TEXT NOT NULL,
	pathToProfilePic TEXT NOT NULL,
	authority TEXT NOT NULL
);

CREATE TABLE drugs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT UNIQUE NOT NULL
);

CREATE TABLE drug_method_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    drug_id INTEGER NOT NULL,
    method_way STRING NOT NULL,
    unit TEXT NOT NULL,

    UNIQUE(drug_id, method_way),

    FOREIGN KEY(drug_id) REFERENCES drugs(id)
);

CREATE TABLE IF NOT EXISTS doses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    drug_id INTEGER NOT NULL,
    amount REAL NOT NULL,
	unit TEXT NOT NULL,
	method_way STRING NOT NULL, 
    taken_at DATETIME NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(drug_id) REFERENCES drugs(id),
	UNIQUE(user_id, drug_id, taken_at)
);

CREATE TABLE IF NOT EXISTS user_drug_color_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    drug_id INTEGER NOT NULL,
    color TEXT NOT NULL,

    UNIQUE(user_id, drug_id),

    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(drug_id) REFERENCES drugs(id)
);
`

type FileFolderInfo struct {
	Name    string
	Path    string
	IsDir   bool
	IsImg   bool
	IsAudio bool
	IsVid   bool
	Size    int
	Date    time.Time
}

type MakeFolderData struct {
	Name string `json:"name"`
	Path string `json:"path"`
}

type cookiesStruct struct {
	Time             time.Time
	Username         string
	OriginalUsername string
	Authority        string
	UserId           int
}

type psychonautwikiApiStruct struct {
	Data struct {
		Substances []struct {
			Name string `json:"name"`
			ROAs []struct {
				Name string `json:"name"`
				Dose struct {
					Units string `json:"units"`
				} `json:"dose"`
			} `json:"roas"`
		} `json:"substances"`
	} `json:"data"`
}

// Sessions are stored so a server restart doesn't sign everyone out.
var sessionSchema string = `
CREATE TABLE IF NOT EXISTS sessions (
	token TEXT PRIMARY KEY,
	user_id INTEGER NOT NULL,
	created_at DATETIME NOT NULL,
	expires_at DATETIME NOT NULL,
	FOREIGN KEY(user_id) REFERENCES users(id)
);
`

const sessionLifetime = 30 * 24 * time.Hour

var profileSchema string = `
CREATE TABLE IF NOT EXISTS liked_substances (
	user_id INTEGER NOT NULL,
	name TEXT NOT NULL COLLATE NOCASE,
	image TEXT NOT NULL DEFAULT '',
	class TEXT NOT NULL DEFAULT '',
	liked_at DATETIME NOT NULL,
	PRIMARY KEY(user_id, name),
	FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS user_drug_color_settings (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER NOT NULL,
	drug_id INTEGER NOT NULL,
	color TEXT NOT NULL,
	UNIQUE(user_id, drug_id),
	FOREIGN KEY(user_id) REFERENCES users(id),
	FOREIGN KEY(drug_id) REFERENCES drugs(id)
);

CREATE TABLE IF NOT EXISTS graph_experiences (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER NOT NULL,
	started_at INTEGER NOT NULL,
	updated_at INTEGER NOT NULL,
	doses TEXT NOT NULL,
	FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS graph_experiences_by_user ON graph_experiences(user_id, started_at);

CREATE TABLE IF NOT EXISTS profile_boxes (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER NOT NULL,
	pictures TEXT NOT NULL DEFAULT '[]',
	created_at INTEGER NOT NULL,
	FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS forum_posts (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER NOT NULL,
	body TEXT NOT NULL DEFAULT '',
	pictures TEXT NOT NULL DEFAULT '[]',
	created_at INTEGER NOT NULL,
	FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS forum_posts_by_user ON forum_posts(user_id, id);

CREATE TABLE IF NOT EXISTS file_access (
	user_id INTEGER PRIMARY KEY,
	all_folders INTEGER NOT NULL DEFAULT 0,
	folders TEXT NOT NULL DEFAULT '[]',
	can_edit INTEGER NOT NULL DEFAULT 0,
	FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS site_pictures (
	slot TEXT PRIMARY KEY,
	path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS forum_comments (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	post_id INTEGER NOT NULL,
	user_id INTEGER NOT NULL,
	body TEXT NOT NULL,
	created_at INTEGER NOT NULL,
	FOREIGN KEY(post_id) REFERENCES forum_posts(id),
	FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS forum_comments_by_post ON forum_comments(post_id, id);

CREATE TABLE IF NOT EXISTS friendships (
	requester_id INTEGER NOT NULL,
	addressee_id INTEGER NOT NULL,
	status TEXT NOT NULL DEFAULT 'pending',
	created_at INTEGER NOT NULL,
	PRIMARY KEY(requester_id, addressee_id),
	FOREIGN KEY(requester_id) REFERENCES users(id),
	FOREIGN KEY(addressee_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS experience_people (
	experience_id INTEGER NOT NULL,
	user_id INTEGER NOT NULL,
	added_at INTEGER NOT NULL,
	PRIMARY KEY(experience_id, user_id),
	FOREIGN KEY(experience_id) REFERENCES graph_experiences(id),
	FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS experience_people_by_user ON experience_people(user_id);
`

// Profile pictures and banners live in profiles/<user id>/ and are served at /profiles/.
var ProfilePicturesDirName string = "profiles"

const defaultProfilePic = "/profiles/Default/default.png"

// maxPictureMB is the biggest picture anyone can upload, in megabytes.
const maxPictureMB = 150
const maxPictureBytes = maxPictureMB << 20
const maxLikes = 500

// Graph sessions ("Experiences"): times are Unix milliseconds, the newest are kept.
const maxExperiences = 300
const maxExperienceDoses = 100

// Boxes on the Profile page (the + button): pictures (up to 4), one Graph session, or a note.
const maxPictureBoxes = 12
const picturesPerBox = 4
const maxNoteChars = 1000

// Forum posts: text and up to 4 pictures, newest first, 20 per page.
const maxPostChars = 2000
const picturesPerPost = 4
const postsPerPage = 20
const postsPer10Minutes = 10
const maxCommentChars = 1000
const commentsPer10Minutes = 30

// Friends someone can add to one Graph session ("who was with you").
const maxExperiencePeople = 20

var db *sql.DB

var UploadedFilesDirName string = "UploadedFiles"
var DataBaseFileName string = "Database.db"

var cookiesMu sync.Mutex
var cookies = map[string]cookiesStruct{}

var tpl *template.Template

func main() {
	tpl = template.New("root")
	tpl.New("Upload")

	StartCookieCleaner()

	// The upload folder is gitignored, so a fresh checkout has none and /Files/ 400s until it exists.
	if err := os.MkdirAll(UploadedFilesDirName, 0755); err != nil {
		panic("cannot create " + UploadedFilesDirName + ": " + err.Error())
	}

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/", "/index.html":
			// no-cache: browsers check for a newer copy each visit (a 304 when nothing changed).
			w.Header().Set("Cache-Control", "no-cache")
			http.ServeFile(w, r, "html/index.html")
		default:
			http.NotFound(w, r)
		}
	})

	http.HandleFunc("/Main", Main)
	http.HandleFunc("/login", LoginData)
	http.HandleFunc("/signup", Signup)
	http.HandleFunc("/logout", Logout)
	http.HandleFunc("/Profile", requireLogin(Profile))
	// Files is one shared folder that only admin accounts can open.
	http.HandleFunc("/Files/", requireFilesLogin(Downloader))
	http.HandleFunc("/Uploader", requireFilesLogin(Uploader))
	http.HandleFunc("/journal", requireLogin(Journal))
	http.HandleFunc("/journal/Drug", requireLogin(DrugInfo))
	http.HandleFunc("/sub", requireLogin(Substance))
	http.HandleFunc("/admin", requireAdminLogin(AdminPanel))
	http.HandleFunc("/admin/createUser", requireAdminLogin(AdminPanelCreateUser))

	http.HandleFunc("/upload", requireFilesLogin(GetUploadData))
	http.HandleFunc("/makeFolder", requireFilesLogin(makeFolder))
	http.HandleFunc("/getFolders", requireFilesLogin(getFolders))
	http.HandleFunc("/search", requireFilesLogin(search))
	http.HandleFunc("/delete", requireFilesLogin(Delete))
	http.HandleFunc("/rename", requireFilesLogin(Rename))
	http.HandleFunc("/getItems", requireFilesLogin(getItems))
	http.HandleFunc("/admin/files-access", requireAdminLogin(adminFilesAccess))
	http.HandleFunc("/admin/stats", requireAdminLogin(adminStats))
	http.HandleFunc("/site/picture", requireAdminLogin(sitePictureUpload))
	http.HandleFunc("/sitepic/", sitePicture)
	http.HandleFunc("/notifications", requireLogin(notifications))
	http.HandleFunc("/journalImport", requireLogin(journalImport))
	http.HandleFunc("/profile/doses", requireLogin(profileDoses))
	http.HandleFunc("/profile/intake", requireLogin(profileIntake))
	http.HandleFunc("/profile/boxes", requireLogin(profileBoxes))
	http.HandleFunc("/profile/picture", requireLogin(profilePicture))
	http.HandleFunc("/profile/appearance", requireLogin(profileAppearance))
	http.HandleFunc("/profiles/", requireLogin(profileImage))
	http.HandleFunc("/u/", requireLogin(publicProfile))
	http.HandleFunc("/Forum", requireLogin(Forum))
	http.HandleFunc("/forum/posts", requireLogin(forumPosts))
	http.HandleFunc("/forum/members", requireLogin(forumMembers))
	http.HandleFunc("/forum/comments", requireLogin(forumComments))
	http.HandleFunc("/friends", requireLogin(friends))
	http.HandleFunc("/experiences/people", requireLogin(experiencePeople))
	http.HandleFunc("/likes", requireLogin(likes))
	http.HandleFunc("/Replications", requireLogin(Replications))
	http.HandleFunc("/replications/list", requireLogin(replicationsList))
	http.HandleFunc("/replications/files/", requireLogin(replicationsFile))
	http.HandleFunc("/replications/thumbs/", requireLogin(replicationsFile))
	http.HandleFunc("/replications/backup", requireAdminLogin(replicationsBackup))
	// The Graph page is open to everyone, so this answers [] instead of redirecting when signed out.
	http.HandleFunc("/graphColors", graphColors)
	http.HandleFunc("/experiences", experiences)
	http.HandleFunc("/sub/saveData", requireLogin(saveData))
	http.HandleFunc("/admin/createUser/AdminPanelCreateUserNow", requireAdminLogin(AdminPanelCreateUserData))

	//	http.HandleFunc("/style.css", func(w http.ResponseWriter, r *http.Request) {
	//		w.Header().Set("Content-Type", "text/css")
	//		fmt.Fprint(w, styleCSS)
	//	})

	jsFiles, err := os.ReadDir("js")
	if err != nil {
		panic(err)
	}
	for _, jsFile := range jsFiles {
		jsName := jsFile.Name()
		http.HandleFunc("/"+jsName, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Cache-Control", "no-cache")
			http.ServeFile(w, r, "js/"+jsName)
		})
	}

	css, _ := os.ReadDir("css")
	for _, stylefile := range css {
		cssName := stylefile.Name()
		name := cssName

		http.HandleFunc("/"+name, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Cache-Control", "no-cache")
			http.ServeFile(w, r, "css/"+name)
		})
	}

	assets, err := os.ReadDir("assets")
	if err != nil {
		panic(err)
	}
	for _, asset := range assets {
		assetName := asset.Name()

		if asset.IsDir() {
			subAssets, _ := os.ReadDir("assets/" + assetName)

			for _, assetInDir := range subAssets {
				subAssetName := assetInDir.Name()

				p := filepath.ToSlash(filepath.Join(assetName, subAssetName))
				filePath := "assets/" + p // COPY VALUE

				route := "/" + p // COPY VALUE

				http.HandleFunc(route, func(w http.ResponseWriter, r *http.Request) {
					http.ServeFile(w, r, filePath)
				})
			}
			continue
		}

		name := assetName
		http.HandleFunc("/"+name, func(w http.ResponseWriter, r *http.Request) {
			http.ServeFile(w, r, "assets/"+name)
		})
	} // TODO Make it recursive for the subfiles

	// _time_format=sqlite stores times the same way mattn/go-sqlite3 did, so old rows still read back.
	db, err = sql.Open("sqlite", DataBaseFileName+"?_time_format=sqlite")
	if err != nil {
		panic(err)
	}
	if err := db.Ping(); err != nil {
		panic("cannot open database " + DataBaseFileName + ": " + err.Error())
	}
	db.Exec(schema)
	if _, err := db.Exec(sessionSchema); err != nil {
		panic("cannot create the sessions table: " + err.Error())
	}
	if _, err := db.Exec(profileSchema); err != nil {
		panic("cannot create the liked substances table: " + err.Error())
	}
	// Keeps the name as PsychonautWiki writes it ("LSD"); drugs.name is lowercase.
	if _, err := db.Exec("ALTER TABLE user_drug_color_settings ADD COLUMN display_name TEXT NOT NULL DEFAULT ''"); err != nil && !strings.Contains(err.Error(), "duplicate column") {
		panic("cannot add the color name column: " + err.Error())
	}
	// Databases from before banners existed don't have the column yet.
	if _, err := db.Exec("ALTER TABLE users ADD COLUMN pathToBanner TEXT NOT NULL DEFAULT ''"); err != nil && !strings.Contains(err.Error(), "duplicate column") {
		panic("cannot add the banner column: " + err.Error())
	}
	// The order of the Profile cards (JSON list of keys) and a custom page background.
	// siteColor is the account's main color for the whole site ('' = the default violet);
	// widgetClear is how see-through its Profile cards are, 0 to 100 percent.
	// nameColor: an admin's name color everywhere it shows; notesSeenAt: when the
	// letter icon (comments on your posts) was last opened, in ms.
	// siteBg is the account's background on every page ('' = the drifting colors,
	// a preset name, or 'custom' for siteBgImage, darkened by siteBgDim percent).
	// createdAt and lastSeen (ms) feed the Admin page's account list.
	// graphsMade and postsMade count every Graph session and Forum post ever made
	// (for the geek rank), so deleting or the session limit doesn't lower it.
	for _, column := range []string{"profileLayout TEXT NOT NULL DEFAULT ''", "pathToBackground TEXT NOT NULL DEFAULT ''", "siteColor TEXT NOT NULL DEFAULT ''", "widgetClear INTEGER NOT NULL DEFAULT 0", "nameColor TEXT NOT NULL DEFAULT ''", "notesSeenAt INTEGER NOT NULL DEFAULT 0", "siteBg TEXT NOT NULL DEFAULT ''", "siteBgImage TEXT NOT NULL DEFAULT ''", "siteBgDim INTEGER NOT NULL DEFAULT 40", "createdAt INTEGER NOT NULL DEFAULT 0", "lastSeen INTEGER NOT NULL DEFAULT 0", "graphsMade INTEGER NOT NULL DEFAULT 0", "postsMade INTEGER NOT NULL DEFAULT 0"} {
		if _, err := db.Exec("ALTER TABLE users ADD COLUMN " + column); err != nil && !strings.Contains(err.Error(), "duplicate column") {
			panic("cannot add the profile layout columns: " + err.Error())
		}
	}
	db.Exec(`UPDATE users SET
		graphsMade = MAX(graphsMade, (SELECT COUNT(*) FROM graph_experiences g WHERE g.user_id = users.id)),
		postsMade = MAX(postsMade, (SELECT COUNT(*) FROM forum_posts p WHERE p.user_id = users.id))`)
	if _, err := db.Exec(statsSchema); err != nil {
		panic("cannot create the view counters: " + err.Error())
	}
	// Boxes from before the + menu are all picture boxes; data holds a note or a Graph session id.
	for _, column := range []string{"kind TEXT NOT NULL DEFAULT 'pictures'", "data TEXT NOT NULL DEFAULT ''"} {
		if _, err := db.Exec("ALTER TABLE profile_boxes ADD COLUMN " + column); err != nil && !strings.Contains(err.Error(), "duplicate column") {
			panic("cannot add the profile box columns: " + err.Error())
		}
	}
	if err := os.MkdirAll(ProfilePicturesDirName, 0755); err != nil {
		panic("cannot create " + ProfilePicturesDirName + ": " + err.Error())
	}

	port := 8000
	loadNameColors()
	fmt.Println("Serving on 0.0.0.0:" + strconv.Itoa(port))

	handler := countViews(http.DefaultServeMux)
	err = http.ListenAndServeTLS("0.0.0.0: "+strconv.Itoa(port), "cert.pem", "key.pem", handler)
	if err != nil {
		http.ListenAndServe("0.0.0.0:"+strconv.Itoa(port), handler)
	}
}

func Main(w http.ResponseWriter, r *http.Request) {

	d := struct {
		Login       bool
		SessionInfo cookiesStruct
		IsAdmin     bool
		Pictures    map[string]string
	}{}

	d.SessionInfo, d.Login = sessionFromRequest(r)
	d.IsAdmin = d.Login && d.SessionInfo.Authority == "admin"
	d.Pictures = map[string]string{}
	for slot := range sitePictureSlots {
		d.Pictures[slot] = sitePictureLink(slot)
	}
	setRoleHint(w, r, d.SessionInfo, d.Login)
	fmt.Printf("[%s] NEUTRAL IP=%s USER=%s PATH=%s\n", time.Now().Format("2006-01-02 15:04:05"), clientIP(r), d.SessionInfo.OriginalUsername, r.URL.Path)

	tpl, err := template.ParseFiles("html/Main.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, d)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func Profile(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/profile.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	type dose struct {
		DrugName   string
		Unit       string
		Amount     float64
		TimeAgo    string
		Method_way string
	}
	type Totals struct {
		Name         string
		TotalAmount  float64
		Unit         string
		DisplayTotal string
	}

	d := struct {
		Username      string
		Initial       string
		Avatar        string
		Banner        string
		Background    string
		Layout        string
		SiteColor     string
		WidgetClear   int
		ClearAlpha    clearAlpha
		NameColor     string
		IsAdmin       bool
		Rank          geekRank
		Liked         []likedSubstance
		RecentIntakes []dose
		Totals        map[string]Totals
	}{
		Totals: make(map[string]Totals),
	}

	session, ok := sessionFromRequest(r)
	if !ok {
		http.Error(w, "invalid session", http.StatusUnauthorized)
		return
	}

	d.Username = session.OriginalUsername
	userId := session.UserId
	if first, _ := utf8.DecodeRuneInString(d.Username); first != utf8.RuneError {
		d.Initial = strings.ToUpper(string(first))
	}

	var avatar, banner, background, layout string
	db.QueryRow("SELECT pathToProfilePic, pathToBanner, pathToBackground, profileLayout, siteColor, widgetClear, nameColor FROM users WHERE id = ?", userId).Scan(&avatar, &banner, &background, &layout, &d.SiteColor, &d.WidgetClear, &d.NameColor)
	d.ClearAlpha = makeClearAlpha(d.WidgetClear)
	d.IsAdmin = session.Authority == "admin"
	d.Rank = rankOf(d.Username)
	if !d.IsAdmin {
		d.NameColor = ""
	}
	d.Avatar = existingPicture(avatar)
	d.Banner = existingPicture(banner)
	d.Background = existingPicture(background)
	d.Layout = strings.Join(profileLayout(layout), ",")

	d.Liked, err = likedSubstances(userId)
	if err != nil {
		fmt.Println(err)
	}

	rows, err := db.Query(`
	SELECT
		drug.name,
		dose.amount,
		dose.unit,
		dose.taken_at,
		dose.method_way
	FROM doses dose
	JOIN drugs drug ON dose.drug_id = drug.id
	WHERE dose.user_id = ?
	ORDER BY dose.taken_at DESC
	LIMIT 10;
	`, userId)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Database query failed", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	for rows.Next() {
		var dose dose
		var ti time.Time

		err := rows.Scan(&dose.DrugName, &dose.Amount, &dose.Unit, &ti, &dose.Method_way)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Something went wrong while getting users intakes", http.StatusInternalServerError)
			continue
		}

		dose.TimeAgo = timeToHowLongAgoString(ti)
		d.RecentIntakes = append(d.RecentIntakes, dose)

		normalizedAmount, normalizedUnit, err := normalizeAmount(dose.Amount, dose.Unit)
		if err != nil {
			continue
		}

		t := d.Totals[dose.DrugName]
		t.TotalAmount += normalizedAmount
		t.Unit = normalizedUnit
		t.Name = dose.DrugName
		d.Totals[dose.DrugName] = t
	}
	err = rows.Err()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong while getting users intakes", http.StatusInternalServerError)
		return
	}
	for name, t := range d.Totals {
		prettyAmt, prettyUnit := prettyAmount(t.TotalAmount, t.Unit)
		t.TotalAmount = prettyAmt
		t.DisplayTotal = strconv.FormatFloat(prettyAmt, 'f', -1, 64)
		t.Unit = prettyUnit
		d.Totals[name] = t
	}

	err = tpl.Execute(w, d)
	if err != nil {
		fmt.Println(err)
	}
}

func normalizeAmount(amount float64, unit string) (float64, string, error) {
	switch unit {
	case "g":
		return amount * 1_000_000, "ug", nil
	case "mg":
		return amount * 1_000, "ug", nil
	case "ug", "µg", "μg", "mcg":
		return amount, "ug", nil
	case "ml":
		return amount, "ml", nil
	default:
		return 0, "", fmt.Errorf("unknown unit")
	}
}

func prettyAmount(amount float64, unit string) (float64, string) {
	switch unit {
	case "ug":
		if amount >= 1_000_000 {
			return float64(amount) / 1_000_000, "g"
		}
		if amount >= 1_000 {
			return float64(amount) / 1_000, "mg"
		}
	}
	return float64(amount), unit
}

func journalImport(w http.ResponseWriter, r *http.Request) {
	var journalData struct {
		Experiences []struct {
			Title        string `json:"title"`
			Text         string `json:"text"`
			CreationDate int64  `json:"creationDate"`
			SortDate     int64  `json:"sortDate"`
			Ingestions   []struct {
				SubstanceName       string `json:"substanceName"`
				Time                int64  `json:"time"`
				ActualTime          time.Time
				EndTime             *int64  `json:"endTime"`
				CreationDate        int64   `json:"creationDate"`
				AdministrationRoute string  `json:"administrationRoute"`
				Dose                float64 `json:"dose"`
				IsDoseAnEstimate    bool    `json:"isDoseAndEstimate"`
				Units               string  `json:"units"`
				Notes               string  `json:"notes"`
			}
		} `json:"experiences"`
		SubstanceCompanions []struct {
			SubstanceName string `json:"substanceName"`
			Color         string `json:"color"`
		} `json:"substanceCompanions"`
	}

	json.NewDecoder(r.Body).Decode(&journalData)

	tx, err := db.Begin()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	stmt, err := tx.Prepare(
		"INSERT OR IGNORE INTO doses (user_id, drug_id, amount, taken_at) VALUES (?, ?, ?, ?)",
	)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	defer stmt.Close()

	tx2, err := db.Begin()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	stmt2, err := tx2.Prepare(
		"INSERT INTO user_drug_color_settings (user_id, drug_id, color) VALUES (?, ?, ?) ON CONFLICT(user_id, drug_id) DO UPDATE SET color = excluded.color",
	)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	defer stmt2.Close()

	usersession, _ := sessionFromRequest(r)
	user_id := usersession.UserId
	cacheDrugId := map[string]int64{}

	for _, experience := range journalData.Experiences {
		for _, ingestion := range experience.Ingestions {
			ingestion.ActualTime = time.Unix(ingestion.Time/1000, 0)

			drugID, exists := cacheDrugId[strings.ToLower(ingestion.SubstanceName)]

			if !exists {
				var drugId int64
				err = db.QueryRow("select id from drugs where name = ?", strings.ToLower(ingestion.SubstanceName)).Scan(&drugId)
				if err != nil {
					if err == sql.ErrNoRows {
						var result psychonautwikiApiStruct
						query := fmt.Sprintf(`
						{
						substances(query: "%s") {
								name
								roas {
									name
									dose {
										units
									}
								}
							}
						}
						`, ingestion.SubstanceName)
						QueryPsychonautWiki(query, &result)

						drugAddedD, err := db.Exec("insert into drugs (name) values(?)", strings.ToLower(ingestion.SubstanceName))
						if err != nil {
							fmt.Println(err)
						}
						drugIdFromAdded, err := drugAddedD.LastInsertId()
						if err != nil {
							fmt.Println(err)
						}
						drugId = drugIdFromAdded

						txtemp, err := db.Begin()
						if err != nil {
							fmt.Println(err)
							http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
							return
						}
						stmttemp, err := txtemp.Prepare(
							"INSERT OR IGNORE INTO drug_method_info (drug_id, method_way, unit) VALUES (?, ?, ?)",
						)
						if err != nil {
							fmt.Println(err)
							http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
							return
						}
						defer stmttemp.Close()

						for _, roa := range result.Data.Substances[0].ROAs {
							_, err := stmttemp.Exec(drugId, roa.Name, roa.Dose.Units)
							if err != nil {
								fmt.Println(err)
								txtemp.Rollback()
								http.Error(w, "Could not add dose to database", http.StatusBadRequest)
								return
							}
						}
						err = txtemp.Commit()
						if err != nil {
							fmt.Println(err)
							http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
							return
						}
					} else {
						fmt.Println(err)
						http.Error(w, "Something went wrong with database, could not check if drug exists or not", http.StatusInternalServerError)
						return
					}
				}
				cacheDrugId[strings.ToLower(ingestion.SubstanceName)] = drugId
				drugID = drugId
			}
			_, err := stmt.Exec(user_id, drugID, ingestion.Dose, ingestion.ActualTime)
			if err != nil {
				fmt.Println(err)
				tx.Rollback()
				http.Error(w, "Could not add dose to database", http.StatusBadRequest)
				return
			}
		}
	}

	for _, color := range journalData.SubstanceCompanions {
		drugID, exists := cacheDrugId[strings.ToLower(strings.ToLower(color.SubstanceName))]

		if !exists {
			var drugId int64
			err = db.QueryRow("select id from drugs where name = ?", strings.ToLower(color.SubstanceName)).Scan(&drugId)
			if err != nil {
				if err == sql.ErrNoRows {
					var result psychonautwikiApiStruct
					query := fmt.Sprintf(`
						{
						substances(query: "%s") {
								name
								roas {
									name
									dose {
										units
									}
								}
							}
						}
					`, color.SubstanceName)
					QueryPsychonautWiki(query, &result)

					drugAddedD, err := db.Exec("insert into drugs (name) values(?)", strings.ToLower(color.SubstanceName))
					if err != nil {
						fmt.Println(err)
					}
					drugIdFromAdded, err := drugAddedD.LastInsertId()
					if err != nil {
						fmt.Println(err)
					}
					drugId = drugIdFromAdded

					txtemp, err := db.Begin()
					if err != nil {
						fmt.Println(err)
						http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
						return
					}
					stmttemp, err := txtemp.Prepare(
						"INSERT OR IGNORE INTO drug_method_info (drug_id, method_way, unit) VALUES (?, ?, ?)",
					)
					if err != nil {
						fmt.Println(err)
						http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
						return
					}
					defer stmttemp.Close()

					for _, roa := range result.Data.Substances[0].ROAs {
						_, err := stmttemp.Exec(drugId, roa.Name, roa.Dose.Units)
						if err != nil {
							fmt.Println(err)
							txtemp.Rollback()
							http.Error(w, "Could not add dose to database", http.StatusBadRequest)
							return
						}
					}
					err = txtemp.Commit()
					if err != nil {
						fmt.Println(err)
						http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
						return
					}
				} else {
					fmt.Println(err)
					http.Error(w, "Something went wrong with database, could not check if drug exists or not", http.StatusInternalServerError)
					return
				}
			}
		}
		_, err := stmt.Exec(user_id, drugID, color.Color)
		if err != nil {
			fmt.Println(err)
			tx.Rollback()
			http.Error(w, "Could not add dose to database", http.StatusBadRequest)
			return
		}

	}

	err = tx.Commit()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
		return
	}
	err = tx2.Commit()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
		return
	}
}

func QueryPsychonautWiki(query string, result any) error {
	reqBody := struct {
		Query string
	}{
		Query: query,
	}

	jsonBody, err := json.Marshal(reqBody)
	if err != nil {
		return err
	}

	resp, err := http.Post(
		"https://api.psychonautwiki.org",
		"application/json",
		bytes.NewBuffer(jsonBody),
	)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	return json.Unmarshal(body, result)
}

func timeToHowLongAgoString(timeArg time.Time) string {
	diff := time.Now().Sub(timeArg)

	seconds := int(diff.Seconds())
	minutes := int(diff.Minutes())
	hours := int(diff.Hours())
	days := hours / 24
	months := days / 30
	years := days / 365

	if seconds < 0 {
		switch {
		case seconds > -60:
			if seconds == -1 {
				return "In 1 second"
			}
			withoutMinus := strings.Trim(strconv.Itoa(seconds), "-")
			return fmt.Sprintf("In %s second", withoutMinus)

		case minutes > -60:
			if minutes == -1 {
				return "In 1 minute"
			}
			withoutMinus := strings.Trim(strconv.Itoa(minutes), "-")
			return fmt.Sprintf("In %s minutes", withoutMinus)

		case hours > -24:
			if hours == -1 {
				return "In 1 hour"
			}
			withoutMinus := strings.Trim(strconv.Itoa(hours), "-")
			return fmt.Sprintf("In %s hours", withoutMinus)

		case days > -30:
			if days == -1 {
				return "In 1 day"
			}
			withoutMinus := strings.Trim(strconv.Itoa(days), "-")
			return fmt.Sprintf("In %s days", withoutMinus)

		case months > -12:
			if months == -1 {
				return "In 1 month"
			}
			withoutMinus := strings.Trim(strconv.Itoa(months), "-")
			return fmt.Sprintf("In %s months", withoutMinus)

		default:
			if years == -1 {
				return "In 1 year"
			}
			withoutMinus := strings.Trim(strconv.Itoa(years), "-")
			return fmt.Sprintf("In %s years", withoutMinus)
		}
	}

	switch {
	case seconds < 60:
		if seconds == 1 {
			return "1 second ago"
		}
		return fmt.Sprintf("%d seconds ago", seconds)

	case minutes < 60:
		if minutes == 1 {
			return "1 minute ago"
		}
		return fmt.Sprintf("%d minutes ago", minutes)

	case hours < 24:
		if hours == 1 {
			return "1 hour ago"
		}
		return fmt.Sprintf("%d hours ago", hours)

	case days < 30:
		if days == 1 {
			return "1 day ago"
		}
		return fmt.Sprintf("%d days ago", days)

	case months < 12:
		if months == 1 {
			return "1 month ago"
		}
		return fmt.Sprintf("%d months ago", months)

	default:
		if years == 1 {
			return "1 year ago"
		}
		return fmt.Sprintf("%d years ago", years)
	}
}

func Substance(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/sub.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

}

func saveData(w http.ResponseWriter, r *http.Request) {
	Data := struct {
		DrugName string `json:"DrugName"`
		Unit     string `json:"Unit"`
		Doses    []struct {
			Time       time.Time `json:"Time"`
			DoseAmount string    `json:"DoseAmount"`
			Unit       string    `json:"Unit"`
			Method     string    `json:"Method"`
		} `json:"Doses"`
	}{}

	err := json.NewDecoder(r.Body).Decode(&Data)
	if err != nil {
		fmt.Println("Couldnt decode data, something went wrong")
		http.Error(w, "Couldnt decode data, something went wrong", http.StatusBadRequest)
		return
	}

	var drugId int64
	err = db.QueryRow("select id from drugs where name = ?", strings.ToLower(Data.DrugName)).Scan(&drugId)
	if err != nil {
		if err == sql.ErrNoRows {
			var result psychonautwikiApiStruct
			query := fmt.Sprintf(`
				{
				substances(query: "%s") {
						name
						roas {
							name
							dose {
								units
							}
						}
					}
				}
			`, Data.DrugName)
			QueryPsychonautWiki(query, &result)
			drugAddedD, err := db.Exec("insert into drugs (name) values(?)", strings.ToLower(Data.DrugName))
			if err != nil {
				fmt.Println(err)
			}
			fmt.Println(result.Data.Substances)
			drugIdFromAdded, err := drugAddedD.LastInsertId()
			if err != nil {
				fmt.Println(err)
			}
			drugId = drugIdFromAdded

			txtemp, err := db.Begin()
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
				return
			}
			stmttemp, err := txtemp.Prepare(
				"INSERT OR IGNORE INTO drug_method_info (drug_id, method_way, unit) VALUES (?, ?, ?)",
			)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
				return
			}
			defer stmttemp.Close()

			for _, roa := range result.Data.Substances[0].ROAs {
				_, err := stmttemp.Exec(drugId, roa.Name, roa.Dose.Units)
				if err != nil {
					fmt.Println(err)
					txtemp.Rollback()
					http.Error(w, "Could not add dose to database", http.StatusBadRequest)
					return
				}
			}
			err = txtemp.Commit()
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
				return
			}
		} else {
			fmt.Println(err)
			http.Error(w, "Something went wrong with database, could not check if drug exists or not", http.StatusInternalServerError)
			return
		}
	}

	usersession, _ := sessionFromRequest(r)
	userId := usersession.UserId

	tx, err := db.Begin()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	stmt, err := tx.Prepare(
		"INSERT OR IGNORE INTO doses (user_id, drug_id, amount, unit, method_way, taken_at) VALUES (?, ?, ?, ?, ?, ?)",
	)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Something went wrong in server", http.StatusInternalServerError)
		return
	}
	defer stmt.Close()

	for _, dose := range Data.Doses {
		_, err = stmt.Exec(userId, drugId, dose.DoseAmount, dose.Unit, dose.Method, dose.Time)
		if err != nil {
			fmt.Println(err)
			tx.Rollback()
			http.Error(w, "Could not add dose to database", http.StatusBadRequest)
			return
		}
	}

	err = tx.Commit()
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Could not add all doses to database, something went wrong", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(200)
}

func Journal(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/Journal.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func DrugInfo(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/DruginfoPage.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func LoginData(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r)
	fmt.Printf("[%s] NEUTRAL IP=%s PATH=%s REASON=LogginIn\n", time.Now().Format("2006-01-02 15:04:05"), ip, r.URL.Path)

	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/Main", http.StatusSeeOther)
		return
	}

	var UserLoginData struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	err := json.NewDecoder(r.Body).Decode(&UserLoginData)
	if err != nil {
		http.Error(w, "Not valid login data", http.StatusBadRequest)
		return
	}

	var originalUsername string
	var authority string
	var password string
	var userId int
	err = db.QueryRow("select originalUsername,authority,password_hash,id from users where username = ?", strings.ToLower(strings.TrimSpace(UserLoginData.Username))).Scan(&originalUsername, &authority, &password, &userId)
	if err != nil {
		if err == sql.ErrNoRows {
			fmt.Printf("[%s] DENY IP=%s USER=%q REASON=no_such_user\n", time.Now().Format("2006-01-02 15:04:05"), ip, UserLoginData.Username)
			http.Error(w, "Wrong username or password.", http.StatusUnauthorized)
			return
		} else {
			fmt.Printf("[%s] ERROR login query failed for %q: %v\n", time.Now().Format("2006-01-02 15:04:05"), UserLoginData.Username, err)
			http.Error(w, "Can not query from database rn", http.StatusInternalServerError)
			return
		}
	}

	if err := bcrypt.CompareHashAndPassword([]byte(password), []byte(UserLoginData.Password)); err != nil {
		fmt.Printf("[%s] DENY IP=%s USER=%q REASON=wrong_password\n", time.Now().Format("2006-01-02 15:04:05"), ip, UserLoginData.Username)
		http.Error(w, "Wrong username or password.", http.StatusUnauthorized)
		return
	}

	endSession(w, r) // drop any older session this browser had
	err = startSession(w, r, cookiesStruct{
		Username:         strings.ToLower(originalUsername),
		OriginalUsername: originalUsername,
		Authority:        strings.ToLower(authority),
		UserId:           userId,
	})
	if err != nil {
		fmt.Printf("[%s] ERROR could not start session for %q: %v\n", time.Now().Format("2006-01-02 15:04:05"), originalUsername, err)
		http.Error(w, "Could not sign you in right now", http.StatusInternalServerError)
		return
	}
	fmt.Printf("[%s] LOGIN IP=%s USER=%s\n", time.Now().Format("2006-01-02 15:04:05"), ip, originalUsername)

	w.WriteHeader(http.StatusOK)
}

// Signup creates a normal ("user") account and signs the new user in.
func Signup(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/Main", http.StatusSeeOther)
		return
	}

	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		http.Error(w, "Not valid sign up data", http.StatusBadRequest)
		return
	}
	in.Username = strings.TrimSpace(in.Username)
	if msg := checkNewAccount(in.Username, in.Password); msg != "" {
		http.Error(w, msg, http.StatusBadRequest)
		return
	}

	userId, err := createUser(in.Username, in.Password, "user")
	if errors.Is(err, errUserExists) {
		http.Error(w, "That username is taken.", http.StatusConflict)
		return
	}
	if err != nil {
		fmt.Printf("[%s] ERROR sign up failed for %q: %v\n", time.Now().Format("2006-01-02 15:04:05"), in.Username, err)
		http.Error(w, "Could not create the account right now", http.StatusInternalServerError)
		return
	}

	endSession(w, r)
	err = startSession(w, r, cookiesStruct{
		Username:         strings.ToLower(in.Username),
		OriginalUsername: in.Username,
		Authority:        "user",
		UserId:           userId,
	})
	if err != nil {
		fmt.Printf("[%s] ERROR could not start session for %q: %v\n", time.Now().Format("2006-01-02 15:04:05"), in.Username, err)
		http.Error(w, "Account created, but signing in failed. Try logging in.", http.StatusInternalServerError)
		return
	}
	fmt.Printf("[%s] SIGNUP IP=%s USER=%s\n", time.Now().Format("2006-01-02 15:04:05"), clientIP(r), in.Username)
	w.WriteHeader(http.StatusOK)
}

// Logout ends the session. Only POST signs out, so a link preview or
// prefetch of /logout can't.
func Logout(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		endSession(w, r)
	}
	http.Redirect(w, r, "/Main", http.StatusSeeOther)
}

var errUserExists = errors.New("user already exists")

var usernamePattern = regexp.MustCompile(`^[A-Za-z0-9_.-]{3,24}$`)

// checkNewAccount returns a message for the user when the username or
// password can't be used, or "" when both are fine.
func checkNewAccount(username, password string) string {
	if !usernamePattern.MatchString(username) {
		return "Usernames are 3 to 24 letters, numbers, dots, dashes or underscores."
	}
	if len(password) < 8 {
		return "Passwords need at least 8 characters."
	}
	if len(password) > 72 { // bcrypt ignores anything past 72 bytes
		return "Passwords can be at most 72 characters."
	}
	return ""
}

// createUser stores a new account and returns its id.
func createUser(username, password, authority string) (int, error) {
	var exists bool
	err := db.QueryRow("select exists(select 1 from users where username = ?)", strings.ToLower(username)).Scan(&exists)
	if err != nil {
		return 0, err
	}
	if exists {
		return 0, errUserExists
	}

	HashedPass, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return 0, err
	}
	res, err := db.Exec("insert into users (username, originalUsername, password_hash, pathToProfilePic, authority, createdAt) values (?, ?, ?, ?, ?, ?)", strings.ToLower(username), username, string(HashedPass), "/profiles/Default/default.png", strings.ToLower(authority), time.Now().UnixMilli())
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			return 0, errUserExists
		}
		return 0, err
	}
	id, err := res.LastInsertId()
	return int(id), err
}

func clientIP(r *http.Request) string {
	ip := r.RemoteAddr
	if strings.Contains(ip, ":") {
		ip, _, _ = net.SplitHostPort(ip)
	}
	return ip
}

// sessionFromRequest returns the signed-in user for the request's SessionID
// cookie. The cookies map is a cache in front of the sessions table.
func sessionFromRequest(r *http.Request) (cookiesStruct, bool) {
	c, err := r.Cookie("SessionID")
	if err != nil || c.Value == "" {
		return cookiesStruct{}, false
	}
	token := c.Value

	cookiesMu.Lock()
	s, ok := cookies[token]
	cookiesMu.Unlock()
	if ok {
		if time.Since(s.Time) < sessionLifetime {
			return s, true
		}
		deleteSession(token)
		return cookiesStruct{}, false
	}

	var created, expires time.Time
	err = db.QueryRow(`
	SELECT s.created_at, s.expires_at, u.username, u.originalUsername, u.authority, u.id
	FROM sessions s
	JOIN users u ON u.id = s.user_id
	WHERE s.token = ?`, token).Scan(&created, &expires, &s.Username, &s.OriginalUsername, &s.Authority, &s.UserId)
	if err != nil {
		return cookiesStruct{}, false
	}
	if time.Now().After(expires) {
		deleteSession(token)
		return cookiesStruct{}, false
	}
	s.Time = created
	s.Authority = strings.ToLower(s.Authority)

	cookiesMu.Lock()
	cookies[token] = s
	cookiesMu.Unlock()
	return s, true
}

// startSession stores a new session for s and sends its cookie.
func startSession(w http.ResponseWriter, r *http.Request, s cookiesStruct) error {
	b := make([]byte, 32)
	if _, err := cryptorand.Read(b); err != nil {
		return err
	}
	token := hex.EncodeToString(b)

	now := time.Now().UTC()
	s.Time = now
	_, err := db.Exec("INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)", token, s.UserId, now, now.Add(sessionLifetime))
	if err != nil {
		return err
	}

	cookiesMu.Lock()
	cookies[token] = s
	cookiesMu.Unlock()

	http.SetCookie(w, &http.Cookie{
		Name:     "SessionID",
		Value:    token,
		Path:     "/",
		MaxAge:   int(sessionLifetime / time.Second),
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Secure:   r.TLS != nil,
	})
	setRoleHint(w, r, s, true)
	return nil
}

// endSession forgets the request's session (if any) and clears its cookie.
func endSession(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("SessionID")
	if err != nil || c.Value == "" {
		return
	}
	deleteSession(c.Value)
	http.SetCookie(w, &http.Cookie{Name: "SessionID", Value: "", Path: "/", MaxAge: -1, HttpOnly: true, SameSite: http.SameSiteLaxMode})
	setRoleHint(w, r, cookiesStruct{}, false)
}

// setRoleHint keeps the xn_role cookie in step with the session so nav.js can
// hide links the account can't open (Files is admin only). It is only a
// display hint: every request is still checked against the session.
func setRoleHint(w http.ResponseWriter, r *http.Request, s cookiesStruct, signedIn bool) {
	c := &http.Cookie{Name: "xn_role", Path: "/", SameSite: http.SameSiteLaxMode, Secure: r.TLS != nil}
	if !signedIn {
		c.MaxAge = -1
	} else {
		c.Value = "user"
		if s.Authority == "admin" {
			c.Value = "admin"
		} else if _, ok := filesGrantFor(s); ok {
			c.Value = "files" // may open Files (some folders), so the nav shows the link
		}
		c.MaxAge = int(sessionLifetime / time.Second)
	}
	http.SetCookie(w, c)
}

func deleteSession(token string) {
	cookiesMu.Lock()
	delete(cookies, token)
	cookiesMu.Unlock()
	db.Exec("DELETE FROM sessions WHERE token = ?", token)
}

// notSignedIn sends page visits to the sign in box on /Main (coming back
// afterwards) and answers scripts with 401 so they can say so.
func notSignedIn(w http.ResponseWriter, r *http.Request) {
	setRoleHint(w, r, cookiesStruct{}, false)
	if r.Method == http.MethodGet || r.Method == http.MethodHead {
		http.Redirect(w, r, "/Main?next="+url.QueryEscape(r.URL.RequestURI()), http.StatusSeeOther)
		return
	}
	http.Error(w, "Please log in again.", http.StatusUnauthorized)
}

func requireLogin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ip := clientIP(r)

		d, ok := sessionFromRequest(r)
		if !ok {
			fmt.Printf("[%s] DENY IP=%s PATH=%s REASON=not_signed_in\n", time.Now().Format("2006-01-02 15:04:05"), ip, r.URL.Path)
			notSignedIn(w, r)
			return
		}
		fmt.Printf("[%s] ALLOW IP=%s USER=%s PATH=%s\n", time.Now().Format("2006-01-02 15:04:05"), ip, d.OriginalUsername, r.URL.Path)
		if r.Method == http.MethodGet {
			setRoleHint(w, r, d, true)
		}

		// all good → call the real handler
		next(w, r)
	}
}

func requireAdminLogin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ip := clientIP(r)

		d, ok := sessionFromRequest(r)
		if !ok {
			fmt.Printf("[%s] DENY IP=%s PATH=%s REASON=not_signed_in\n", time.Now().Format("2006-01-02 15:04:05"), ip, r.URL.Path)
			notSignedIn(w, r)
			return
		}
		if r.Method == http.MethodGet {
			setRoleHint(w, r, d, true)
		}
		if d.Authority != "admin" {
			fmt.Printf("[%s] DENY IP=%s USER=%s PATH=%s REASON=not_admin\n", time.Now().Format("2006-01-02 15:04:05"), ip, d.OriginalUsername, r.URL.Path)
			if r.Method == http.MethodGet {
				http.Redirect(w, r, "/Main?need=admin", http.StatusSeeOther)
			} else {
				http.Error(w, "Only admins can do that.", http.StatusForbidden)
			}
			return
		}

		fmt.Printf("[%s] ALLOW IP=%s USER=%s AUTHORITY=%s PATH=%s\n", time.Now().Format("2006-01-02 15:04:05"), ip, d.OriginalUsername, d.Authority, r.URL.Path)
		next(w, r)
	}
}

func StartCookieCleaner() {
	go func() {
		for {
			time.Sleep(1 * time.Hour)

			cookiesMu.Lock()
			for key, value := range cookies {
				if time.Since(value.Time) > sessionLifetime {
					delete(cookies, key)
				}
			}
			cookiesMu.Unlock()

			rows, err := db.Query("SELECT token, expires_at FROM sessions")
			if err != nil {
				continue
			}
			var expired []string
			for rows.Next() {
				var token string
				var expires time.Time
				if rows.Scan(&token, &expires) == nil && time.Now().After(expires) {
					expired = append(expired, token)
				}
			}
			rows.Close()
			for _, token := range expired {
				db.Exec("DELETE FROM sessions WHERE token = ?", token)
			}
		}
	}()
}

func Downloader(w http.ResponseWriter, r *http.Request) {
	//fs := http.FileServer(http.Dir("."))

	path := r.URL.Path
	path = strings.TrimSuffix(path, "/")

	if strings.Contains(path, "downloader.css") {
		return
	}

	session, _ := sessionFromRequest(r)
	grant, _ := filesGrantFor(session)
	dirPath, ok := insideUploads(strings.Split(strings.TrimPrefix(strings.TrimPrefix(path, "/Files"), "/"), "/")...)
	if !ok {
		http.Error(w, "Cant find folder/file, it dosent exit", http.StatusBadRequest)
		return
	}
	rel := uploadRel(dirPath)

	info, err := os.Stat(dirPath)
	if err != nil {
		if os.IsNotExist(err) {
			http.Error(w, "Cant find folder/file, it dosent exit", http.StatusBadRequest)
			return
		} else {
			http.Error(w, "Something went wrong when trying to find the folder", http.StatusBadRequest)
			return
		}
	}

	if info.IsDir() && !grant.canSee(rel) || !info.IsDir() && !grant.allows(rel) {
		http.Error(w, "You don't have access to that folder.", http.StatusForbidden)
		return
	}

	if info.IsDir() {
		d := struct {
			Files    []FileFolderInfo
			IsRoot   bool
			BackPath string
			CanEdit  bool
		}{CanEdit: grant.canChangeIn(rel)}
		if path == "/Files" {
			d.IsRoot = true
		} else {
			pathSplit := strings.Split(path, "/")
			if len(pathSplit) < 2 {
				d.BackPath = "/"
			} else {
				d.BackPath = strings.Join(pathSplit[:len(pathSplit)-1], "/")
			}
		}

		d.Files, err = getItemsInPath(w, r, dirPath)
		if err != nil {
			http.Error(w, "Cant find folder/file", http.StatusBadRequest)
			return
		}
		d.Files = grant.visible(d.Files, rel)

		tpl, err := template.ParseFiles("html/Downloader.html")
		if err != nil {
			http.Error(w, "Couldnt load page", http.StatusBadRequest)
			return
		}

		err = tpl.Execute(w, d)
		if err != nil {
			http.Error(w, "Couldnt load page", http.StatusBadRequest)
			return
		}
	} else {
		w.Header().Set("Content-Disposition", "attachment; filename=\""+info.Name()+"\"")
		http.ServeFile(w, r, dirPath)
	}

}

func Uploader(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	if grant, _ := filesGrantFor(session); !grant.CanEdit {
		http.Redirect(w, r, "/Files/", http.StatusSeeOther)
		return
	}

	//tpl.ExecuteTemplate(w, "Upload", nil)

	tpl, err := template.ParseFiles("html/Uploader.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func GetUploadData(w http.ResponseWriter, r *http.Request) {

	err := r.ParseMultipartForm(20 << 20)
	if err != nil {
		http.Error(w, "Error parsing form", http.StatusBadRequest)
		return
	}

	files := r.MultipartForm.File["files"]
	if len(files) == 0 {
		http.Error(w, "No files uploaded", http.StatusBadRequest)
		return
	}
	uploadDir, ok := insideUploads(r.FormValue("currentPath"))
	if !ok {
		http.Error(w, "Not a valid folder", http.StatusBadRequest)
		return
	}
	if !filesGrantOf(r).canChangeIn(uploadRel(uploadDir)) {
		http.Error(w, "You can't upload to that folder.", http.StatusForbidden)
		return
	}

	os.MkdirAll(UploadedFilesDirName, 0755)
	for _, file := range files {
		f, _ := file.Open()
		out, err := os.Create(filepath.Join(uploadDir, filepath.Base(file.Filename)))
		if err != nil {
			http.Error(w, "Error Downloading File", http.StatusBadRequest)
			f.Close()
			continue
		}

		_, err = io.Copy(out, f)
		if err != nil {
			http.Error(w, "Error Saving file", http.StatusInternalServerError)
			return
		}

		f.Close()
		out.Close()
		fmt.Println("Uploaded file: " + file.Filename)
	}

	http.Redirect(w, r, "/Uploader?success=true", http.StatusSeeOther)
}

func makeFolder(w http.ResponseWriter, r *http.Request) {
	var folderData MakeFolderData
	err := json.NewDecoder(r.Body).Decode(&folderData)
	if err != nil {
		http.Error(w, "Not valid folder data", http.StatusBadRequest)
		return
	}

	folderName := folderData.Name
	path := folderData.Path

	pathSplit := strings.Split(path, "/")

	var parts []string
	if len(pathSplit) > 2 {
		parts = pathSplit[2:]
	}
	dirPath, ok := insideUploads(parts...)
	if !ok || !validName(folderName) {
		http.Error(w, "Not a valid folder name", http.StatusBadRequest)
		return
	}
	if !filesGrantOf(r).canChangeIn(uploadRel(dirPath)) {
		http.Error(w, "You can't make folders here.", http.StatusForbidden)
		return
	}

	FullPathDir := filepath.Join(dirPath, folderName)
	err = os.MkdirAll(FullPathDir, 0755)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusOK)
}

func getFolders(w http.ResponseWriter, r *http.Request) {
	var getFolderData struct {
		CurrentPath string `json:"currentPath"`
		FolderToGet string `json:"FolderToGet"`
	}

	var FoldersReturn struct {
		Folders     []string `json:"Folders"`
		CurrentPath string   `json:"CurrentPath"`
	}

	err := json.NewDecoder(r.Body).Decode(&getFolderData)
	if err != nil {
		http.Error(w, "Not valid folder data", http.StatusBadRequest)
		return
	}

	currentPath := getFolderData.CurrentPath
	FolderToGet := getFolderData.FolderToGet
	if strings.HasPrefix(currentPath, "/") {
		currentPath = "./" + currentPath[1:]
	}

	Path, ok := insideUploads(currentPath, FolderToGet)
	grant := filesGrantOf(r)
	if !ok || !grant.canSee(uploadRel(Path)) {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	Dirs, err := os.ReadDir(Path)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	for _, Dir := range Dirs {
		if Dir.IsDir() && grant.canSee(joinRel(uploadRel(Path), Dir.Name())) {
			FoldersReturn.Folders = append(FoldersReturn.Folders, Dir.Name())
		}
	}
	rel, _ := filepath.Rel(UploadedFilesDirName, Path)
	FoldersReturn.CurrentPath = filepath.ToSlash(rel)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(FoldersReturn)
}

func search(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	currentPath := r.URL.Query().Get("path")

	pathSplit := strings.Split(currentPath, "/")

	var parts []string
	if len(pathSplit) > 2 {
		parts = pathSplit[2:]
	}
	finalPath, ok := insideUploads(parts...)
	grant := filesGrantOf(r)
	if !ok || !grant.canSee(uploadRel(finalPath)) {
		http.Error(w, "Cant find folder/file", http.StatusBadRequest)
		return
	}

	results := []FileFolderInfo{}
	if query != "" {
		results = searchFileFolder(finalPath, query)
	} else {
		FileFolders, err := getItemsInPath(w, r, finalPath)
		if err != nil {
			http.Error(w, "Cant find folder/file", http.StatusBadRequest)
			return
		}
		results = append(results, FileFolders...)
	}
	results = grant.visible(results, "")

	w.Header().Set("Content-Type", "application/json")
	err := json.NewEncoder(w).Encode(results)
	if err != nil {
		http.Error(w, "Failed to encode results", http.StatusInternalServerError)
		return
	}
}

// getItems answers a "Path: /Files/..." header with that folder's items as JSON,
// or with the file itself. Like the other Files routes it stays inside UploadedFiles.
func getItems(w http.ResponseWriter, r *http.Request) {
	finalPath := UploadedFilesDirName
	if p := r.Header.Get("Path"); strings.Trim(strings.TrimPrefix(p, "/Files"), "/") != "" {
		var ok bool
		if finalPath, ok = uploadPathFromURL(p); !ok {
			http.Error(w, "File not found", http.StatusNotFound)
			return
		}
	}
	info, err := os.Stat(finalPath)
	grant := filesGrantOf(r)
	rel := uploadRel(finalPath)
	if err != nil || info.IsDir() && !grant.canSee(rel) || !info.IsDir() && !grant.allows(rel) {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}
	if !info.IsDir() {
		http.ServeFile(w, r, finalPath)
		return
	}

	result, err := getItemsInPath(w, r, finalPath)
	if err != nil {
		http.Error(w, "Failed to get items", http.StatusInternalServerError)
		return
	}
	result = grant.visible(result, rel)

	w.Header().Set("Content-Type", "application/json")
	err = json.NewEncoder(w).Encode(result)
	if err != nil {
		http.Error(w, "Failed to encode results", http.StatusInternalServerError)
		return
	}
}

func getItemsInPath(w http.ResponseWriter, r *http.Request, PathString string) ([]FileFolderInfo, error) {
	var Items []FileFolderInfo
	var ArgNeeded struct {
		UrlPath string `json:"urlPath"`
	}

	var path string
	if PathString == "" {
		path = urlPathToFile(ArgNeeded.UrlPath)
	} else {
		path = PathString
	}

	FilesFolders, err := os.ReadDir(path)
	if err != nil {
		http.Error(w, "Could not read files from path", http.StatusBadRequest)
		return Items, fmt.Errorf("Could not read files from path")
	}

	for _, file := range FilesFolders {
		isDir, isImg, isVid, isAudio := checkExtension(file.Name(), file.IsDir())

		info, err := file.Info()
		if err != nil {
			continue
		}

		Items = append(Items, FileFolderInfo{
			Name:    info.Name(),
			Path:    FilePathToUrl(filepath.Join(path, info.Name())),
			IsDir:   isDir,
			IsImg:   isImg,
			IsAudio: isAudio,
			IsVid:   isVid,
			Size:    int(info.Size()),
			Date:    info.ModTime(),
		})
	}

	return Items, nil
}

func getItemFromPath(w http.ResponseWriter, r *http.Request, PathString string) FileFolderInfo {
	var Item FileFolderInfo
	var ArgNeeded struct {
		UrlPath string `json:"urlPath"`
	}

	var path string
	if PathString == "" {
		path = urlPathToFile(ArgNeeded.UrlPath)
	} else {
		path = PathString
	}

	file, err := os.Stat(path)
	if err != nil {
		http.Error(w, "Could not read files from path", http.StatusBadRequest)
		return FileFolderInfo{}
	}

	isDir, isImg, isVid, isAudio := checkExtension(file.Name(), file.IsDir())

	Item = FileFolderInfo{
		Name:    file.Name(),
		Path:    FilePathToUrl(strings.Join([]string{path, file.Name()}, "/")),
		IsDir:   isDir,
		IsImg:   isImg,
		IsAudio: isAudio,
		IsVid:   isVid,
	}

	return Item
}

func checkExtension(fileName string, isDir bool) (bool, bool, bool, bool) {
	Extensions := map[string][]string{
		"Images": []string{".jpg", ".jpeg", ".png", ".gif"},
		"Videos": []string{".mp4", ".mkv", ".mov", ".webm"},
		"Audio":  []string{".mp3", ".wav"},
	}

	var isImg bool
	var isVid bool
	var isAudio bool
	if isDir {
		return isDir, isImg, isVid, isAudio
	} else {
		for Type, ExtList := range Extensions {
			for _, Ext := range ExtList {
				if fileName[len(fileName)-len(Ext):] == Ext {
					if Type == "Images" {
						isImg = true
					} else if Type == "Videos" {
						isVid = true
					} else if Type == "Audio" {
						isAudio = true
					}
					break
				}
			}
		}
		return isDir, isImg, isVid, isAudio
	}
}

func urlPathToFile(urlPath string) string {
	pathSplit := strings.Split(urlPath, "/")

	var finalPath string
	if len(pathSplit) > 2 {
		finalPath = filepath.Join(append([]string{UploadedFilesDirName}, pathSplit[2:]...)...)
	} else {
		finalPath = UploadedFilesDirName + "/."
	}
	return finalPath
}

func FilePathToUrl(filePath string) string {
	pathSplit := strings.Split(filepath.ToSlash(filePath), "/")
	finalPath := "/Files/" + strings.Join(pathSplit[1:], "/")
	return (&url.URL{Path: finalPath}).EscapedPath()
}

// insideUploads joins parts onto the upload folder and refuses anything that
// would land outside it (a "..", an absolute path).
func insideUploads(parts ...string) (string, bool) {
	p := filepath.Join(append([]string{UploadedFilesDirName}, parts...)...)
	rel, err := filepath.Rel(UploadedFilesDirName, p)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return "", false
	}
	return p, true
}

// uploadPathFromURL maps a /Files/... link (a full URL or just the path,
// percent-encoded or not) to the file or folder it points at.
func uploadPathFromURL(raw string) (string, bool) {
	u, err := url.Parse(raw)
	if err != nil {
		return "", false
	}
	rel, found := strings.CutPrefix(u.Path, "/Files/")
	if !found || strings.Trim(rel, "/") == "" {
		return "", false
	}
	return insideUploads(strings.Split(rel, "/")...)
}

// validName is true for a plain file or folder name with no path in it.
func validName(name string) bool {
	return name != "" && name != "." && name != ".." && !strings.ContainsAny(name, "/\\")
}

func searchFileFolder(path string, query string) []FileFolderInfo {
	var results []FileFolderInfo
	entries, _ := os.ReadDir(path)

	for _, entry := range entries {
		fullPath := filepath.Join(path, entry.Name())

		if entry.IsDir() {
			results = append(results, searchFileFolder(fullPath, query)...)
		} else {
			if strings.Contains(strings.ToLower(entry.Name()), strings.ToLower(query)) {
				relPath, err := filepath.Rel(UploadedFilesDirName, fullPath)
				if err != nil {
					continue
				}

				info, err := entry.Info()
				if err != nil {
					continue
				}
				var d FileFolderInfo
				d.Name = info.Name()
				d.IsDir, d.IsImg, d.IsVid, d.IsAudio = checkExtension(info.Name(), false)
				d.Path = (&url.URL{Path: "/Files/" + filepath.ToSlash(relPath)}).EscapedPath()
				d.Size = int(info.Size())
				d.Date = info.ModTime()

				results = append(results, d)
			}
		}
	}

	return results
}

func Delete(w http.ResponseWriter, r *http.Request) {
	var deleteData struct {
		Path string `json:"path"`
	}
	err := json.NewDecoder(r.Body).Decode(&deleteData)
	if err != nil {
		http.Error(w, "Not valid folder data", http.StatusBadRequest)
		return
	}

	path, ok := uploadPathFromURL(deleteData.Path)
	if !ok {
		http.Error(w, "Not a valid file", http.StatusBadRequest)
		return
	}
	if !filesGrantOf(r).canChange(uploadRel(path)) {
		http.Error(w, "You can't delete that.", http.StatusForbidden)
		return
	}
	err = os.Remove(path)
	if err != nil {
		http.Error(w, "Failed to delete file", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func Rename(w http.ResponseWriter, r *http.Request) {
	var renameData struct {
		CurrentFilenamePath string `json:"currentFilenamePath"`
		NewFileName         string `json:"newFileName"`
	}
	err := json.NewDecoder(r.Body).Decode(&renameData)
	if err != nil {
		http.Error(w, "Not valid folder data", http.StatusBadRequest)
		return
	}

	currentFilePath, ok := uploadPathFromURL(renameData.CurrentFilenamePath)
	if !ok || !validName(renameData.NewFileName) {
		http.Error(w, "Not a valid name", http.StatusBadRequest)
		return
	}
	if !filesGrantOf(r).canChange(uploadRel(currentFilePath)) {
		http.Error(w, "You can't rename that.", http.StatusForbidden)
		return
	}
	newFilePath := filepath.Join(filepath.Dir(currentFilePath), renameData.NewFileName)

	curentFileName := filepath.Base(currentFilePath)
	if curentFileName != renameData.NewFileName {
		err := os.Rename(currentFilePath, newFilePath)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Could not rename file/folder", http.StatusInternalServerError)
			return

		}
	}

	w.WriteHeader(http.StatusOK)
}

func AdminPanel(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/AdminPanel.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func AdminPanelCreateUser(w http.ResponseWriter, r *http.Request) {
	tpl, err := template.ParseFiles("html/AdminPanelCreateUser.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}

	err = tpl.Execute(w, nil)
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
}

func AdminPanelCreateUserData(w http.ResponseWriter, r *http.Request) {
	err := r.ParseMultipartForm(1024)
	if err != nil {
		http.Error(w, "Cant parse data", http.StatusBadRequest)
		return
	}
	username := strings.TrimSpace(r.FormValue("username"))
	password := r.FormValue("password")
	authority := strings.ToLower(r.FormValue("authority"))

	if authority != "user" && authority != "admin" {
		http.Error(w, "Choose User or Admin.", http.StatusBadRequest)
		return
	}
	if msg := checkNewAccount(username, password); msg != "" {
		http.Error(w, msg, http.StatusBadRequest)
		return
	}

	_, err = createUser(username, password, authority)
	if errors.Is(err, errUserExists) {
		http.Error(w, "User already exists", http.StatusBadRequest)
		return
	}
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Could not create user", http.StatusInternalServerError)
		return
	}

	w.Write([]byte("User Created"))
}

// ---- Profile: dose calendar, liked substances, pictures ----

type likedSubstance struct {
	Name  string `json:"name"`
	Image string `json:"image"`
	Class string `json:"class"`
}

// Initial is the letter shown when a liked substance has no picture.
func (l likedSubstance) Initial() string {
	first, _ := utf8.DecodeRuneInString(l.Name)
	if first == utf8.RuneError {
		return "?"
	}
	return strings.ToUpper(string(first))
}

func likedSubstances(userId int) ([]likedSubstance, error) {
	rows, err := db.Query("SELECT name, image, class FROM liked_substances WHERE user_id = ? ORDER BY liked_at DESC", userId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []likedSubstance{}
	for rows.Next() {
		var l likedSubstance
		if err := rows.Scan(&l.Name, &l.Image, &l.Class); err != nil {
			return nil, err
		}
		out = append(out, l)
	}
	return out, rows.Err()
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

// cleanText trims s, drops control characters and cuts it to max characters.
func cleanText(s string, max int) string {
	s = strings.Map(func(r rune) rune {
		if unicode.IsControl(r) {
			return -1
		}
		return r
	}, strings.TrimSpace(s))
	if utf8.RuneCountInString(s) > max {
		s = string([]rune(s)[:max])
	}
	return s
}

// cleanMultiline is cleanText for notes and posts: it keeps line breaks (at
// most one empty line in a row) and drops the other control characters.
func cleanMultiline(s string, max int) string {
	lines := strings.Split(strings.ReplaceAll(s, "\r\n", "\n"), "\n")
	for i, line := range lines {
		lines[i] = strings.TrimRightFunc(strings.Map(func(r rune) rune {
			if r == '\t' {
				return ' '
			}
			if unicode.IsControl(r) {
				return -1
			}
			return r
		}, line), unicode.IsSpace)
	}
	s = strings.Join(lines, "\n")
	for strings.Contains(s, "\n\n\n") {
		s = strings.ReplaceAll(s, "\n\n\n", "\n\n")
	}
	s = strings.TrimSpace(s)
	if utf8.RuneCountInString(s) > max {
		s = strings.TrimSpace(string([]rune(s)[:max]))
	}
	return s
}

// initialOf is the letter shown when an account has no profile picture.
func initialOf(name string) string {
	if first, _ := utf8.DecodeRuneInString(name); first != utf8.RuneError {
		return strings.ToUpper(string(first))
	}
	return "?"
}

// userByName finds an account by its username (any letter case).
func userByName(name string) (int, bool) {
	var id int
	if err := db.QueryRow("SELECT id FROM users WHERE username = ?", strings.ToLower(strings.TrimSpace(name))).Scan(&id); err != nil {
		return 0, false
	}
	return id, true
}

// likes: GET lists the account's liked substances, POST {name, image, class, liked} adds or removes one.
func likes(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)

	switch r.Method {
	case http.MethodGet:
		list, err := likedSubstances(session.UserId)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load your likes.", http.StatusInternalServerError)
			return
		}
		writeJSON(w, list)

	case http.MethodPost:
		var in struct {
			likedSubstance
			Liked bool `json:"liked"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		name := cleanText(in.Name, 80)
		if name == "" {
			http.Error(w, "Pick a substance.", http.StatusBadRequest)
			return
		}
		if !in.Liked {
			if _, err := db.Exec("DELETE FROM liked_substances WHERE user_id = ? AND name = ?", session.UserId, name); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save that.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, map[string]bool{"liked": false})
			return
		}

		var count int
		db.QueryRow("SELECT COUNT(*) FROM liked_substances WHERE user_id = ?", session.UserId).Scan(&count)
		if count >= maxLikes {
			http.Error(w, fmt.Sprintf("You can like up to %d substances.", maxLikes), http.StatusBadRequest)
			return
		}
		// Only keep structure pictures from PsychonautWiki itself.
		image := strings.TrimSpace(in.Image)
		if len(image) > 300 || !strings.HasPrefix(image, "https://psychonautwiki.org/") {
			image = ""
		}
		_, err := db.Exec(`INSERT INTO liked_substances (user_id, name, image, class, liked_at) VALUES (?, ?, ?, ?, ?)
			ON CONFLICT(user_id, name) DO UPDATE SET image = excluded.image, class = excluded.class`,
			session.UserId, name, image, cleanText(in.Class, 120), time.Now().UTC())
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't save that.", http.StatusInternalServerError)
			return
		}
		writeJSON(w, map[string]bool{"liked": true})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// profileDoses answers GET ?month=2026-10&zone=Europe/Amsterdam (or &tz=<minutes, as JS
// getTimezoneOffset gives it>) with that month's doses grouped by day in the visitor's time zone.
func profileDoses(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	q := r.URL.Query()

	month, err := time.Parse("2006-01", q.Get("month"))
	if err != nil {
		http.Error(w, "Pick a month like 2026-10.", http.StatusBadRequest)
		return
	}
	zone := visitorZone(q)
	start := time.Date(month.Year(), month.Month(), 1, 0, 0, 0, 0, zone)
	end := start.AddDate(0, 1, 0)

	type entry struct {
		Name   string `json:"name"`
		Amount string `json:"amount"`
		Unit   string `json:"unit"`
		Method string `json:"method"`
		Time   string `json:"time"`
	}
	out := struct {
		Month  string             `json:"month"`
		Days   map[string][]entry `json:"days"`
		Latest string             `json:"latest"`
	}{Month: start.Format("2006-01"), Days: map[string][]entry{}}

	all, err := accountDoses(session.UserId, zone, time.Time{}, time.Time{})
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Couldn't load your doses.", http.StatusInternalServerError)
		return
	}
	for _, d := range all {
		if d.At.Before(start) || !d.At.Before(end) {
			continue
		}
		day := d.At.Format("2006-01-02")
		out.Days[day] = append(out.Days[day], entry{
			Name:   d.Name,
			Amount: formatAmount(d.Amount),
			Unit:   displayUnit(d.Unit),
			Method: d.Method,
			Time:   d.At.Format("15:04"),
		})
	}
	if len(all) > 0 {
		out.Latest = all[len(all)-1].At.Format("2006-01-02")
	}
	writeJSON(w, out)
}

// visitorZone reads the browser's time zone from ?zone=<IANA name>&tz=<minutes,
// as getTimezoneOffset gives them>.
func visitorZone(q url.Values) *time.Location {
	tz, err := strconv.Atoi(q.Get("tz"))
	if err != nil || tz < -840 || tz > 840 {
		tz = 0
	}
	zone := time.FixedZone("visitor", -tz*60)
	if name := q.Get("zone"); name != "" && name != "Local" {
		if loc, err := time.LoadLocation(name); err == nil {
			zone = loc
		}
	}
	return zone
}

// loggedDose is one dose on the Profile page, from the journal (the doses
// table, filled by "Save data" and journal imports) or from a Graph session.
type loggedDose struct {
	Name   string
	Amount float64
	Unit   string
	Method string
	At     time.Time
}

// accountDoses lists the account's doses taken in [from, to), oldest first; a
// zero time means no limit. Graph sessions only keep a clock time per dose, so
// those doses go on the day the session started, in loc. A Graph dose that was
// also saved to the journal (same substance, amount and minute) is listed once.
func accountDoses(userID int, loc *time.Location, from, to time.Time) ([]loggedDose, error) {
	out := []loggedDose{}
	seen := map[string]bool{}
	add := func(d loggedDose) {
		if (!from.IsZero() && d.At.Before(from)) || (!to.IsZero() && !d.At.Before(to)) {
			return
		}
		key := strings.ToLower(d.Name) + "|" + strconv.FormatFloat(d.Amount, 'f', -1, 64) + "|" + strconv.FormatInt(d.At.Unix()/60, 10)
		if !seen[key] {
			seen[key] = true
			out = append(out, d)
		}
	}

	// taken_at is text with its own UTC offset, so filter by date a day wider here and exactly in add.
	query := `SELECT drug.name, dose.amount, dose.unit, dose.method_way, dose.taken_at
		FROM doses dose JOIN drugs drug ON dose.drug_id = drug.id WHERE dose.user_id = ?`
	args := []any{userID}
	if !from.IsZero() {
		query += " AND dose.taken_at >= ?"
		args = append(args, from.AddDate(0, 0, -1).UTC().Format("2006-01-02"))
	}
	if !to.IsZero() {
		query += " AND dose.taken_at < ?"
		args = append(args, to.AddDate(0, 0, 2).UTC().Format("2006-01-02"))
	}
	rows, err := db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var d loggedDose
		if err := rows.Scan(&d.Name, &d.Amount, &d.Unit, &d.Method, &d.At); err != nil {
			fmt.Println(err)
			continue
		}
		d.At = d.At.In(loc)
		add(d)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}

	lo, hi := int64(0), int64(math.MaxInt64)
	if !from.IsZero() {
		lo = from.AddDate(0, 0, -2).UnixMilli()
	}
	if !to.IsZero() {
		hi = to.AddDate(0, 0, 2).UnixMilli()
	}
	rows, err = db.Query("SELECT started_at, doses FROM graph_experiences WHERE user_id = ? AND started_at >= ? AND started_at < ?", userID, lo, hi)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var started int64
		var raw string
		if err := rows.Scan(&started, &raw); err != nil {
			continue
		}
		var doses []experienceDose
		if json.Unmarshal([]byte(raw), &doses) != nil {
			continue
		}
		day := time.UnixMilli(started).In(loc)
		for _, g := range doses {
			var h, m int
			if _, err := fmt.Sscanf(g.Time, "%d:%d", &h, &m); err != nil {
				continue
			}
			add(loggedDose{
				Name:   g.Substance,
				Amount: g.Amount,
				Unit:   g.Unit,
				Method: g.Formulation,
				At:     time.Date(day.Year(), day.Month(), day.Day(), h, m, 0, 0, loc),
			})
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].At.Before(out[j].At) })
	return out, nil
}

func formatAmount(v float64) string {
	return strconv.FormatFloat(math.Round(v*100)/100, 'f', -1, 64)
}

// displayUnit writes micrograms the way PsychonautWiki does.
func displayUnit(unit string) string {
	if unit == "ug" || unit == "mcg" || unit == "μg" {
		return "µg"
	}
	return unit
}

// profileIntake: the Profile page's "Recent intake" (newest 10 doses) and
// "Totals" per substance for the last 7 days, 30 days and all time.
func profileIntake(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	loc := visitorZone(r.URL.Query())
	all, err := accountDoses(session.UserId, loc, time.Time{}, time.Time{})
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Couldn't load your doses.", http.StatusInternalServerError)
		return
	}

	type recentDose struct {
		Name   string `json:"name"`
		Amount string `json:"amount"`
		Unit   string `json:"unit"`
		Method string `json:"method"`
		At     string `json:"at"`
		Ago    string `json:"ago"`
	}
	type total struct {
		Name   string `json:"name"`
		Amount string `json:"amount"`
		Unit   string `json:"unit"`
		Doses  int    `json:"doses"`
	}
	out := struct {
		Count  int                `json:"count"`
		Recent []recentDose       `json:"recent"`
		Totals map[string][]total `json:"totals"`
	}{Count: len(all), Recent: []recentDose{}, Totals: map[string][]total{}}

	// The journal stores names in lowercase; the Graph keeps PsychonautWiki's spelling ("LSD").
	names := map[string]string{}
	for _, d := range all {
		k := strings.ToLower(d.Name)
		if cur, ok := names[k]; !ok || cur == k {
			names[k] = d.Name
		}
	}

	for i := len(all) - 1; i >= 0 && len(out.Recent) < 10; i-- {
		d := all[i]
		out.Recent = append(out.Recent, recentDose{
			Name:   names[strings.ToLower(d.Name)],
			Amount: formatAmount(d.Amount),
			Unit:   displayUnit(d.Unit),
			Method: d.Method,
			At:     d.At.Format(time.RFC3339),
			Ago:    timeToHowLongAgoString(d.At),
		})
	}

	now := time.Now().In(loc)
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, loc)
	ranges := map[string]time.Time{"week": today.AddDate(0, 0, -6), "month": today.AddDate(0, 0, -29), "all": {}}
	for key, from := range ranges {
		type sum struct {
			name   string
			amount float64
			unit   string
			doses  int
		}
		sums := map[string]*sum{}
		order := []string{}
		for _, d := range all {
			if !from.IsZero() && d.At.Before(from) {
				continue
			}
			amount, unit, err := normalizeAmount(d.Amount, d.Unit)
			if err != nil {
				amount, unit = d.Amount, d.Unit
			}
			k := strings.ToLower(d.Name) + "|" + unit
			if sums[k] == nil {
				sums[k] = &sum{name: names[strings.ToLower(d.Name)], unit: unit}
				order = append(order, k)
			}
			sums[k].amount += amount
			sums[k].doses++
		}
		list := []total{}
		for _, k := range order {
			s := sums[k]
			amount, unit := prettyAmount(s.amount, s.unit)
			list = append(list, total{Name: s.name, Amount: formatAmount(amount), Unit: displayUnit(unit), Doses: s.doses})
		}
		sort.SliceStable(list, func(i, j int) bool {
			if list[i].Doses != list[j].Doses {
				return list[i].Doses > list[j].Doses
			}
			return strings.ToLower(list[i].Name) < strings.ToLower(list[j].Name)
		})
		out.Totals[key] = list
	}
	writeJSON(w, out)
}

// profileFile maps a /profiles/... link to its file inside the profiles folder.
func profileFile(link string) (string, bool) {
	rel, found := strings.CutPrefix(link, "/profiles/")
	if !found || strings.Trim(rel, "/") == "" {
		return "", false
	}
	p := filepath.Join(ProfilePicturesDirName, filepath.FromSlash(rel))
	r, err := filepath.Rel(ProfilePicturesDirName, p)
	if err != nil || r == "." || r == ".." || strings.HasPrefix(r, ".."+string(filepath.Separator)) {
		return "", false
	}
	return p, true
}

// existingPicture returns link when it points at a picture that is really on disk, else "".
func existingPicture(link string) string {
	p, ok := profileFile(link)
	if !ok {
		return ""
	}
	if info, err := os.Stat(p); err != nil || info.IsDir() {
		return ""
	}
	return link
}

func profileImage(w http.ResponseWriter, r *http.Request) {
	p, ok := profileFile(r.URL.Path)
	if !ok {
		http.NotFound(w, r)
		return
	}
	switch strings.ToLower(filepath.Ext(p)) {
	case ".jpg", ".jpeg", ".png", ".gif", ".webp":
	default:
		http.NotFound(w, r)
		return
	}
	if info, err := os.Stat(p); err != nil || info.IsDir() {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, max-age=86400")
	http.ServeFile(w, r, p)
}

// removeOwnPicture deletes a replaced upload, but only one inside that account's own folder.
func removeOwnPicture(link string, userId int) {
	if !strings.HasPrefix(link, "/profiles/"+strconv.Itoa(userId)+"/") {
		return
	}
	if p, ok := profileFile(link); ok {
		os.Remove(p)
	}
}

// saveProfileImage stores an uploaded JPG/PNG/GIF/WebP in profiles/<uid>/ as
// <prefix>-<random>.<ext> and returns its /profiles/ link, or an HTTP status
// and message when it can't.
func saveProfileImage(file io.ReadSeeker, uid int, prefix string) (string, int, string) {
	name, status, msg := saveImageIn(file, filepath.Join(ProfilePicturesDirName, strconv.Itoa(uid)), prefix)
	if status != 0 {
		return "", status, msg
	}
	return "/profiles/" + strconv.Itoa(uid) + "/" + name, 0, ""
}

// saveImageIn stores an uploaded JPG/PNG/GIF/WebP in dir as
// <prefix>-<random>.<ext> and returns the file name.
func saveImageIn(file io.ReadSeeker, dir, prefix string) (string, int, string) {
	head := make([]byte, 512)
	n, _ := io.ReadFull(file, head)
	var ext string
	switch http.DetectContentType(head[:n]) {
	case "image/jpeg":
		ext = ".jpg"
	case "image/png":
		ext = ".png"
	case "image/gif":
		ext = ".gif"
	case "image/webp":
		ext = ".webp"
	default:
		return "", http.StatusUnsupportedMediaType, "Use a JPG, PNG, GIF or WebP picture."
	}
	if _, err := file.Seek(0, io.SeekStart); err != nil {
		return "", http.StatusInternalServerError, "Couldn't read the picture."
	}

	if err := os.MkdirAll(dir, 0755); err != nil {
		fmt.Println(err)
		return "", http.StatusInternalServerError, "Couldn't save the picture."
	}
	b := make([]byte, 6)
	cryptorand.Read(b)
	name := prefix + "-" + hex.EncodeToString(b) + ext
	out, err := os.Create(filepath.Join(dir, name))
	if err != nil {
		fmt.Println(err)
		return "", http.StatusInternalServerError, "Couldn't save the picture."
	}
	_, copyErr := io.Copy(out, file)
	closeErr := out.Close()
	if copyErr != nil || closeErr != nil {
		os.Remove(filepath.Join(dir, name))
		return "", http.StatusInternalServerError, "Couldn't save the picture."
	}
	return name, 0, ""
}

// profilePicture takes a multipart POST with kind=avatar|banner and either an
// "image" file or remove=1, and answers {"url": "<new link or empty>"}.
func profilePicture(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	session, _ := sessionFromRequest(r)
	uid := session.UserId

	r.Body = http.MaxBytesReader(w, r.Body, maxPictureBytes+(64<<10))
	if err := r.ParseMultipartForm(1 << 20); err != nil {
		http.Error(w, fmt.Sprintf("That picture is too big. Pick one under %d MB.", maxPictureMB), http.StatusRequestEntityTooLarge)
		return
	}
	defer r.MultipartForm.RemoveAll()

	var column string
	kind := r.FormValue("kind")
	switch kind {
	case "avatar":
		column = "pathToProfilePic"
	case "banner":
		column = "pathToBanner"
	case "background":
		column = "pathToBackground"
	case "sitebg":
		column = "siteBgImage"
	default:
		http.Error(w, "Unknown picture.", http.StatusBadRequest)
		return
	}
	var old string
	db.QueryRow("SELECT "+column+" FROM users WHERE id = ?", uid).Scan(&old)

	if r.FormValue("remove") == "1" {
		link := ""
		if kind == "avatar" {
			link = defaultProfilePic
		}
		if _, err := db.Exec("UPDATE users SET "+column+" = ? WHERE id = ?", link, uid); err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't remove the picture.", http.StatusInternalServerError)
			return
		}
		removeOwnPicture(old, uid)
		writeJSON(w, map[string]string{"url": ""})
		return
	}

	file, _, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "Pick a picture first.", http.StatusBadRequest)
		return
	}
	defer file.Close()

	link, status, msg := saveProfileImage(file, uid, kind)
	if status != 0 {
		http.Error(w, msg, status)
		return
	}
	if _, err := db.Exec("UPDATE users SET "+column+" = ? WHERE id = ?", link, uid); err != nil {
		fmt.Println(err)
		removeOwnPicture(link, uid)
		http.Error(w, "Couldn't save the picture.", http.StatusInternalServerError)
		return
	}
	removeOwnPicture(old, uid)
	writeJSON(w, map[string]string{"url": link})
}

var hexColor = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)

// graphColors: GET lists the account's custom graph colors as [{name, color}],
// POST {name, color} sets one, and an empty color goes back to the default.
func graphColors(w http.ResponseWriter, r *http.Request) {
	session, ok := sessionFromRequest(r)

	switch r.Method {
	case http.MethodGet:
		type entry struct {
			Name  string `json:"name"`
			Color string `json:"color"`
		}
		out := []entry{}
		if ok {
			rows, err := db.Query(`
			SELECT CASE WHEN c.display_name != '' THEN c.display_name ELSE d.name END, c.color
			FROM user_drug_color_settings c
			JOIN drugs d ON d.id = c.drug_id
			WHERE c.user_id = ?
			ORDER BY c.id DESC`, session.UserId)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't load your colors.", http.StatusInternalServerError)
				return
			}
			defer rows.Close()
			for rows.Next() {
				var e entry
				if err := rows.Scan(&e.Name, &e.Color); err == nil && hexColor.MatchString(e.Color) {
					out = append(out, e)
				}
			}
		}
		writeJSON(w, out)

	case http.MethodPost:
		if !ok {
			notSignedIn(w, r)
			return
		}
		var in struct {
			Name  string `json:"name"`
			Color string `json:"color"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		name := cleanText(in.Name, 80)
		if name == "" {
			http.Error(w, "Pick a substance.", http.StatusBadRequest)
			return
		}
		key := strings.ToLower(name)

		if in.Color == "" {
			_, err := db.Exec("DELETE FROM user_drug_color_settings WHERE user_id = ? AND drug_id = (SELECT id FROM drugs WHERE name = ?)", session.UserId, key)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save that.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, map[string]string{"name": name, "color": ""})
			return
		}
		if !hexColor.MatchString(in.Color) {
			http.Error(w, "Pick a color like #a67cff.", http.StatusBadRequest)
			return
		}
		color := strings.ToLower(in.Color)

		if _, err := db.Exec("INSERT OR IGNORE INTO drugs (name) VALUES (?)", key); err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't save that.", http.StatusInternalServerError)
			return
		}
		_, err := db.Exec(`INSERT INTO user_drug_color_settings (user_id, drug_id, color, display_name)
			VALUES (?, (SELECT id FROM drugs WHERE name = ?), ?, ?)
			ON CONFLICT(user_id, drug_id) DO UPDATE SET color = excluded.color, display_name = excluded.display_name`,
			session.UserId, key, color, name)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't save that.", http.StatusInternalServerError)
			return
		}
		writeJSON(w, map[string]string{"name": name, "color": color})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// One dose of a graph session, with the duration profile it was drawn
// with so the curve can be redrawn without asking PsychonautWiki again.
type experienceDose struct {
	Substance    string  `json:"substance"`
	Amount       float64 `json:"amount"`
	Unit         string  `json:"unit"`
	Formulation  string  `json:"formulation"`
	ReleaseHours float64 `json:"releaseHours"`
	Time         string  `json:"time"`
	Profile      struct {
		Base struct {
			Onset  float64 `json:"onset"`
			Comeup float64 `json:"comeup"`
			Peak   float64 `json:"peak"`
			Offset float64 `json:"offset"`
		} `json:"base"`
		CommonDose float64 `json:"commonDose"`
	} `json:"profile"`
}

type experience struct {
	ID        int64            `json:"id"`
	StartedAt int64            `json:"startedAt"`
	UpdatedAt int64            `json:"updatedAt"`
	Doses     []experienceDose `json:"doses"`
	// Friends the owner added to the session, and (for a session shared
	// with you) whose session it is.
	People []postAuthor `json:"people"`
	Owner  *postAuthor  `json:"owner,omitempty"`
}

var clockTime = regexp.MustCompile(`^([01]?[0-9]|2[0-3]):[0-5][0-9]$`)

func inRange(v, min, max float64) bool {
	return !math.IsNaN(v) && v >= min && v <= max
}

// cleanExperienceDoses checks every field and drops what the graph could not draw.
func cleanExperienceDoses(in []experienceDose) ([]experienceDose, bool) {
	if len(in) == 0 || len(in) > maxExperienceDoses {
		return nil, false
	}
	out := make([]experienceDose, 0, len(in))
	for _, d := range in {
		d.Substance = cleanText(d.Substance, 80)
		d.Unit = cleanText(d.Unit, 12)
		d.Formulation = cleanText(d.Formulation, 40)
		b := d.Profile.Base
		if d.Substance == "" || !clockTime.MatchString(d.Time) ||
			!inRange(d.Amount, 0.000001, 1e6) || !inRange(d.ReleaseHours, 0, 48) ||
			!inRange(d.Profile.CommonDose, 0.000001, 1e6) ||
			!inRange(b.Onset, 0, 240) || !inRange(b.Comeup, 0, 240) || !inRange(b.Peak, 0, 240) || !inRange(b.Offset, 0, 240) {
			return nil, false
		}
		out = append(out, d)
	}
	return out, true
}

// experiences: GET lists the account's graph sessions, newest first, as
// {signedIn, items}. POST {id, startedAt, doses} saves one (id 0 = new) and
// POST {id, delete: true} removes one.
func experiences(w http.ResponseWriter, r *http.Request) {
	session, ok := sessionFromRequest(r)

	switch r.Method {
	case http.MethodGet:
		items := []experience{}
		if ok {
			rows, err := db.Query(`SELECT id, started_at, updated_at, doses FROM graph_experiences
				WHERE user_id = ? ORDER BY started_at DESC, id DESC LIMIT ?`, session.UserId, maxExperiences)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't load your experiences.", http.StatusInternalServerError)
				return
			}
			defer rows.Close()
			for rows.Next() {
				var e experience
				var doses string
				if err := rows.Scan(&e.ID, &e.StartedAt, &e.UpdatedAt, &doses); err != nil {
					continue
				}
				if json.Unmarshal([]byte(doses), &e.Doses) == nil && len(e.Doses) > 0 {
					items = append(items, e)
				}
			}
			rows.Close()
		}
		shared := []experience{}
		if ok {
			people := sessionPeople("SELECT id FROM graph_experiences WHERE user_id = ?", session.UserId)
			for i := range items {
				items[i].People = orNobody(people[items[i].ID])
			}
			shared = sharedExperiences(session.UserId)
		}
		writeJSON(w, map[string]any{"signedIn": ok, "items": items, "shared": shared})

	case http.MethodPost:
		if !ok {
			notSignedIn(w, r)
			return
		}
		var in struct {
			experience
			Delete bool `json:"delete"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 96<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that session.", http.StatusBadRequest)
			return
		}

		if in.Delete {
			res, err := db.Exec("DELETE FROM graph_experiences WHERE id = ? AND user_id = ?", in.ID, session.UserId)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't delete that.", http.StatusInternalServerError)
				return
			}
			if n, _ := res.RowsAffected(); n > 0 {
				db.Exec("DELETE FROM experience_people WHERE experience_id = ?", in.ID)
			}
			writeJSON(w, map[string]any{"id": in.ID, "deleted": true})
			return
		}

		doses, valid := cleanExperienceDoses(in.Doses)
		if !valid {
			http.Error(w, "That session has a dose the graph can't draw.", http.StatusBadRequest)
			return
		}
		body, _ := json.Marshal(doses)
		now := time.Now().UnixMilli()
		started := in.StartedAt
		if started <= 0 || started > now+86400000 {
			started = now
		}

		saved := false
		if in.ID > 0 {
			res, err := db.Exec("UPDATE graph_experiences SET doses = ?, updated_at = ? WHERE id = ? AND user_id = ?",
				string(body), now, in.ID, session.UserId)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save that session.", http.StatusInternalServerError)
				return
			}
			n, _ := res.RowsAffected()
			saved = n > 0
		}
		if !saved {
			// New, or deleted on another device meanwhile: store it as a new one.
			res, err := db.Exec("INSERT INTO graph_experiences (user_id, started_at, updated_at, doses) VALUES (?, ?, ?, ?)",
				session.UserId, started, now, string(body))
			if err == nil {
				db.Exec("UPDATE users SET graphsMade = graphsMade + 1 WHERE id = ?", session.UserId)
			}
			staleRanks()
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save that session.", http.StatusInternalServerError)
				return
			}
			in.ID, _ = res.LastInsertId()
			db.Exec(`DELETE FROM graph_experiences WHERE user_id = ? AND id NOT IN
				(SELECT id FROM graph_experiences WHERE user_id = ? ORDER BY started_at DESC, id DESC LIMIT ?)`,
				session.UserId, session.UserId, maxExperiences)
			db.Exec("DELETE FROM experience_people WHERE experience_id NOT IN (SELECT id FROM graph_experiences)")
		} else {
			db.QueryRow("SELECT started_at FROM graph_experiences WHERE id = ?", in.ID).Scan(&started)
		}
		people := orNobody(sessionPeople("SELECT ?", in.ID)[in.ID])
		writeJSON(w, experience{ID: in.ID, StartedAt: started, UpdatedAt: now, Doses: doses, People: people})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// profileBox is one box from the + menu on the Profile page. Kind "pictures"
// holds up to 4 pictures, "experience" shows one saved Graph session and
// "note" a few lines of text. Everyone who opens the profile sees them.
type profileBox struct {
	ID         int64       `json:"id"`
	Kind       string      `json:"kind"`
	Pictures   []string    `json:"pictures"`
	Note       string      `json:"note"`
	Experience *experience `json:"experience"`
}

// shown reports whether a box has anything for other people to see.
func (b profileBox) shown() bool {
	switch b.Kind {
	case "note":
		return b.Note != ""
	case "experience":
		return b.Experience != nil
	default:
		return len(b.Pictures) > 0
	}
}

// loadExperience returns one of the account's saved Graph sessions, or nil
// when it was deleted.
func loadExperience(id int64, uid int) *experience {
	e := experience{ID: id}
	var doses string
	if err := db.QueryRow("SELECT started_at, updated_at, doses FROM graph_experiences WHERE id = ? AND user_id = ?", id, uid).Scan(&e.StartedAt, &e.UpdatedAt, &doses); err != nil {
		return nil
	}
	if json.Unmarshal([]byte(doses), &e.Doses) != nil || len(e.Doses) == 0 {
		return nil
	}
	e.People = orNobody(sessionPeople("SELECT ?", id)[id])
	return &e
}

// makeProfileBox turns a profile_boxes row into a box. It looks up the Graph
// session of an experience box, so call it after the rows are closed.
func makeProfileBox(id int64, kind, pictures, data string, owner int) profileBox {
	b := profileBox{ID: id, Kind: kind, Pictures: []string{}}
	switch kind {
	case "note":
		b.Note = data
	case "experience":
		if expID, err := strconv.ParseInt(data, 10, 64); err == nil {
			b.Experience = loadExperience(expID, owner)
		}
	default:
		b.Kind = "pictures"
		if json.Unmarshal([]byte(pictures), &b.Pictures) != nil || b.Pictures == nil {
			b.Pictures = []string{}
		}
	}
	return b
}

func loadPictureBox(id int64, uid int) (profileBox, bool) {
	var kind, pictures, data string
	if err := db.QueryRow("SELECT kind, pictures, data FROM profile_boxes WHERE id = ? AND user_id = ?", id, uid).Scan(&kind, &pictures, &data); err != nil {
		return profileBox{}, false
	}
	return makeProfileBox(id, kind, pictures, data, uid), true
}

func savePictureBox(b profileBox, uid int) error {
	raw, _ := json.Marshal(b.Pictures)
	_, err := db.Exec("UPDATE profile_boxes SET pictures = ? WHERE id = ? AND user_id = ?", string(raw), b.ID, uid)
	return err
}

// profileBoxes: GET lists the account's boxes, or with ?user=<name> the boxes
// that account shows other people. POST JSON {action: "create", kind,
// experience, note}, {action: "note", id, note}, {action: "delete", id} or
// {action: "remove", id, url}; a multipart POST with id and image adds a
// picture to a picture box (4 per box).
func profileBoxes(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	uid := session.UserId

	switch r.Method {
	case http.MethodGet:
		// ?user=<name> is the public view (also when it's the account's own name).
		owner := uid
		name := r.URL.Query().Get("user")
		if name != "" {
			id, ok := userByName(name)
			if !ok {
				http.Error(w, "No account has that name.", http.StatusNotFound)
				return
			}
			owner = id
		}
		type row struct {
			id                   int64
			kind, pictures, data string
		}
		rows, err := db.Query("SELECT id, kind, pictures, data FROM profile_boxes WHERE user_id = ? ORDER BY id", owner)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load the boxes.", http.StatusInternalServerError)
			return
		}
		var found []row
		for rows.Next() {
			var x row
			if err := rows.Scan(&x.id, &x.kind, &x.pictures, &x.data); err == nil {
				found = append(found, x)
			}
		}
		rows.Close()
		var layout string
		db.QueryRow("SELECT profileLayout FROM users WHERE id = ?", owner).Scan(&layout)
		place := map[string]int{}
		for i, key := range profileLayout(layout) {
			place[key] = i
		}
		sort.SliceStable(found, func(a, b int) bool {
			pa, okA := place["b"+strconv.FormatInt(found[a].id, 10)]
			pb, okB := place["b"+strconv.FormatInt(found[b].id, 10)]
			if okA != okB {
				return okA
			}
			return okA && pa < pb
		})
		out := []profileBox{}
		for _, x := range found {
			b := makeProfileBox(x.id, x.kind, x.pictures, x.data, owner)
			if name != "" && !b.shown() {
				continue
			}
			out = append(out, b)
		}
		writeJSON(w, out)

	case http.MethodPost:
		if strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/form-data") {
			r.Body = http.MaxBytesReader(w, r.Body, maxPictureBytes+(64<<10))
			if err := r.ParseMultipartForm(1 << 20); err != nil {
				http.Error(w, fmt.Sprintf("That picture is too big. Pick one under %d MB.", maxPictureMB), http.StatusRequestEntityTooLarge)
				return
			}
			defer r.MultipartForm.RemoveAll()
			id, _ := strconv.ParseInt(r.FormValue("id"), 10, 64)
			box, ok := loadPictureBox(id, uid)
			if !ok || box.Kind != "pictures" {
				http.Error(w, "That box was removed. Reload the page.", http.StatusNotFound)
				return
			}
			if len(box.Pictures) >= picturesPerBox {
				http.Error(w, "This box already has 4 pictures.", http.StatusBadRequest)
				return
			}
			file, _, err := r.FormFile("image")
			if err != nil {
				http.Error(w, "Pick a picture first.", http.StatusBadRequest)
				return
			}
			defer file.Close()
			link, status, msg := saveProfileImage(file, uid, "box")
			if status != 0 {
				http.Error(w, msg, status)
				return
			}
			box.Pictures = append(box.Pictures, link)
			if err := savePictureBox(box, uid); err != nil {
				fmt.Println(err)
				removeOwnPicture(link, uid)
				http.Error(w, "Couldn't save the picture.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, box)
			return
		}

		var in struct {
			Action     string   `json:"action"`
			ID         int64    `json:"id"`
			URL        string   `json:"url"`
			Kind       string   `json:"kind"`
			Note       string   `json:"note"`
			Experience int64    `json:"experience"`
			Order      []string `json:"order"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		switch in.Action {
		case "order":
			// The Profile cards in the order the owner dragged them into:
			// "intake", "totals" and "b<box id>" for their own boxes.
			own := map[string]bool{"intake": true, "totals": true}
			rows, err := db.Query("SELECT id FROM profile_boxes WHERE user_id = ?", uid)
			if err == nil {
				for rows.Next() {
					var id int64
					if rows.Scan(&id) == nil {
						own["b"+strconv.FormatInt(id, 10)] = true
					}
				}
				rows.Close()
			}
			keys := []string{}
			for _, key := range in.Order {
				if own[key] {
					keys = append(keys, key)
					delete(own, key)
				}
			}
			if _, err := db.Exec("UPDATE users SET profileLayout = ? WHERE id = ?", strings.Join(keys, ","), uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the order.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, map[string][]string{"order": keys})
			return
		case "create":
			var n int
			db.QueryRow("SELECT COUNT(*) FROM profile_boxes WHERE user_id = ?", uid).Scan(&n)
			if n >= maxPictureBoxes {
				http.Error(w, "You can have up to 12 boxes.", http.StatusBadRequest)
				return
			}
			kind, data := in.Kind, ""
			switch kind {
			case "", "pictures":
				kind = "pictures"
			case "note":
				data = cleanMultiline(in.Note, maxNoteChars)
			case "experience":
				if loadExperience(in.Experience, uid) == nil {
					http.Error(w, "That Graph session was deleted. Pick another one.", http.StatusNotFound)
					return
				}
				data = strconv.FormatInt(in.Experience, 10)
			default:
				http.Error(w, "Unknown kind of box.", http.StatusBadRequest)
				return
			}
			res, err := db.Exec("INSERT INTO profile_boxes (user_id, pictures, created_at, kind, data) VALUES (?, '[]', ?, ?, ?)", uid, time.Now().UnixMilli(), kind, data)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't add a box.", http.StatusInternalServerError)
				return
			}
			id, _ := res.LastInsertId()
			box, _ := loadPictureBox(id, uid)
			writeJSON(w, box)

		case "note":
			box, ok := loadPictureBox(in.ID, uid)
			if !ok || box.Kind != "note" {
				http.Error(w, "That box was removed. Reload the page.", http.StatusNotFound)
				return
			}
			box.Note = cleanMultiline(in.Note, maxNoteChars)
			if _, err := db.Exec("UPDATE profile_boxes SET data = ? WHERE id = ? AND user_id = ?", box.Note, in.ID, uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the note.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, box)

		case "delete":
			box, ok := loadPictureBox(in.ID, uid)
			if ok {
				if _, err := db.Exec("DELETE FROM profile_boxes WHERE id = ? AND user_id = ?", in.ID, uid); err != nil {
					fmt.Println(err)
					http.Error(w, "Couldn't remove that box.", http.StatusInternalServerError)
					return
				}
				for _, p := range box.Pictures {
					removeOwnPicture(p, uid)
				}
			}
			writeJSON(w, map[string]any{"id": in.ID, "deleted": true})

		case "remove":
			box, ok := loadPictureBox(in.ID, uid)
			if !ok || box.Kind != "pictures" {
				http.Error(w, "That box was removed. Reload the page.", http.StatusNotFound)
				return
			}
			kept := []string{}
			found := false
			for _, p := range box.Pictures {
				if p == in.URL && !found {
					found = true
					continue
				}
				kept = append(kept, p)
			}
			if found {
				box.Pictures = kept
				if err := savePictureBox(box, uid); err != nil {
					fmt.Println(err)
					http.Error(w, "Couldn't remove that picture.", http.StatusInternalServerError)
					return
				}
				removeOwnPicture(in.URL, uid)
			}
			writeJSON(w, box)

		default:
			http.Error(w, "Unknown action.", http.StatusBadRequest)
		}

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// publicProfile serves /u/<name>: what an account shows other members (its
// pictures, boxes, liked substances and Forum posts). The dose calendar,
// recent intake and totals stay on the owner's own Profile page.
func publicProfile(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	name := strings.Trim(strings.TrimPrefix(r.URL.Path, "/u/"), "/")

	d := struct {
		Found      bool
		Name       string
		Initial    string
		Avatar     string
		Banner     string
		Background string
		Clear      int
		ClearAlpha clearAlpha
		NameColor  string
		Admin      bool
		Rank       geekRank
		IsSelf     bool
		Posts      int
		Friend     string
		Liked      []likedSubstance
	}{Name: name}

	var id int
	var avatar, banner, background, authority string
	err := db.QueryRow("SELECT id, originalUsername, pathToProfilePic, pathToBanner, pathToBackground, widgetClear, authority FROM users WHERE username = ?", strings.ToLower(name)).Scan(&id, &d.Name, &avatar, &banner, &background, &d.Clear, &authority)
	d.ClearAlpha = makeClearAlpha(d.Clear)
	if err == nil {
		d.Found = true
		d.Initial = initialOf(d.Name)
		d.Avatar = existingPicture(avatar)
		d.Banner = existingPicture(banner)
		d.Background = existingPicture(background)
		d.Admin = authority == "admin"
		d.NameColor = adminNameColor(d.Name, authority)
		d.Rank = rankOf(d.Name)
		d.IsSelf = id == session.UserId
		d.Friend = friendState(session.UserId, id)
		db.QueryRow("SELECT COUNT(*) FROM forum_posts WHERE user_id = ?", id).Scan(&d.Posts)
		if d.Liked, err = likedSubstances(id); err != nil {
			fmt.Println(err)
		}
	}

	tpl, err := template.ParseFiles("html/user.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
	w.Header().Set("Cache-Control", "no-cache")
	if !d.Found {
		w.WriteHeader(http.StatusNotFound)
	}
	if err := tpl.Execute(w, d); err != nil {
		fmt.Println(err)
	}
}

// Forum serves the Forum page; the posts come from /forum/posts.
func Forum(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	var avatar string
	db.QueryRow("SELECT pathToProfilePic FROM users WHERE id = ?", session.UserId).Scan(&avatar)
	d := struct {
		Name    string
		Initial string
		Avatar  string
	}{session.OriginalUsername, initialOf(session.OriginalUsername), existingPicture(avatar)}

	tpl, err := template.ParseFiles("html/forum.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
	w.Header().Set("Cache-Control", "no-cache")
	if err := tpl.Execute(w, d); err != nil {
		fmt.Println(err)
	}
}

type postAuthor struct {
	Name    string `json:"name"`
	Initial string `json:"initial"`
	Avatar  string `json:"avatar"`
	Admin   bool   `json:"admin"`
	Color   string `json:"color,omitempty"` // an admin's name color
	Rank    int    `json:"rank,omitempty"`  // geek rank tier, 1 to 5
	Level   int    `json:"level,omitempty"` // times the account reached Geek⁴
}

type forumPost struct {
	ID        int64      `json:"id"`
	Author    postAuthor `json:"author"`
	Body      string     `json:"body"`
	Pictures  []string   `json:"pictures"`
	CreatedAt int64      `json:"createdAt"`
	CanDelete bool       `json:"canDelete"`
	Comments  int        `json:"comments"`
}

// forumPosts: GET answers {posts, more} newest first, 20 at a time
// (?before=<id> for older ones, ?user=<name> for one account's posts).
// A multipart POST with body and up to 4 "image" files adds a post;
// POST JSON {action: "delete", id} removes one (its author or an admin).
func forumPosts(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	uid := session.UserId
	isAdmin := session.Authority == "admin"

	switch r.Method {
	case http.MethodGet:
		q := r.URL.Query()
		before, _ := strconv.ParseInt(q.Get("before"), 10, 64)
		only, _ := strconv.ParseInt(q.Get("id"), 10, 64) // ?id= answers just that post (letter icon links)
		owner := 0
		if name := q.Get("user"); name != "" {
			id, ok := userByName(name)
			if !ok {
				http.Error(w, "No account has that name.", http.StatusNotFound)
				return
			}
			owner = id
		}
		rows, err := db.Query(`
		SELECT p.id, p.user_id, p.body, p.pictures, p.created_at, u.originalUsername, u.pathToProfilePic, u.authority,
			(SELECT COUNT(*) FROM forum_comments c WHERE c.post_id = p.id)
		FROM forum_posts p
		JOIN users u ON u.id = p.user_id
		WHERE (? = 0 OR p.id < ?) AND (? = 0 OR p.user_id = ?) AND (? = 0 OR p.id = ?)
		ORDER BY p.id DESC
		LIMIT ?`, before, before, owner, owner, only, only, postsPerPage+1)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load the posts.", http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		avatars := map[int]string{}
		posts := []forumPost{}
		for rows.Next() {
			var p forumPost
			var author int
			var pictures, avatar, authority string
			if err := rows.Scan(&p.ID, &author, &p.Body, &pictures, &p.CreatedAt, &p.Author.Name, &avatar, &authority, &p.Comments); err != nil {
				continue
			}
			if _, seen := avatars[author]; !seen {
				avatars[author] = existingPicture(avatar)
			}
			p.Author.Avatar = avatars[author]
			p.Author.Initial = initialOf(p.Author.Name)
			p.Author.Admin = authority == "admin"
			p.Author.Color = adminNameColor(p.Author.Name, authority)
			p.Author.Rank, p.Author.Level = rankOf(p.Author.Name).Tier, rankOf(p.Author.Name).Level
			if json.Unmarshal([]byte(pictures), &p.Pictures) != nil || p.Pictures == nil {
				p.Pictures = []string{}
			}
			p.CanDelete = author == uid || isAdmin
			posts = append(posts, p)
		}
		more := len(posts) > postsPerPage
		if more {
			posts = posts[:postsPerPage]
		}
		writeJSON(w, map[string]any{"posts": posts, "more": more})

	case http.MethodPost:
		if strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/form-data") {
			r.Body = http.MaxBytesReader(w, r.Body, picturesPerPost*maxPictureBytes+(64<<10))
			if err := r.ParseMultipartForm(1 << 20); err != nil {
				http.Error(w, fmt.Sprintf("That post is too big. Each picture has to be under %d MB.", maxPictureMB), http.StatusRequestEntityTooLarge)
				return
			}
			defer r.MultipartForm.RemoveAll()
			body := cleanMultiline(r.FormValue("body"), maxPostChars)
			files := r.MultipartForm.File["image"]
			if len(files) > picturesPerPost {
				http.Error(w, "A post can have up to 4 pictures.", http.StatusBadRequest)
				return
			}
			if body == "" && len(files) == 0 {
				http.Error(w, "Write something or add a picture first.", http.StatusBadRequest)
				return
			}
			var recent int
			db.QueryRow("SELECT COUNT(*) FROM forum_posts WHERE user_id = ? AND created_at > ?", uid, time.Now().Add(-10*time.Minute).UnixMilli()).Scan(&recent)
			if recent >= postsPer10Minutes {
				http.Error(w, "You've posted a lot just now. Wait a few minutes and try again.", http.StatusTooManyRequests)
				return
			}

			saved := []string{}
			fail := func(status int, msg string) {
				for _, link := range saved {
					removeOwnPicture(link, uid)
				}
				http.Error(w, msg, status)
			}
			for _, header := range files {
				if header.Size > maxPictureBytes {
					fail(http.StatusRequestEntityTooLarge, fmt.Sprintf("Each picture has to be under %d MB.", maxPictureMB))
					return
				}
				file, err := header.Open()
				if err != nil {
					fail(http.StatusBadRequest, "Couldn't read one of the pictures.")
					return
				}
				link, status, msg := saveProfileImage(file, uid, "post")
				file.Close()
				if status != 0 {
					fail(status, msg)
					return
				}
				saved = append(saved, link)
			}
			raw, _ := json.Marshal(saved)
			now := time.Now().UnixMilli()
			res, err := db.Exec("INSERT INTO forum_posts (user_id, body, pictures, created_at) VALUES (?, ?, ?, ?)", uid, body, string(raw), now)
			if err == nil {
				db.Exec("UPDATE users SET postsMade = postsMade + 1 WHERE id = ?", uid)
			}
			staleRanks()
			if err != nil {
				fmt.Println(err)
				fail(http.StatusInternalServerError, "Couldn't save your post.")
				return
			}
			id, _ := res.LastInsertId()
			var avatar string
			db.QueryRow("SELECT pathToProfilePic FROM users WHERE id = ?", uid).Scan(&avatar)
			writeJSON(w, forumPost{
				ID:        id,
				Author:    postAuthor{Name: session.OriginalUsername, Initial: initialOf(session.OriginalUsername), Avatar: existingPicture(avatar), Admin: isAdmin, Color: adminNameColor(session.OriginalUsername, session.Authority), Rank: rankOf(session.OriginalUsername).Tier, Level: rankOf(session.OriginalUsername).Level},
				Body:      body,
				Pictures:  saved,
				CreatedAt: now,
				CanDelete: true,
			})
			return
		}

		var in struct {
			Action string `json:"action"`
			ID     int64  `json:"id"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&in); err != nil || in.Action != "delete" {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		var author int
		var pictures string
		err := db.QueryRow("SELECT user_id, pictures FROM forum_posts WHERE id = ?", in.ID).Scan(&author, &pictures)
		if err == sql.ErrNoRows {
			writeJSON(w, map[string]any{"id": in.ID, "deleted": true})
			return
		}
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't delete that post.", http.StatusInternalServerError)
			return
		}
		if author != uid && !isAdmin {
			http.Error(w, "You can only delete your own posts.", http.StatusForbidden)
			return
		}
		if _, err := db.Exec("DELETE FROM forum_posts WHERE id = ?", in.ID); err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't delete that post.", http.StatusInternalServerError)
			return
		}
		db.Exec("DELETE FROM forum_comments WHERE post_id = ?", in.ID)
		var links []string
		json.Unmarshal([]byte(pictures), &links)
		for _, link := range links {
			removeOwnPicture(link, author)
		}
		writeJSON(w, map[string]any{"id": in.ID, "deleted": true})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// forumMembers lists every account for the Forum's Members box, as
// [{name, initial, avatar, admin, posts}].
func forumMembers(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	rows, err := db.Query(`
	SELECT u.id, u.originalUsername, u.pathToProfilePic, u.authority,
		(SELECT COUNT(*) FROM forum_posts p WHERE p.user_id = u.id)
	FROM users u
	ORDER BY lower(u.originalUsername)
	LIMIT 500`)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Couldn't load the members.", http.StatusInternalServerError)
		return
	}
	type member struct {
		postAuthor
		Posts  int    `json:"posts"`
		Friend string `json:"friend"`
		Self   bool   `json:"self"`
	}
	type found struct {
		member
		id int
	}
	var list []found
	for rows.Next() {
		var m found
		var avatar, authority string
		if err := rows.Scan(&m.id, &m.Name, &avatar, &authority, &m.Posts); err != nil {
			continue
		}
		m.Initial = initialOf(m.Name)
		m.Avatar = existingPicture(avatar)
		m.Admin = authority == "admin"
		m.Color = adminNameColor(m.Name, authority)
		m.Rank, m.Level = rankOf(m.Name).Tier, rankOf(m.Name).Level
		list = append(list, m)
	}
	rows.Close()
	session, _ := sessionFromRequest(r)
	states := friendStates(session.UserId)
	out := []member{}
	for _, m := range list {
		m.Friend = states[m.id]
		m.Self = m.id == session.UserId
		out = append(out, m.member)
	}
	writeJSON(w, out)
}

// person is how an account is shown next to posts, comments and friends.
func person(name, avatar, authority string) postAuthor {
	return postAuthor{Name: name, Initial: initialOf(name), Avatar: existingPicture(avatar), Admin: authority == "admin", Color: adminNameColor(name, authority), Rank: rankOf(name).Tier, Level: rankOf(name).Level}
}

// profileAppearance reads (GET) or saves (POST JSON) the account's site color
// and Profile card transparency. Fields left out of a POST stay as they are;
// an empty color goes back to the default violet.
func profileAppearance(w http.ResponseWriter, r *http.Request) {
	session, ok := sessionFromRequest(r)
	if !ok {
		http.Error(w, "Log in first.", http.StatusUnauthorized)
		return
	}
	uid := session.UserId
	if r.Method == http.MethodPost {
		var in struct {
			SiteColor   *string `json:"siteColor"`
			WidgetClear *int    `json:"widgetClear"`
			NameColor   *string `json:"nameColor"`
			SiteBg      *string `json:"siteBg"`
			SiteBgDim   *int    `json:"siteBgDim"`
		}
		if err := json.NewDecoder(io.LimitReader(r.Body, 4<<10)).Decode(&in); err != nil {
			http.Error(w, "Bad request.", http.StatusBadRequest)
			return
		}
		if in.SiteColor != nil {
			color := strings.ToLower(strings.TrimSpace(*in.SiteColor))
			if color != "" && !hexColor.MatchString(color) {
				http.Error(w, "Pick a color like #a67cff.", http.StatusBadRequest)
				return
			}
			if _, err := db.Exec("UPDATE users SET siteColor = ? WHERE id = ?", color, uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the color.", http.StatusInternalServerError)
				return
			}
		}
		if in.NameColor != nil {
			color := strings.ToLower(strings.TrimSpace(*in.NameColor))
			if session.Authority != "admin" {
				http.Error(w, "Only admins can color their name.", http.StatusForbidden)
				return
			}
			if color != "" && !hexColor.MatchString(color) {
				http.Error(w, "Pick a color like #a67cff.", http.StatusBadRequest)
				return
			}
			if _, err := db.Exec("UPDATE users SET nameColor = ? WHERE id = ?", color, uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the name color.", http.StatusInternalServerError)
				return
			}
			loadNameColors()
		}
		if in.SiteBg != nil {
			scene := strings.TrimSpace(*in.SiteBg)
			if !siteScenes[scene] {
				http.Error(w, "Unknown background.", http.StatusBadRequest)
				return
			}
			if _, err := db.Exec("UPDATE users SET siteBg = ? WHERE id = ?", scene, uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the background.", http.StatusInternalServerError)
				return
			}
		}
		if in.SiteBgDim != nil {
			if _, err := db.Exec("UPDATE users SET siteBgDim = ? WHERE id = ?", min(max(*in.SiteBgDim, 0), 90), uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the background.", http.StatusInternalServerError)
				return
			}
		}
		if in.WidgetClear != nil {
			clear := min(max(*in.WidgetClear, 0), 100)
			if _, err := db.Exec("UPDATE users SET widgetClear = ? WHERE id = ?", clear, uid); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save the transparency.", http.StatusInternalServerError)
				return
			}
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed.", http.StatusMethodNotAllowed)
		return
	}
	var out struct {
		SiteColor   string `json:"siteColor"`
		WidgetClear int    `json:"widgetClear"`
		NameColor   string `json:"nameColor"`
		SiteBg      string `json:"siteBg"`
		SiteBgImage string `json:"siteBgImage"`
		SiteBgDim   int    `json:"siteBgDim"`
	}
	db.QueryRow("SELECT siteColor, widgetClear, nameColor, siteBg, siteBgImage, siteBgDim FROM users WHERE id = ?", uid).Scan(&out.SiteColor, &out.WidgetClear, &out.NameColor, &out.SiteBg, &out.SiteBgImage, &out.SiteBgDim)
	out.SiteBgImage = existingPicture(out.SiteBgImage)
	writeJSON(w, out)
}

// profileLayout splits the stored card order ("intake,totals,b12") into keys.
func profileLayout(stored string) []string {
	keys := []string{}
	for _, key := range strings.Split(stored, ",") {
		if key = strings.TrimSpace(key); key != "" {
			keys = append(keys, key)
		}
	}
	return keys
}

// orNobody makes a missing list an empty one, so the JSON says [] and not null.
func orNobody(people []postAuthor) []postAuthor {
	if people == nil {
		return []postAuthor{}
	}
	return people
}

// sessionPeople returns the friends added to each Graph session that the
// subquery idQuery (with one ? argument) lists, keyed by session id.
func sessionPeople(idQuery string, arg any) map[int64][]postAuthor {
	out := map[int64][]postAuthor{}
	rows, err := db.Query(`
	SELECT p.experience_id, u.originalUsername, u.pathToProfilePic, u.authority
	FROM experience_people p
	JOIN users u ON u.id = p.user_id
	WHERE p.experience_id IN (`+idQuery+`)
	ORDER BY p.added_at, lower(u.originalUsername)`, arg)
	if err != nil {
		fmt.Println(err)
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var name, avatar, authority string
		if err := rows.Scan(&id, &name, &avatar, &authority); err == nil {
			out[id] = append(out[id], person(name, avatar, authority))
		}
	}
	return out
}

// sharedExperiences lists the Graph sessions friends added this account to.
func sharedExperiences(uid int) []experience {
	out := []experience{}
	rows, err := db.Query(`
	SELECT e.id, e.started_at, e.updated_at, e.doses, u.originalUsername, u.pathToProfilePic, u.authority
	FROM experience_people p
	JOIN graph_experiences e ON e.id = p.experience_id
	JOIN users u ON u.id = e.user_id
	WHERE p.user_id = ?
	ORDER BY e.started_at DESC, e.id DESC
	LIMIT 100`, uid)
	if err != nil {
		fmt.Println(err)
		return out
	}
	for rows.Next() {
		var e experience
		var doses, name, avatar, authority string
		if err := rows.Scan(&e.ID, &e.StartedAt, &e.UpdatedAt, &doses, &name, &avatar, &authority); err != nil {
			continue
		}
		if json.Unmarshal([]byte(doses), &e.Doses) != nil || len(e.Doses) == 0 {
			continue
		}
		owner := person(name, avatar, authority)
		e.Owner = &owner
		out = append(out, e)
	}
	rows.Close()
	people := sessionPeople("SELECT experience_id FROM experience_people WHERE user_id = ?", uid)
	var me string
	db.QueryRow("SELECT originalUsername FROM users WHERE id = ?", uid).Scan(&me)
	for i := range out {
		// The others who were there; you know you were.
		out[i].People = []postAuthor{}
		for _, p := range people[out[i].ID] {
			if p.Name != me {
				out[i].People = append(out[i].People, p)
			}
		}
	}
	return out
}

// friendState says how other relates to me: "friends", "outgoing" (I asked),
// "incoming" (they asked) or "".
func friendState(me, other int) string {
	var from int
	var status string
	err := db.QueryRow(`SELECT requester_id, status FROM friendships
		WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)
		ORDER BY status = 'accepted' DESC LIMIT 1`, me, other, other, me).Scan(&from, &status)
	switch {
	case err != nil:
		return ""
	case status == "accepted":
		return "friends"
	case from == me:
		return "outgoing"
	default:
		return "incoming"
	}
}

// friendStates is friendState for every account me has a friendship with.
func friendStates(me int) map[int]string {
	out := map[int]string{}
	rows, err := db.Query("SELECT requester_id, addressee_id, status FROM friendships WHERE requester_id = ? OR addressee_id = ?", me, me)
	if err != nil {
		fmt.Println(err)
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var from, to int
		var status string
		if rows.Scan(&from, &to, &status) != nil {
			continue
		}
		other := to
		if to == me {
			other = from
		}
		switch {
		case status == "accepted":
			out[other] = "friends"
		case out[other] == "friends":
		case from == me:
			out[other] = "outgoing"
		default:
			out[other] = "incoming"
		}
	}
	return out
}

// friends: GET answers {friends, incoming, outgoing}. POST {action, user},
// action being request, accept, decline, cancel or remove, answers {state}.
func friends(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	me := session.UserId

	switch r.Method {
	case http.MethodGet:
		out := map[string][]postAuthor{"friends": {}, "incoming": {}, "outgoing": {}}
		rows, err := db.Query(`
		SELECT f.requester_id, f.status, u.originalUsername, u.pathToProfilePic, u.authority
		FROM friendships f
		JOIN users u ON u.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END
		WHERE f.requester_id = ? OR f.addressee_id = ?
		ORDER BY lower(u.originalUsername)`, me, me, me)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load your friends.", http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		for rows.Next() {
			var from int
			var status, name, avatar, authority string
			if rows.Scan(&from, &status, &name, &avatar, &authority) != nil {
				continue
			}
			key := "friends"
			if status != "accepted" {
				key = "incoming"
				if from == me {
					key = "outgoing"
				}
			}
			out[key] = append(out[key], person(name, avatar, authority))
		}
		writeJSON(w, out)

	case http.MethodPost:
		var in struct {
			Action string `json:"action"`
			User   string `json:"user"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		other, ok := userByName(in.User)
		if !ok {
			http.Error(w, "No account has that name.", http.StatusNotFound)
			return
		}
		if other == me {
			http.Error(w, "That's your own account.", http.StatusBadRequest)
			return
		}
		state := friendState(me, other)
		var err error
		switch in.Action {
		case "request":
			switch state {
			case "incoming":
				// They already asked, so asking back makes you friends.
				_, err = db.Exec("UPDATE friendships SET status = 'accepted' WHERE requester_id = ? AND addressee_id = ?", other, me)
				state = "friends"
			case "":
				var waiting int
				db.QueryRow("SELECT COUNT(*) FROM friendships WHERE requester_id = ? AND status = 'pending'", me).Scan(&waiting)
				if waiting >= 100 {
					http.Error(w, "You have 100 friend requests waiting. Cancel some first.", http.StatusBadRequest)
					return
				}
				_, err = db.Exec("INSERT INTO friendships (requester_id, addressee_id, status, created_at) VALUES (?, ?, 'pending', ?)", me, other, time.Now().UnixMilli())
				state = "outgoing"
			}
		case "accept":
			if state != "incoming" && state != "friends" {
				http.Error(w, "That friend request was cancelled.", http.StatusConflict)
				return
			}
			_, err = db.Exec("UPDATE friendships SET status = 'accepted' WHERE requester_id = ? AND addressee_id = ?", other, me)
			state = "friends"
		case "decline":
			if state == "incoming" {
				_, err = db.Exec("DELETE FROM friendships WHERE requester_id = ? AND addressee_id = ?", other, me)
				state = ""
			}
		case "cancel":
			if state == "outgoing" {
				_, err = db.Exec("DELETE FROM friendships WHERE requester_id = ? AND addressee_id = ?", me, other)
				state = ""
			}
		case "remove":
			if state == "friends" {
				_, err = db.Exec("DELETE FROM friendships WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)", me, other, other, me)
				// They also leave each other's Graph sessions.
				db.Exec(`DELETE FROM experience_people WHERE
					(user_id = ? AND experience_id IN (SELECT id FROM graph_experiences WHERE user_id = ?)) OR
					(user_id = ? AND experience_id IN (SELECT id FROM graph_experiences WHERE user_id = ?))`, other, me, me, other)
				state = ""
			}
		default:
			http.Error(w, "Unknown action.", http.StatusBadRequest)
			return
		}
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't change that. Try again.", http.StatusInternalServerError)
			return
		}
		writeJSON(w, map[string]string{"state": state})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// experiencePeople: POST {id, people: [names]} sets which friends were part
// of one of your Graph sessions, and answers {id, people}. Those friends see
// the session under "Shared with you" on their Graph page.
func experiencePeople(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	session, _ := sessionFromRequest(r)
	me := session.UserId
	var in struct {
		ID     int64    `json:"id"`
		People []string `json:"people"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&in); err != nil {
		http.Error(w, "Couldn't read that.", http.StatusBadRequest)
		return
	}
	var owner int
	if err := db.QueryRow("SELECT user_id FROM graph_experiences WHERE id = ?", in.ID).Scan(&owner); err != nil || owner != me {
		http.Error(w, "That session was deleted. Reload the page.", http.StatusNotFound)
		return
	}
	if len(in.People) > maxExperiencePeople {
		http.Error(w, "A session can have up to 20 people.", http.StatusBadRequest)
		return
	}
	var ids []int
	seen := map[int]bool{}
	for _, name := range in.People {
		id, ok := userByName(name)
		if !ok || id == me || seen[id] {
			continue
		}
		if friendState(me, id) != "friends" {
			http.Error(w, "You can only add friends, and "+cleanText(name, 40)+" isn't one.", http.StatusForbidden)
			return
		}
		seen[id] = true
		ids = append(ids, id)
	}

	tx, err := db.Begin()
	if err == nil {
		_, err = tx.Exec("DELETE FROM experience_people WHERE experience_id = ?", in.ID)
		now := time.Now().UnixMilli()
		for i, id := range ids {
			if err != nil {
				break
			}
			_, err = tx.Exec("INSERT INTO experience_people (experience_id, user_id, added_at) VALUES (?, ?, ?)", in.ID, id, now+int64(i))
		}
		if err == nil {
			err = tx.Commit()
		} else {
			tx.Rollback()
		}
	}
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Couldn't save who was there. Try again.", http.StatusInternalServerError)
		return
	}
	people := orNobody(sessionPeople("SELECT ?", in.ID)[in.ID])
	if people == nil {
		people = []postAuthor{}
	}
	writeJSON(w, map[string]any{"id": in.ID, "people": people})
}

type forumComment struct {
	ID        int64      `json:"id"`
	Author    postAuthor `json:"author"`
	Body      string     `json:"body"`
	CreatedAt int64      `json:"createdAt"`
	CanDelete bool       `json:"canDelete"`
}

// forumComments: GET ?post=<id> lists a post's comments, oldest first.
// POST JSON {action: "add", post, body} adds one and {action: "delete", id}
// removes one (its author, the post's author or an admin).
func forumComments(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	me := session.UserId
	isAdmin := session.Authority == "admin"

	switch r.Method {
	case http.MethodGet:
		postID, _ := strconv.ParseInt(r.URL.Query().Get("post"), 10, 64)
		var postAuthorID int
		if err := db.QueryRow("SELECT user_id FROM forum_posts WHERE id = ?", postID).Scan(&postAuthorID); err != nil {
			http.Error(w, "That post was deleted.", http.StatusNotFound)
			return
		}
		rows, err := db.Query(`
		SELECT c.id, c.user_id, c.body, c.created_at, u.originalUsername, u.pathToProfilePic, u.authority
		FROM forum_comments c
		JOIN users u ON u.id = c.user_id
		WHERE c.post_id = ?
		ORDER BY c.id
		LIMIT 500`, postID)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load the comments.", http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		out := []forumComment{}
		for rows.Next() {
			var c forumComment
			var author int
			var name, avatar, authority string
			if rows.Scan(&c.ID, &author, &c.Body, &c.CreatedAt, &name, &avatar, &authority) != nil {
				continue
			}
			c.Author = person(name, avatar, authority)
			c.CanDelete = author == me || postAuthorID == me || isAdmin
			out = append(out, c)
		}
		writeJSON(w, out)

	case http.MethodPost:
		var in struct {
			Action string `json:"action"`
			Post   int64  `json:"post"`
			ID     int64  `json:"id"`
			Body   string `json:"body"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		switch in.Action {
		case "add":
			body := cleanMultiline(in.Body, maxCommentChars)
			if body == "" {
				http.Error(w, "Write something first.", http.StatusBadRequest)
				return
			}
			var postAuthorID int
			if err := db.QueryRow("SELECT user_id FROM forum_posts WHERE id = ?", in.Post).Scan(&postAuthorID); err != nil {
				http.Error(w, "That post was deleted.", http.StatusNotFound)
				return
			}
			var recent int
			db.QueryRow("SELECT COUNT(*) FROM forum_comments WHERE user_id = ? AND created_at > ?", me, time.Now().Add(-10*time.Minute).UnixMilli()).Scan(&recent)
			if recent >= commentsPer10Minutes {
				http.Error(w, "You've commented a lot just now. Wait a few minutes and try again.", http.StatusTooManyRequests)
				return
			}
			now := time.Now().UnixMilli()
			res, err := db.Exec("INSERT INTO forum_comments (post_id, user_id, body, created_at) VALUES (?, ?, ?, ?)", in.Post, me, body, now)
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't save your comment.", http.StatusInternalServerError)
				return
			}
			id, _ := res.LastInsertId()
			var avatar, authority string
			db.QueryRow("SELECT pathToProfilePic, authority FROM users WHERE id = ?", me).Scan(&avatar, &authority)
			writeJSON(w, forumComment{ID: id, Author: person(session.OriginalUsername, avatar, authority), Body: body, CreatedAt: now, CanDelete: true})

		case "delete":
			var author, postAuthorID int
			err := db.QueryRow("SELECT c.user_id, p.user_id FROM forum_comments c JOIN forum_posts p ON p.id = c.post_id WHERE c.id = ?", in.ID).Scan(&author, &postAuthorID)
			if err == sql.ErrNoRows {
				writeJSON(w, map[string]any{"id": in.ID, "deleted": true})
				return
			}
			if err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't delete that comment.", http.StatusInternalServerError)
				return
			}
			if author != me && postAuthorID != me && !isAdmin {
				http.Error(w, "You can only delete your own comments.", http.StatusForbidden)
				return
			}
			if _, err := db.Exec("DELETE FROM forum_comments WHERE id = ?", in.ID); err != nil {
				fmt.Println(err)
				http.Error(w, "Couldn't delete that comment.", http.StatusInternalServerError)
				return
			}
			writeJSON(w, map[string]any{"id": in.ID, "deleted": true})

		default:
			http.Error(w, "Unknown action.", http.StatusBadRequest)
		}

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// ---- Files access for members (picked on the admin page) ----

// filesGrant is what an account may do in Files. Admins can do everything;
// a member listed in file_access can open the folders picked for them (and
// everything inside), and with CanEdit upload, rename and delete in there.
type filesGrant struct {
	All     bool     `json:"all"`
	Folders []string `json:"folders"`
	CanEdit bool     `json:"canEdit"`
}

// filesGrantFor answers the account's grant, and false when it has no access at all.
func filesGrantFor(s cookiesStruct) (filesGrant, bool) {
	if s.Authority == "admin" {
		return filesGrant{All: true, CanEdit: true}, true
	}
	if s.UserId == 0 {
		return filesGrant{}, false
	}
	var all, edit int
	var folders string
	if err := db.QueryRow("SELECT all_folders, folders, can_edit FROM file_access WHERE user_id = ?", s.UserId).Scan(&all, &folders, &edit); err != nil {
		return filesGrant{}, false
	}
	g := filesGrant{All: all == 1, CanEdit: edit == 1}
	json.Unmarshal([]byte(folders), &g.Folders)
	return g, true
}

func filesGrantOf(r *http.Request) filesGrant {
	session, _ := sessionFromRequest(r)
	g, _ := filesGrantFor(session)
	return g
}

// uploadRel is a path inside UploadedFiles as "a/b" ("" for the folder itself).
func uploadRel(p string) string {
	rel, err := filepath.Rel(UploadedFilesDirName, p)
	if err != nil || rel == "." {
		return ""
	}
	return filepath.ToSlash(rel)
}

func joinRel(dir, name string) string {
	if dir == "" {
		return name
	}
	return dir + "/" + name
}

// allows: rel is one of the granted folders or inside one.
func (g filesGrant) allows(rel string) bool {
	if g.All {
		return true
	}
	for _, f := range g.Folders {
		if rel == f || strings.HasPrefix(rel, f+"/") {
			return true
		}
	}
	return false
}

// canSee: rel can be listed, either because it is allowed or because a
// granted folder is somewhere below it (so the member can walk down to it).
func (g filesGrant) canSee(rel string) bool {
	if g.allows(rel) {
		return true
	}
	for _, f := range g.Folders {
		if rel == "" || strings.HasPrefix(f, rel+"/") {
			return true
		}
	}
	return false
}

// canChangeIn: new files and folders may go into the folder rel.
func (g filesGrant) canChangeIn(rel string) bool {
	return g.CanEdit && g.allows(rel)
}

// canChange: the item rel may be renamed or deleted (never a granted folder itself).
func (g filesGrant) canChange(rel string) bool {
	if !g.CanEdit || rel == "" {
		return false
	}
	if g.All {
		return true
	}
	for _, f := range g.Folders {
		if strings.HasPrefix(rel, f+"/") {
			return true
		}
	}
	return false
}

// visible drops the items the member may not see. dir is the listed folder,
// or "" when the items carry their own full /Files/ links (search results).
func (g filesGrant) visible(items []FileFolderInfo, dir string) []FileFolderInfo {
	if g.All {
		return items
	}
	out := []FileFolderInfo{}
	for _, it := range items {
		rel := joinRel(dir, it.Name)
		if dir == "" {
			if p, ok := uploadPathFromURL(it.Path); ok {
				rel = uploadRel(p)
			}
		}
		if it.IsDir && g.canSee(rel) || !it.IsDir && g.allows(rel) {
			out = append(out, it)
		}
	}
	return out
}

// requireFilesLogin lets in admins and the members an admin gave Files access.
func requireFilesLogin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		d, ok := sessionFromRequest(r)
		if !ok {
			notSignedIn(w, r)
			return
		}
		if r.Method == http.MethodGet {
			setRoleHint(w, r, d, true)
		}
		if _, ok := filesGrantFor(d); !ok {
			fmt.Printf("[%s] DENY IP=%s USER=%s PATH=%s REASON=no_files_access\n", time.Now().Format("2006-01-02 15:04:05"), clientIP(r), d.OriginalUsername, r.URL.Path)
			if r.Method == http.MethodGet {
				http.Redirect(w, r, "/Main?need=files", http.StatusSeeOther)
			} else {
				http.Error(w, "You don't have access to Files.", http.StatusForbidden)
			}
			return
		}
		next(w, r)
	}
}

// uploadFolders lists the folders in UploadedFiles (three levels deep, at most 400).
func uploadFolders() []string {
	out := []string{}
	var walk func(dir, rel string, depth int)
	walk = func(dir, rel string, depth int) {
		entries, err := os.ReadDir(dir)
		if err != nil {
			return
		}
		for _, e := range entries {
			if !e.IsDir() || len(out) >= 400 {
				continue
			}
			r := joinRel(rel, e.Name())
			out = append(out, r)
			if depth < 3 {
				walk(filepath.Join(dir, e.Name()), r, depth+1)
			}
		}
	}
	walk(UploadedFilesDirName, "", 1)
	sort.Strings(out)
	return out
}

// adminFilesAccess: GET lists the accounts with their Files access and the
// folders to pick from; POST {user, access} sets one account's access
// (access null takes it away).
func adminFilesAccess(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		type row struct {
			ID     int         `json:"id"`
			Name   string      `json:"name"`
			Admin  bool        `json:"admin"`
			Access *filesGrant `json:"access"`
		}
		rows, err := db.Query("SELECT id, originalUsername, authority FROM users ORDER BY lower(originalUsername) LIMIT 1000")
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load the accounts.", http.StatusInternalServerError)
			return
		}
		var list []row
		for rows.Next() {
			var x row
			var authority string
			if rows.Scan(&x.ID, &x.Name, &authority) == nil {
				x.Admin = authority == "admin"
				list = append(list, x)
			}
		}
		rows.Close()
		for i := range list {
			if g, ok := filesGrantFor(cookiesStruct{UserId: list[i].ID, Authority: map[bool]string{true: "admin", false: "user"}[list[i].Admin]}); ok {
				if g.Folders == nil {
					g.Folders = []string{}
				}
				list[i].Access = &g
			}
		}
		writeJSON(w, map[string]any{"users": list, "folders": uploadFolders()})

	case http.MethodPost:
		var in struct {
			User   int         `json:"user"`
			Access *filesGrant `json:"access"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(&in); err != nil {
			http.Error(w, "Couldn't read that.", http.StatusBadRequest)
			return
		}
		var authority string
		if err := db.QueryRow("SELECT authority FROM users WHERE id = ?", in.User).Scan(&authority); err != nil {
			http.Error(w, "That account doesn't exist.", http.StatusNotFound)
			return
		}
		if authority == "admin" {
			http.Error(w, "Admins can always open every folder.", http.StatusBadRequest)
			return
		}
		if in.Access == nil {
			db.Exec("DELETE FROM file_access WHERE user_id = ?", in.User)
			writeJSON(w, map[string]any{"user": in.User, "access": nil})
			return
		}
		// Only real folders inside UploadedFiles, written as "a/b", each once.
		folders := []string{}
		seen := map[string]bool{}
		for _, f := range in.Access.Folders {
			p, ok := insideUploads(strings.Split(strings.Trim(filepath.ToSlash(f), "/"), "/")...)
			rel := uploadRel(p)
			if !ok || rel == "" || seen[rel] {
				continue
			}
			if info, err := os.Stat(p); err != nil || !info.IsDir() {
				continue
			}
			seen[rel] = true
			folders = append(folders, rel)
			if len(folders) >= 100 {
				break
			}
		}
		g := filesGrant{All: in.Access.All, Folders: folders, CanEdit: in.Access.CanEdit}
		if g.All {
			g.Folders = []string{}
		}
		list, _ := json.Marshal(g.Folders)
		all, edit := 0, 0
		if g.All {
			all = 1
		}
		if g.CanEdit {
			edit = 1
		}
		if _, err := db.Exec(`INSERT INTO file_access (user_id, all_folders, folders, can_edit) VALUES (?, ?, ?, ?)
			ON CONFLICT(user_id) DO UPDATE SET all_folders = excluded.all_folders, folders = excluded.folders, can_edit = excluded.can_edit`, in.User, all, string(list), edit); err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't save the access.", http.StatusInternalServerError)
			return
		}
		writeJSON(w, map[string]any{"user": in.User, "access": g})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// ---- Admin name colors ----

var nameColorsMu sync.RWMutex
var nameColors = map[string]string{} // lower-case name -> color, admins only

func loadNameColors() {
	m := map[string]string{}
	if rows, err := db.Query("SELECT originalUsername, nameColor FROM users WHERE authority = 'admin' AND nameColor != ''"); err == nil {
		for rows.Next() {
			var name, color string
			if rows.Scan(&name, &color) == nil && hexColor.MatchString(color) {
				m[strings.ToLower(name)] = color
			}
		}
		rows.Close()
	}
	nameColorsMu.Lock()
	nameColors = m
	nameColorsMu.Unlock()
}

// adminNameColor is the color an admin picked for their name ("" for everyone else).
func adminNameColor(name, authority string) string {
	if authority != "admin" {
		return ""
	}
	nameColorsMu.RLock()
	defer nameColorsMu.RUnlock()
	return nameColors[strings.ToLower(name)]
}

// ---- Main page pictures (admins can swap them) ----

var sitePictureSlots = map[string]string{
	"member1": "/hookey.jpg",
	"member2": "/tepz.jpg",
}

var sitePicturesDir = filepath.Join(ProfilePicturesDirName, "site")

// sitePictureLink is the link Main uses for a slot: the uploaded picture
// (with a version so browsers fetch a new one) or the original file.
func sitePictureLink(slot string) string {
	var path string
	if db.QueryRow("SELECT path FROM site_pictures WHERE slot = ?", slot).Scan(&path) == nil {
		if info, err := os.Stat(filepath.Join(sitePicturesDir, filepath.Base(path))); err == nil && !info.IsDir() {
			return "/sitepic/" + slot + "?v=" + strconv.FormatInt(info.ModTime().UnixMilli(), 36)
		}
	}
	return sitePictureSlots[slot]
}

// sitePicture serves an uploaded Main picture to everyone (Main is public).
func sitePicture(w http.ResponseWriter, r *http.Request) {
	slot := strings.TrimPrefix(r.URL.Path, "/sitepic/")
	fallback, known := sitePictureSlots[slot]
	if !known {
		http.NotFound(w, r)
		return
	}
	var path string
	if db.QueryRow("SELECT path FROM site_pictures WHERE slot = ?", slot).Scan(&path) != nil {
		http.Redirect(w, r, fallback, http.StatusFound)
		return
	}
	p := filepath.Join(sitePicturesDir, filepath.Base(path))
	switch strings.ToLower(filepath.Ext(p)) {
	case ".jpg", ".jpeg", ".png", ".gif", ".webp":
	default:
		http.NotFound(w, r)
		return
	}
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "public, max-age=31536000, immutable")
	http.ServeFile(w, r, p)
}

// sitePictureUpload: multipart POST slot=<slot> with an "image", or remove=1
// to go back to the original picture. Admins only. Answers {"url": "..."}.
func sitePictureUpload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxPictureBytes+(64<<10))
	if err := r.ParseMultipartForm(1 << 20); err != nil {
		http.Error(w, fmt.Sprintf("That picture is too big. Pick one under %d MB.", maxPictureMB), http.StatusRequestEntityTooLarge)
		return
	}
	defer r.MultipartForm.RemoveAll()
	slot := r.FormValue("slot")
	if _, known := sitePictureSlots[slot]; !known {
		http.Error(w, "Unknown picture.", http.StatusBadRequest)
		return
	}
	var old string
	db.QueryRow("SELECT path FROM site_pictures WHERE slot = ?", slot).Scan(&old)

	if r.FormValue("remove") == "1" {
		db.Exec("DELETE FROM site_pictures WHERE slot = ?", slot)
		if old != "" {
			os.Remove(filepath.Join(sitePicturesDir, filepath.Base(old)))
		}
		writeJSON(w, map[string]string{"url": sitePictureLink(slot)})
		return
	}
	file, _, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "Pick a picture first.", http.StatusBadRequest)
		return
	}
	defer file.Close()
	name, status, msg := saveImageIn(file, sitePicturesDir, slot)
	if status != 0 {
		http.Error(w, msg, status)
		return
	}
	if _, err := db.Exec("INSERT INTO site_pictures (slot, path) VALUES (?, ?) ON CONFLICT(slot) DO UPDATE SET path = excluded.path", slot, name); err != nil {
		fmt.Println(err)
		os.Remove(filepath.Join(sitePicturesDir, name))
		http.Error(w, "Couldn't save the picture.", http.StatusInternalServerError)
		return
	}
	if old != "" && old != name {
		os.Remove(filepath.Join(sitePicturesDir, filepath.Base(old)))
	}
	writeJSON(w, map[string]string{"url": sitePictureLink(slot)})
}

// ---- Letter icon: comments on your Forum posts ----

// notifications: GET answers {unread, items} with the newest 30 comments
// other people left on the account's posts (unread = newer than the last
// time the letter was opened); POST {action:"seen"} marks them all read.
func notifications(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	me := session.UserId
	var seen int64
	db.QueryRow("SELECT notesSeenAt FROM users WHERE id = ?", me).Scan(&seen)

	switch r.Method {
	case http.MethodGet:
		type note struct {
			ID       int64      `json:"id"`
			Post     int64      `json:"post"`
			PostText string     `json:"postText"`
			From     postAuthor `json:"from"`
			Body     string     `json:"body"`
			At       int64      `json:"at"`
			Unread   bool       `json:"unread"`
		}
		out := struct {
			Unread int    `json:"unread"`
			Items  []note `json:"items"`
		}{Items: []note{}}
		db.QueryRow(`SELECT COUNT(*) FROM forum_comments c JOIN forum_posts p ON p.id = c.post_id
			WHERE p.user_id = ? AND c.user_id != ? AND c.created_at > ?`, me, me, seen).Scan(&out.Unread)
		if r.URL.Query().Get("count") == "1" {
			writeJSON(w, out)
			return
		}
		rows, err := db.Query(`
		SELECT c.id, c.post_id, p.body, c.body, c.created_at, u.originalUsername, u.pathToProfilePic, u.authority
		FROM forum_comments c
		JOIN forum_posts p ON p.id = c.post_id
		JOIN users u ON u.id = c.user_id
		WHERE p.user_id = ? AND c.user_id != ?
		ORDER BY c.id DESC
		LIMIT 30`, me, me)
		if err != nil {
			fmt.Println(err)
			http.Error(w, "Couldn't load your messages.", http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		for rows.Next() {
			var n note
			var name, avatar, authority string
			if rows.Scan(&n.ID, &n.Post, &n.PostText, &n.Body, &n.At, &name, &avatar, &authority) != nil {
				continue
			}
			if runes := []rune(n.PostText); len(runes) > 80 {
				n.PostText = string(runes[:80]) + "…"
			}
			n.From = person(name, avatar, authority)
			n.Unread = n.At > seen
			out.Items = append(out.Items, n)
		}
		writeJSON(w, out)

	case http.MethodPost:
		var in struct {
			Action string `json:"action"`
		}
		json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<10)).Decode(&in)
		if in.Action != "seen" {
			http.Error(w, "Unknown action.", http.StatusBadRequest)
			return
		}
		db.Exec("UPDATE users SET notesSeenAt = ? WHERE id = ?", time.Now().UnixMilli(), me)
		writeJSON(w, map[string]int{"unread": 0})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// ---- Site backgrounds ----

// siteScenes are the backgrounds an account can pick for every page.
var siteScenes = map[string]bool{"": true, "none": true, "aurora": true, "stars": true, "grid": true, "pills": true, "waves": true, "custom": true}

// ---- Geek rank ----

// geekRank: every Graph session and every Forum post an account ever made is a point.
// The five tiers make a round of rankRound points. Reaching Geek⁴ earns a level,
// and when the round is full the tiers start over from Fresh Geek, so the level
// keeps counting up (Geek⁴ once = level 1, twice = level 2, ...). Every round
// needs rankHarder (10%) more points than the one before, tiers included.
type geekRank struct {
	Tier      int    `json:"tier"`
	Name      string `json:"name"`
	Level     int    `json:"level"`     // times Geek⁴ was reached
	Round     int    `json:"round"`     // which round the account is in, from 1
	RoundSize int    `json:"roundSize"` // points this round takes
	Score     int    `json:"score"`
	Graphs    int    `json:"graphs"`
	Posts     int    `json:"posts"`
	Next      string `json:"next"`     // what comes next: a tier name or "a new round"
	ToNext    int    `json:"toNext"`   // points still needed for it
	Progress  int    `json:"progress"` // percent of the way from this tier to the next
}

const rankRound = 150
const rankHarder = 1.10

// rankScale is how much bigger round r (0 = the first) is than the first.
func rankScale(r int) float64 { return math.Pow(rankHarder, float64(r)) }

func scaled(points int, r int) int { return int(math.Round(float64(points) * rankScale(r))) }

var geekTiers = []struct {
	Name string
	From int
}{{"Fresh Geek", 0}, {"Geek", 5}, {"Big Geek", 20}, {"Mega Geek", 50}, {"Geek⁴", 120}}

func makeRank(graphs, posts int) geekRank {
	g := geekRank{Graphs: graphs, Posts: posts, Score: graphs + posts}
	rounds, in := 0, g.Score
	for in >= scaled(rankRound, rounds) {
		in -= scaled(rankRound, rounds)
		rounds++
	}
	g.Level = rounds
	g.Round = rounds + 1
	g.RoundSize = scaled(rankRound, rounds)
	for i, t := range geekTiers {
		if in >= scaled(t.From, rounds) {
			g.Tier, g.Name = i+1, t.Name
		}
	}
	if g.Tier == len(geekTiers) {
		g.Level++
	}
	from := scaled(geekTiers[g.Tier-1].From, rounds)
	to := g.RoundSize
	g.Next = "a new round"
	if g.Tier < len(geekTiers) {
		to = scaled(geekTiers[g.Tier].From, rounds)
		g.Next = geekTiers[g.Tier].Name
	}
	g.ToNext = to - in
	g.Progress = (in - from) * 100 / (to - from)
	return g
}

var ranksMu sync.Mutex
var ranks = map[string]geekRank{} // lower-case name -> rank
var ranksAt time.Time

func staleRanks() {
	ranksMu.Lock()
	ranksAt = time.Time{}
	ranksMu.Unlock()
}

// allRanks recounts everyone at most every 30 seconds (or right after a new post or session).
func allRanks() map[string]geekRank {
	ranksMu.Lock()
	defer ranksMu.Unlock()
	if time.Since(ranksAt) < 30*time.Second {
		return ranks
	}
	m := map[string]geekRank{}
	rows, err := db.Query("SELECT username, graphsMade, postsMade FROM users")
	if err != nil {
		fmt.Println(err)
		return ranks
	}
	for rows.Next() {
		var name string
		var graphs, posts int
		if rows.Scan(&name, &graphs, &posts) == nil {
			m[strings.ToLower(name)] = makeRank(graphs, posts)
		}
	}
	rows.Close()
	ranks, ranksAt = m, time.Now()
	return ranks
}

func rankOf(name string) geekRank {
	if g, ok := allRanks()[strings.ToLower(name)]; ok {
		return g
	}
	return makeRank(0, 0)
}

// ---- Page views ----

var statsSchema = `
CREATE TABLE IF NOT EXISTS page_views (
	day TEXT NOT NULL,
	page TEXT NOT NULL,
	views INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY(day, page)
);
CREATE TABLE IF NOT EXISTS page_visitors (
	day TEXT NOT NULL,
	visitor TEXT NOT NULL,
	PRIMARY KEY(day, visitor)
);
`

// viewedPage names the page a browser opened, or "" for scripts, files and pictures.
func viewedPage(r *http.Request) string {
	if r.Method != http.MethodGet {
		return ""
	}
	if dest := r.Header.Get("Sec-Fetch-Dest"); dest != "" && dest != "document" {
		return ""
	}
	p := r.URL.Path
	switch {
	case p == "/" || p == "/Main" || p == "/journal" || p == "/journal/Drug" || p == "/Profile" || p == "/Forum" || p == "/admin" || p == "/Uploader" || p == "/Replications":
		return p
	case strings.HasPrefix(p, "/u/"):
		return "/u/"
	case strings.HasPrefix(p, "/Files/") && strings.HasSuffix(p, "/"):
		return "/Files/"
	}
	return ""
}

// countViews adds one view per page opened, and remembers each visitor once a day:
// an account by its id, everyone else by a hash of their address and browser.
func countViews(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if page := viewedPage(r); page != "" {
			day := time.Now().Format("2006-01-02")
			visitor := ""
			if s, ok := sessionFromRequest(r); ok && s.UserId != 0 {
				visitor = "u" + strconv.Itoa(s.UserId)
				db.Exec("UPDATE users SET lastSeen = ? WHERE id = ?", time.Now().UnixMilli(), s.UserId)
			} else {
				sum := sha256.Sum256([]byte(clientIP(r) + "|" + r.UserAgent()))
				visitor = "a" + hex.EncodeToString(sum[:8])
			}
			db.Exec(`INSERT INTO page_views (day, page, views) VALUES (?, ?, 1)
				ON CONFLICT(day, page) DO UPDATE SET views = views + 1`, day, page)
			db.Exec("INSERT OR IGNORE INTO page_visitors (day, visitor) VALUES (?, ?)", day, visitor)
		}
		next.ServeHTTP(w, r)
	})
}

// adminStats: views per day (last 30 days), the most opened pages, site totals
// and every account with its numbers and geek rank.
func adminStats(w http.ResponseWriter, r *http.Request) {
	type dayRow struct {
		Day      string `json:"day"`
		Views    int    `json:"views"`
		Visitors int    `json:"visitors"`
	}
	now := time.Now()
	days := make([]dayRow, 30)
	index := map[string]int{}
	for i := range days {
		d := now.AddDate(0, 0, i-29).Format("2006-01-02")
		days[i].Day = d
		index[d] = i
	}
	first := days[0].Day
	if rows, err := db.Query("SELECT day, SUM(views) FROM page_views WHERE day >= ? GROUP BY day", first); err == nil {
		for rows.Next() {
			var d string
			var n int
			if rows.Scan(&d, &n) == nil {
				if i, ok := index[d]; ok {
					days[i].Views = n
				}
			}
		}
		rows.Close()
	}
	if rows, err := db.Query("SELECT day, COUNT(*) FROM page_visitors WHERE day >= ? GROUP BY day", first); err == nil {
		for rows.Next() {
			var d string
			var n int
			if rows.Scan(&d, &n) == nil {
				if i, ok := index[d]; ok {
					days[i].Visitors = n
				}
			}
		}
		rows.Close()
	}
	type pageRow struct {
		Page  string `json:"page"`
		Views int    `json:"views"`
	}
	pages := []pageRow{}
	if rows, err := db.Query("SELECT page, SUM(views) AS n FROM page_views WHERE day >= ? GROUP BY page ORDER BY n DESC", first); err == nil {
		for rows.Next() {
			var p pageRow
			if rows.Scan(&p.Page, &p.Views) == nil {
				pages = append(pages, p)
			}
		}
		rows.Close()
	}
	type userRow struct {
		ID       int      `json:"id"`
		Name     string   `json:"name"`
		Admin    bool     `json:"admin"`
		Avatar   string   `json:"avatar"`
		Joined   int64    `json:"joined"`
		LastSeen int64    `json:"lastSeen"`
		Graphs   int      `json:"graphs"`
		Posts    int      `json:"posts"`
		Comments int      `json:"comments"`
		Doses    int      `json:"doses"`
		Likes    int      `json:"likes"`
		Friends  int      `json:"friends"`
		Rank     geekRank `json:"rank"`
	}
	users := []userRow{}
	rows, err := db.Query(`SELECT u.id, u.originalUsername, u.authority, u.pathToProfilePic, u.createdAt, u.lastSeen,
		u.graphsMade, u.postsMade,
		(SELECT COUNT(*) FROM forum_comments c WHERE c.user_id = u.id),
		(SELECT COUNT(*) FROM doses d WHERE d.user_id = u.id),
		(SELECT COUNT(*) FROM liked_substances l WHERE l.user_id = u.id),
		(SELECT COUNT(*) FROM friendships f WHERE f.status = 'accepted' AND (f.requester_id = u.id OR f.addressee_id = u.id)),
		(SELECT MAX(created_at) FROM sessions s WHERE s.user_id = u.id)
		FROM users u ORDER BY lower(u.originalUsername) LIMIT 2000`)
	if err != nil {
		fmt.Println(err)
		http.Error(w, "Couldn't load the accounts.", http.StatusInternalServerError)
		return
	}
	for rows.Next() {
		var u userRow
		var authority, avatar string
		var login sql.NullString
		if err := rows.Scan(&u.ID, &u.Name, &authority, &avatar, &u.Joined, &u.LastSeen, &u.Graphs, &u.Posts, &u.Comments, &u.Doses, &u.Likes, &u.Friends, &login); err != nil {
			fmt.Println(err)
			continue
		}
		u.Admin = authority == "admin"
		u.Avatar = existingPicture(avatar)
		if u.LastSeen == 0 && login.Valid {
			// Accounts from before lastSeen existed: their latest sign in.
			for _, layout := range []string{"2006-01-02 15:04:05.999999999-07:00", "2006-01-02 15:04:05-07:00", time.RFC3339Nano, "2006-01-02 15:04:05"} {
				if t, err := time.Parse(layout, login.String); err == nil {
					u.LastSeen = t.UnixMilli()
					break
				}
			}
		}
		u.Rank = makeRank(u.Graphs, u.Posts)
		users = append(users, u)
	}
	rows.Close()
	var totals struct {
		Accounts int `json:"accounts"`
		Graphs   int `json:"graphs"`
		Posts    int `json:"posts"`
		Comments int `json:"comments"`
	}
	totals.Accounts = len(users)
	for _, u := range users {
		totals.Graphs += u.Graphs
		totals.Posts += u.Posts
		totals.Comments += u.Comments
	}
	tiers := []map[string]any{}
	for i, t := range geekTiers {
		tiers = append(tiers, map[string]any{"tier": i + 1, "name": t.Name, "from": t.From})
	}
	writeJSON(w, map[string]any{"days": days, "pages": pages, "users": users, "totals": totals, "tiers": tiers, "round": rankRound})
}

// clearAlpha: the card opacities for a widget transparency, worked out here so
// the page doesn't need calc() inside rgba(), which some phone browsers skip.
type clearAlpha struct{ Card, Inner string }

func makeClearAlpha(clear int) clearAlpha {
	c := float64(min(max(clear, 0), 100)) / 100
	return clearAlpha{Card: strconv.FormatFloat(1-c, 'f', 2, 64), Inner: strconv.FormatFloat(1-c*0.85, 'f', 3, 64)}
}

// ---------------- Replications: a backup of PsychonautWiki's effect pictures ----------------

// An admin presses "Back up" on /Replications and this server (it's the one with internet)
// walks the wiki's effect pages through the MediaWiki API, then downloads every replication
// picture plus a small preview into replications/ (gitignored), with index.json keeping the
// effect, caption and artist credit of each. Pressing it again only fetches what's new, and
// pictures that later vanish from the wiki stay here. PW_API changes the API address (tests).

const replicationsDir = "replications"
const replAgent = "Geek4uBackup/1.0 (personal backup of effect replications)"
const replThumbWidth = 480
const replMaxBytes = 250 << 20

type replication struct {
	Name     string   `json:"name"`            // the wiki's file name, without "File:"
	File     string   `json:"file"`            // in replications/files/
	Thumb    string   `json:"thumb,omitempty"` // in replications/thumbs/ ('' = the file is small enough)
	Width    int      `json:"width"`
	Height   int      `json:"height"`
	Bytes    int64    `json:"bytes"`
	Mime     string   `json:"mime"`
	Effects  []string `json:"effects"`
	Kinds    []string `json:"kinds,omitempty"` // e.g. Visual, from the effect pages' categories
	Caption  string   `json:"caption,omitempty"`
	About    string   `json:"about,omitempty"` // the file page's own description
	Artist   string   `json:"artist,omitempty"`
	License  string   `json:"license,omitempty"`
	Source   string   `json:"source"` // the file's page on the wiki
	Uploaded string   `json:"uploaded,omitempty"`
}

type replIndex struct {
	Updated int64         `json:"updated"`
	Items   []replication `json:"items"`
	Removed []string      `json:"removed,omitempty"` // removed by an admin, so updates skip them
}

type replStatus struct {
	Running  bool   `json:"running"`
	Phase    string `json:"phase"`
	Done     int    `json:"done"`
	Total    int    `json:"total"`
	New      int    `json:"new"`
	Failed   int    `json:"failed"`
	Bytes    int64  `json:"bytes"`
	Started  int64  `json:"started,omitempty"`
	Finished int64  `json:"finished,omitempty"`
	Error    string `json:"error,omitempty"`
}

var (
	replMu    sync.Mutex // guards replState and replStop
	replState replStatus
	replStop  bool

	replIdxMu   sync.Mutex // guards replIdx
	replIdx     *replIndex
	errReplStop = errors.New("stopped")
)

var replAPIClient = &http.Client{Timeout: 90 * time.Second}

// Pictures can be big, so there's no overall time limit, only for the wiki to start answering.
var replFileClient = &http.Client{Transport: &http.Transport{
	Proxy:                 http.ProxyFromEnvironment,
	ResponseHeaderTimeout: 60 * time.Second,
	IdleConnTimeout:       90 * time.Second,
}}

func replAPI() string {
	if v := os.Getenv("PW_API"); v != "" {
		return v
	}
	return "https://psychonautwiki.org/w/api.php"
}

func replSetState(change func(s *replStatus)) {
	replMu.Lock()
	change(&replState)
	replMu.Unlock()
}

func replStopped() bool {
	replMu.Lock()
	defer replMu.Unlock()
	return replStop
}

// replLoaded returns the index, reading index.json the first time. Call with replIdxMu held.
func replLoaded() *replIndex {
	if replIdx == nil {
		replIdx = &replIndex{}
		if b, err := os.ReadFile(filepath.Join(replicationsDir, "index.json")); err == nil {
			json.Unmarshal(b, replIdx)
		}
	}
	return replIdx
}

// replSave writes index.json through a temporary file so a crash can't leave half of it. Call with replIdxMu held.
func replSave() error {
	idx := replLoaded()
	idx.Updated = time.Now().UnixMilli()
	b, err := json.MarshalIndent(idx, "", " ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(replicationsDir, 0755); err != nil {
		return err
	}
	tmp := filepath.Join(replicationsDir, "index.json.tmp")
	if err := os.WriteFile(tmp, b, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, filepath.Join(replicationsDir, "index.json"))
}

// ---- MediaWiki API ----

type wikiPage struct {
	Title    string `json:"title"`
	Ns       int    `json:"ns"`
	Missing  any    `json:"missing,omitempty"`
	Revision []struct {
		Content string `json:"content"`
		Star    string `json:"*"`
		Slots   struct {
			Main struct {
				Content string `json:"content"`
				Star    string `json:"*"`
			} `json:"main"`
		} `json:"slots"`
	} `json:"revisions"`
	Images []struct {
		Title string `json:"title"`
	} `json:"images"`
	Links []struct {
		Title string `json:"title"`
	} `json:"links"`
	ImageInfo []struct {
		URL         string `json:"url"`
		ThumbURL    string `json:"thumburl"`
		Size        int64  `json:"size"`
		Width       int    `json:"width"`
		Height      int    `json:"height"`
		Mime        string `json:"mime"`
		DescURL     string `json:"descriptionurl"`
		Timestamp   string `json:"timestamp"`
		User        string `json:"user"`
		ExtMetadata map[string]struct {
			Value any `json:"value"`
		} `json:"extmetadata"`
	} `json:"imageinfo"`
}

func (p wikiPage) text() string {
	for _, r := range p.Revision {
		for _, s := range []string{r.Slots.Main.Content, r.Slots.Main.Star, r.Content, r.Star} {
			if s != "" {
				return s
			}
		}
	}
	return ""
}

type wikiAnswer struct {
	Continue map[string]any `json:"continue"`
	Error    *struct {
		Code string `json:"code"`
		Info string `json:"info"`
	} `json:"error"`
	Query struct {
		Normalized []struct {
			From string `json:"from"`
			To   string `json:"to"`
		} `json:"normalized"`
		Redirects []struct {
			From string `json:"from"`
			To   string `json:"to"`
		} `json:"redirects"`
		Pages           json.RawMessage `json:"pages"`
		CategoryMembers []struct {
			Title string `json:"title"`
			Ns    int    `json:"ns"`
		} `json:"categorymembers"`
	} `json:"query"`
}

// pages reads query.pages, which is a list in formatversion 2 and an object in older wikis.
func (a wikiAnswer) pages() []wikiPage {
	var list []wikiPage
	if json.Unmarshal(a.Query.Pages, &list) == nil {
		return list
	}
	var byID map[string]wikiPage
	json.Unmarshal(a.Query.Pages, &byID)
	for _, p := range byID {
		list = append(list, p)
	}
	return list
}

// replAsk makes one API call, waiting and retrying when the wiki is busy, then pauses a moment to stay polite.
func replAsk(params url.Values) (wikiAnswer, error) {
	params.Set("action", "query")
	params.Set("format", "json")
	params.Set("formatversion", "2")
	params.Set("maxlag", "5")
	var answer wikiAnswer
	var last error
	for try := 0; try < 5; try++ {
		if try > 0 {
			time.Sleep(time.Duration(2<<try) * time.Second)
		}
		if replStopped() {
			return answer, errReplStop
		}
		req, _ := http.NewRequest(http.MethodGet, replAPI()+"?"+params.Encode(), nil)
		req.Header.Set("User-Agent", replAgent)
		res, err := replAPIClient.Do(req)
		if err != nil {
			var ue *url.Error
			if errors.As(err, &ue) {
				err = ue.Err
			}
			last = fmt.Errorf("couldn't reach PsychonautWiki (%v)", err)
			if try >= 2 {
				break // no internet or the address is wrong; retrying longer won't help
			}
			continue
		}
		body, err := io.ReadAll(io.LimitReader(res.Body, 64<<20))
		res.Body.Close()
		if err != nil {
			last = err
			continue
		}
		if res.StatusCode != http.StatusOK {
			last = fmt.Errorf("the wiki answered %s", res.Status)
			if res.StatusCode == http.StatusTooManyRequests || res.StatusCode >= 500 {
				continue
			}
			return answer, last
		}
		answer = wikiAnswer{}
		if err := json.Unmarshal(body, &answer); err != nil {
			last = fmt.Errorf("the wiki sent something that isn't JSON")
			continue
		}
		if answer.Error != nil {
			last = fmt.Errorf("the wiki said: %s", answer.Error.Info)
			if answer.Error.Code == "maxlag" {
				continue
			}
			return answer, last
		}
		time.Sleep(300 * time.Millisecond)
		return answer, nil
	}
	return answer, last
}

// replEach follows the API's "continue" until every part of the answer has arrived.
func replEach(params url.Values, each func(wikiAnswer)) error {
	base := url.Values{}
	for k, v := range params {
		base[k] = v
	}
	cont := map[string]any{}
	for {
		q := url.Values{}
		for k, v := range base {
			q[k] = v
		}
		for k, v := range cont {
			q.Set(k, fmt.Sprint(v))
		}
		answer, err := replAsk(q)
		if err != nil {
			return err
		}
		each(answer)
		if len(answer.Continue) == 0 {
			return nil
		}
		cont = answer.Continue
	}
}

// ---- reading the wiki text ----

func replFileKey(title string) string {
	t := strings.TrimSpace(strings.ReplaceAll(title, "_", " "))
	if i := strings.Index(t, ":"); i >= 0 {
		switch strings.ToLower(strings.TrimSpace(t[:i])) {
		case "file", "image":
			t = strings.TrimSpace(t[i+1:])
		}
	}
	t = strings.Join(strings.Fields(t), " ")
	if t == "" {
		return ""
	}
	r, n := utf8.DecodeRuneInString(t)
	return string(unicode.ToUpper(r)) + t[n:]
}

var (
	reWikiTemplate = regexp.MustCompile(`\{\{[^{}]*\}\}`)
	reWikiRef      = regexp.MustCompile(`(?is)<ref[^>]*/>|<ref[^>]*>.*?</ref>`)
	reWikiLink     = regexp.MustCompile(`\[\[(?:[^\]|]*\|)?([^\]|]*)\]\]`)
	reWikiExtLink  = regexp.MustCompile(`\[(?:https?:)?//[^\s\]]+\s+([^\]]*)\]`)
	reTags         = regexp.MustCompile(`<[^>]*>`)
	reGallery      = regexp.MustCompile(`(?is)<gallery[^>]*>(.*?)</gallery>`)
	reSpace        = regexp.MustCompile(`\s+`)
	reUnderscores  = regexp.MustCompile(`_+`)
)

// replPlain turns a bit of wiki text or HTML into plain text.
func replPlain(s string, limit int) string {
	// Simple templates like {{Sub|DMT}} keep their last part; bigger ones go.
	for i := 0; i < 3; i++ {
		s = reWikiTemplate.ReplaceAllStringFunc(s, func(t string) string {
			parts := strings.Split(strings.Trim(t, "{}"), "|")
			last := strings.TrimSpace(parts[len(parts)-1])
			if len(parts) < 2 || len(parts) > 3 || strings.Contains(last, "=") || utf8.RuneCountInString(last) > 40 {
				return ""
			}
			return last
		})
	}
	s = reWikiRef.ReplaceAllString(s, "")
	s = reWikiLink.ReplaceAllString(s, "$1")
	s = reWikiExtLink.ReplaceAllString(s, "$1")
	s = reTags.ReplaceAllString(s, " ")
	s = strings.NewReplacer("'''", "", "''", "", "&nbsp;", " ").Replace(s)
	s = html.UnescapeString(s)
	s = strings.TrimSpace(reSpace.ReplaceAllString(s, " "))
	s = strings.Trim(s, "|")
	if limit > 0 && utf8.RuneCountInString(s) > limit {
		s = string([]rune(s)[:limit]) + "…"
	}
	return s
}

// splitWikiArgs splits "a|[[b|c]]|d" on the bars that aren't inside a link or template.
func splitWikiArgs(s string) []string {
	var out []string
	depth, start := 0, 0
	for i := 0; i < len(s); i++ {
		switch {
		case strings.HasPrefix(s[i:], "[[") || strings.HasPrefix(s[i:], "{{"):
			depth++
			i++
		case (strings.HasPrefix(s[i:], "]]") || strings.HasPrefix(s[i:], "}}")) && depth > 0:
			depth--
			i++
		case s[i] == '|' && depth == 0:
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	return append(out, s[start:])
}

// pictureCaption picks the caption out of a picture's options, skipping things like "thumb" or "300px".
func pictureCaption(args []string) string {
	caption := ""
	for _, a := range args {
		t := strings.TrimSpace(a)
		l := strings.ToLower(t)
		if t == "" || strings.HasSuffix(l, "px") || strings.Contains(l, "=") && !strings.Contains(l, "[[") && len(strings.SplitN(l, "=", 2)[0]) < 12 {
			continue
		}
		switch l {
		case "thumb", "thumbnail", "frame", "framed", "frameless", "border", "left", "right", "center", "centre", "none", "upright", "baseline", "middle", "top", "bottom":
			continue
		}
		caption = t
	}
	return replPlain(caption, 400)
}

type wikiPicture struct {
	Caption string
	Gallery bool
}

// picturesInText finds the pictures a page shows: <gallery> lines and [[File:...]] links.
func picturesInText(text string) map[string]wikiPicture {
	found := map[string]wikiPicture{}
	add := func(name, caption string, gallery bool) {
		key := replFileKey(name)
		if key == "" || strings.ContainsAny(key, "{}[]<>") {
			return
		}
		old, seen := found[key]
		if !seen || (gallery && !old.Gallery) || old.Caption == "" {
			found[key] = wikiPicture{caption, gallery || old.Gallery}
		}
	}
	for _, m := range reGallery.FindAllStringSubmatch(text, -1) {
		for _, line := range strings.Split(m[1], "\n") {
			line = strings.TrimSpace(line)
			if line == "" {
				continue
			}
			parts := splitWikiArgs(line)
			add(parts[0], pictureCaption(parts[1:]), true)
		}
	}
	text = reGallery.ReplaceAllString(text, "")
	for i := 0; ; {
		j := strings.Index(text[i:], "[[")
		if j < 0 {
			break
		}
		start := i + j + 2
		depth, end := 1, -1
		for k := start; k < len(text)-1; k++ {
			if text[k] == '[' && text[k+1] == '[' {
				depth++
				k++
			} else if text[k] == ']' && text[k+1] == ']' {
				depth--
				k++
				if depth == 0 {
					end = k - 1
					break
				}
			}
		}
		if end < 0 {
			break
		}
		inner := text[start:end]
		i = end + 2
		parts := splitWikiArgs(inner)
		head := strings.ToLower(strings.TrimSpace(parts[0]))
		if strings.HasPrefix(head, "file:") || strings.HasPrefix(head, "image:") {
			add(parts[0], pictureCaption(parts[1:]), false)
		}
	}
	return found
}

// ---- the backup run ----

type replFound struct {
	effects        map[string]bool
	caption        string
	galleryCaption bool // the caption came from a gallery, so a later one doesn't replace it
	gallery        bool
	inCat          bool
}

func startReplicationsBackup() bool {
	replMu.Lock()
	defer replMu.Unlock()
	if replState.Running {
		return false
	}
	replStop = false
	replState = replStatus{Running: true, Phase: "Finding the effect pages", Started: time.Now().UnixMilli()}
	go func() {
		err := backupReplications()
		replMu.Lock()
		replState.Running = false
		replState.Finished = time.Now().UnixMilli()
		switch {
		case err == errReplStop:
			replState.Phase = "Stopped"
		case err != nil:
			replState.Phase = "Didn't finish"
			replState.Error = err.Error()
		default:
			replState.Phase = "Done"
		}
		replMu.Unlock()
		if err != nil {
			fmt.Println("Replications backup:", err)
		}
	}()
	return true
}

func backupReplications() error {
	for _, dir := range []string{"files", "thumbs"} {
		if err := os.MkdirAll(filepath.Join(replicationsDir, dir), 0755); err != nil {
			return err
		}
	}

	// 1. Effect pages: everything under the effect and replication categories (two levels down).
	pages := map[string]map[string]bool{} // page -> the categories it was listed in
	found := map[string]*replFound{}
	seeds := []string{"Category:Effect", "Category:Effects", "Category:Replication", "Category:Replications"}
	seed := map[string]bool{}
	for _, s := range seeds {
		seed[s] = true
	}
	type catAt struct {
		title string
		depth int
	}
	queue := []catAt{}
	for _, s := range seeds {
		queue = append(queue, catAt{s, 0})
	}
	seenCat := map[string]bool{}
	for len(queue) > 0 && len(seenCat) < 120 {
		c := queue[0]
		queue = queue[1:]
		if seenCat[c.title] {
			continue
		}
		seenCat[c.title] = true
		err := replEach(url.Values{"list": {"categorymembers"}, "cmtitle": {c.title}, "cmtype": {"page|subcat|file"}, "cmlimit": {"max"}}, func(a wikiAnswer) {
			for _, m := range a.Query.CategoryMembers {
				switch m.Ns {
				case 0:
					if pages[m.Title] == nil {
						pages[m.Title] = map[string]bool{}
					}
					if !seed[c.title] {
						pages[m.Title][strings.TrimPrefix(c.title, "Category:")] = true
					}
				case 14:
					if c.depth < 2 {
						queue = append(queue, catAt{m.Title, c.depth + 1})
					}
				case 6:
					key := replFileKey(m.Title)
					if found[key] == nil {
						found[key] = &replFound{effects: map[string]bool{}}
					}
					found[key].inCat = true
				}
			}
		})
		if err == errReplStop {
			return err
		}
		if err != nil && len(seenCat) == 1 {
			return err // the very first question failed, so the wiki can't be reached
		}
		if err != nil && c.depth == 0 {
			fmt.Println("Replications:", c.title, err)
		}
		replSetState(func(s *replStatus) { s.Phase = fmt.Sprintf("Finding the effect pages (%d so far)", len(pages)) })
	}
	// Few pages in categories (the wiki may be set up differently): use the effect index's links too.
	if len(pages) < 40 {
		replEach(url.Values{"prop": {"links"}, "titles": {"Subjective effect index|Effect index"}, "redirects": {"1"}, "plnamespace": {"0"}, "pllimit": {"max"}}, func(a wikiAnswer) {
			for _, p := range a.pages() {
				for _, l := range p.Links {
					if pages[l.Title] == nil {
						pages[l.Title] = map[string]bool{}
					}
				}
			}
		})
	}
	if replStopped() {
		return errReplStop
	}
	if len(pages) == 0 && len(found) == 0 {
		return errors.New("couldn't find any effect pages on the wiki")
	}

	// 2. Read each page: the pictures in its galleries and text, and every picture it shows.
	titles := make([]string, 0, len(pages))
	for t := range pages {
		titles = append(titles, t)
	}
	sort.Strings(titles)
	usedOn := map[string]int{} // how many pages show a picture; logos and icons are on lots of them
	kindsOf := map[string]map[string]bool{}
	for i := 0; i < len(titles); i += 20 {
		batch := titles[i:min(i+20, len(titles))]
		replSetState(func(s *replStatus) {
			s.Phase = fmt.Sprintf("Reading effect pages (%d of %d)", i, len(titles))
		})
		seenHere := map[string]map[string]bool{}
		err := replEach(url.Values{"prop": {"revisions|images"}, "titles": {strings.Join(batch, "|")}, "rvprop": {"content"}, "rvslots": {"main"}, "imlimit": {"max"}}, func(a wikiAnswer) {
			for _, p := range a.pages() {
				if p.Missing != nil && p.Missing != false {
					continue
				}
				if seenHere[p.Title] == nil {
					seenHere[p.Title] = map[string]bool{}
				}
				for name, pic := range picturesInText(p.text()) {
					f := found[name]
					if f == nil {
						f = &replFound{effects: map[string]bool{}}
						found[name] = f
					}
					f.effects[p.Title] = true
					f.gallery = f.gallery || pic.Gallery
					if pic.Caption != "" && (f.caption == "" || pic.Gallery && !f.galleryCaption) {
						f.caption = pic.Caption
						f.galleryCaption = pic.Gallery
					}
					seenHere[p.Title][name] = true
				}
				for _, im := range p.Images {
					name := replFileKey(im.Title)
					if found[name] == nil {
						found[name] = &replFound{effects: map[string]bool{}}
					}
					found[name].effects[p.Title] = true
					seenHere[p.Title][name] = true
				}
			}
		})
		if err != nil {
			return err
		}
		for page, names := range seenHere {
			for name := range names {
				usedOn[name]++
				if len(pages[page]) > 0 {
					if kindsOf[name] == nil {
						kindsOf[name] = map[string]bool{}
					}
					for k := range pages[page] {
						kindsOf[name][k] = true
					}
				}
			}
		}
	}

	// Keep pictures from galleries and the replication categories, plus pictures shown on just a few pages.
	keep := []string{}
	for name, f := range found {
		if f.gallery || f.inCat || usedOn[name] <= 3 {
			keep = append(keep, name)
		}
	}
	sort.Strings(keep)

	// 3. Look up each picture: its address, size, artist and license.
	type infoRow struct {
		replication
		url, thumb string
	}
	infos := map[string]infoRow{}
	for i := 0; i < len(keep); i += 50 {
		batch := keep[i:min(i+50, len(keep))]
		replSetState(func(s *replStatus) { s.Phase = fmt.Sprintf("Looking up pictures (%d of %d)", i, len(keep)) })
		names := make([]string, len(batch))
		for j, n := range batch {
			names[j] = "File:" + n
		}
		err := replEach(url.Values{"prop": {"imageinfo"}, "titles": {strings.Join(names, "|")}, "iiprop": {"url|size|mime|extmetadata|timestamp|user"}, "iiurlwidth": {strconv.Itoa(replThumbWidth)}, "iiextmetadatafilter": {"ImageDescription|Artist|LicenseShortName|Credit"}}, func(a wikiAnswer) {
			for _, p := range a.pages() {
				if len(p.ImageInfo) == 0 {
					continue
				}
				ii := p.ImageInfo[0]
				meta := func(k string) string {
					if v, ok := ii.ExtMetadata[k]; ok {
						return fmt.Sprint(v.Value)
					}
					return ""
				}
				row := infoRow{url: ii.URL, thumb: ii.ThumbURL}
				row.Name = replFileKey(p.Title)
				row.Width, row.Height, row.Bytes, row.Mime = ii.Width, ii.Height, ii.Size, ii.Mime
				row.Source = ii.DescURL
				row.Uploaded = ii.Timestamp
				row.About = replPlain(meta("ImageDescription"), 600)
				row.Artist = replPlain(meta("Artist"), 120)
				if row.Artist == "" {
					row.Artist = ii.User
				}
				row.License = replPlain(meta("LicenseShortName"), 60)
				infos[row.Name] = row
			}
		})
		if err != nil {
			return err
		}
	}

	// 4. Download what's new.
	replIdxMu.Lock()
	idx := replLoaded()
	have := map[string]replication{}
	for _, it := range idx.Items {
		have[it.Name] = it
	}
	removed := map[string]bool{}
	for _, n := range idx.Removed {
		removed[n] = true
	}
	replIdxMu.Unlock()

	todo := []infoRow{}
	for _, name := range keep {
		row, ok := infos[name]
		if !ok || removed[name] || row.url == "" {
			continue
		}
		ext := strings.ToLower(filepath.Ext(name))
		if !replExtOK(ext) || !strings.HasPrefix(row.Mime, "image/") && !strings.HasPrefix(row.Mime, "video/") {
			continue
		}
		f := found[name]
		big := min(row.Width, row.Height) >= 150
		if !(f.gallery || f.inCat) && !big {
			continue // small pictures outside galleries are icons
		}
		row.Effects = sortedKeys(f.effects)
		row.Kinds = sortedKeys(kindsOf[name])
		row.Caption = f.caption
		todo = append(todo, row)
	}
	replSetState(func(s *replStatus) {
		s.Phase = "Downloading pictures"
		s.Total = len(todo)
	})

	base, _ := url.Parse(replAPI())
	sinceSave := 0
	for _, row := range todo {
		if replStopped() {
			break
		}
		it := row.replication
		old, had := have[it.Name]
		it.File = replSafeName(it.Name)
		filePath := filepath.Join(replicationsDir, "files", it.File)
		fresh := false
		// Download it when it's new, its file is gone, or the wiki has a newer upload of it.
		if st, err := os.Stat(filePath); err == nil && had && st.Size() > 0 && (it.Uploaded == "" || old.Uploaded == "" || it.Uploaded == old.Uploaded) {
			it.Bytes = st.Size()
		} else {
			if it.Bytes > replMaxBytes {
				replSetState(func(s *replStatus) { s.Done++; s.Failed++ })
				continue
			}
			n, err := replDownload(replResolve(base, row.url), filePath)
			if err == errReplStop {
				break
			}
			if err != nil {
				fmt.Println("Replications:", it.Name, err)
				replSetState(func(s *replStatus) { s.Done++; s.Failed++ })
				continue
			}
			it.Bytes = n
			fresh = true
			replSetState(func(s *replStatus) { s.Bytes += n; s.New++ })
		}
		// A preview for the grid, when the picture is bigger than one.
		it.Thumb = old.Thumb
		if row.thumb != "" && row.thumb != row.url && it.Width > replThumbWidth {
			thumbName := strings.TrimSuffix(it.File, filepath.Ext(it.File)) + replThumbExt(row.thumb)
			thumbPath := filepath.Join(replicationsDir, "thumbs", thumbName)
			if _, err := os.Stat(thumbPath); err != nil || fresh {
				if n, err := replDownload(replResolve(base, row.thumb), thumbPath); err == nil {
					it.Thumb = thumbName
					replSetState(func(s *replStatus) { s.Bytes += n })
				}
			} else {
				it.Thumb = thumbName
			}
		}
		replIdxMu.Lock()
		idx := replLoaded()
		placed := false
		for i := range idx.Items {
			if idx.Items[i].Name == it.Name {
				idx.Items[i] = it
				placed = true
				break
			}
		}
		if !placed {
			idx.Items = append(idx.Items, it)
		}
		sinceSave++
		if sinceSave >= 20 {
			replSave()
			sinceSave = 0
		}
		replIdxMu.Unlock()
		replSetState(func(s *replStatus) { s.Done++ })
	}
	replIdxMu.Lock()
	err := replSave()
	replIdxMu.Unlock()
	if replStopped() {
		return errReplStop
	}
	return err
}

func sortedKeys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func replExtOK(ext string) bool {
	switch ext {
	case ".jpg", ".jpeg", ".png", ".gif", ".webp", ".webm", ".mp4":
		return true
	}
	return false
}

func replThumbExt(link string) string {
	if u, err := url.Parse(link); err == nil {
		if ext := strings.ToLower(filepath.Ext(u.Path)); replExtOK(ext) {
			return ext
		}
	}
	return ".jpg"
}

func replResolve(base *url.URL, link string) string {
	u, err := url.Parse(link)
	if err != nil || base == nil {
		return link
	}
	return base.ResolveReference(u).String()
}

// replSafeName makes a file name that's fine on Windows: plain letters, plus a short hash so
// two names that differ only in case or symbols don't land on the same file.
func replSafeName(name string) string {
	ext := strings.ToLower(filepath.Ext(name))
	var b strings.Builder
	for _, r := range strings.TrimSuffix(name, filepath.Ext(name)) {
		switch {
		case r < 128 && (unicode.IsLetter(r) || unicode.IsDigit(r) || r == '-'):
			b.WriteRune(r)
		default:
			b.WriteByte('_')
		}
		if b.Len() >= 100 {
			break
		}
	}
	s := strings.Trim(reUnderscores.ReplaceAllString(b.String(), "_"), "_")
	if s == "" {
		s = "picture"
	}
	sum := sha256.Sum256([]byte(name))
	return s + "-" + hex.EncodeToString(sum[:3]) + ext
}

// replDownload saves a link to a file, through a .part file so a broken download never looks finished.
func replDownload(link, dest string) (int64, error) {
	var last error
	for try := 0; try < 3; try++ {
		if replStopped() {
			return 0, errReplStop
		}
		if try > 0 {
			time.Sleep(time.Duration(3*try) * time.Second)
		}
		req, err := http.NewRequest(http.MethodGet, link, nil)
		if err != nil {
			return 0, err
		}
		req.Header.Set("User-Agent", replAgent)
		res, err := replFileClient.Do(req)
		if err != nil {
			last = err
			continue
		}
		if res.StatusCode != http.StatusOK {
			res.Body.Close()
			last = fmt.Errorf("the wiki answered %s", res.Status)
			if res.StatusCode == http.StatusNotFound {
				return 0, last
			}
			continue
		}
		part := dest + ".part"
		out, err := os.Create(part)
		if err != nil {
			res.Body.Close()
			return 0, err
		}
		n, err := io.Copy(out, io.LimitReader(res.Body, replMaxBytes+1))
		res.Body.Close()
		if cerr := out.Close(); err == nil {
			err = cerr
		}
		if err == nil && n > replMaxBytes {
			err = errors.New("too big")
		}
		if err != nil {
			os.Remove(part)
			last = err
			continue
		}
		if err := os.Rename(part, dest); err != nil {
			os.Remove(part)
			return 0, err
		}
		time.Sleep(150 * time.Millisecond)
		return n, nil
	}
	return 0, last
}

// ---- pages and endpoints ----

func Replications(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	t, err := template.ParseFiles("html/replications.html")
	if err != nil {
		http.Error(w, "Couldnt load page", http.StatusBadRequest)
		return
	}
	w.Header().Set("Cache-Control", "no-cache")
	if err := t.Execute(w, struct{ Admin bool }{session.Authority == "admin"}); err != nil {
		fmt.Println(err)
	}
}

// replicationsList: GET every backed-up picture (gzipped, it can be a long list); admins also get the backup's progress.
func replicationsList(w http.ResponseWriter, r *http.Request) {
	session, _ := sessionFromRequest(r)
	out := struct {
		Updated int64         `json:"updated"`
		Items   []replication `json:"items"`
		Bytes   int64         `json:"bytes"`
		Admin   bool          `json:"admin"`
		Status  *replStatus   `json:"status,omitempty"`
	}{Admin: session.Authority == "admin"}
	replIdxMu.Lock()
	idx := replLoaded()
	out.Updated = idx.Updated
	out.Items = append([]replication{}, idx.Items...)
	replIdxMu.Unlock()
	for _, it := range out.Items {
		out.Bytes += it.Bytes
	}
	if out.Admin {
		replMu.Lock()
		st := replState
		replMu.Unlock()
		out.Status = &st
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	if strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
		w.Header().Set("Content-Encoding", "gzip")
		w.Header().Set("Vary", "Accept-Encoding")
		gz := gzip.NewWriter(w)
		defer gz.Close()
		json.NewEncoder(gz).Encode(out)
		return
	}
	json.NewEncoder(w).Encode(out)
}

// replicationsFile serves /replications/files/<name> and /replications/thumbs/<name>.
func replicationsFile(w http.ResponseWriter, r *http.Request) {
	rest := strings.TrimPrefix(r.URL.Path, "/replications/")
	dir, name, ok := strings.Cut(rest, "/")
	if !ok || (dir != "files" && dir != "thumbs") || name == "" || name != filepath.Base(name) || strings.HasPrefix(name, ".") || !replExtOK(strings.ToLower(filepath.Ext(name))) {
		http.NotFound(w, r)
		return
	}
	p := filepath.Join(replicationsDir, dir, name)
	if info, err := os.Stat(p); err != nil || info.IsDir() {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, max-age=604800")
	http.ServeFile(w, r, p)
}

// replicationsBackup (admins): GET the progress; POST {action: "start" | "stop" | "remove", name}.
func replicationsBackup(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		var in struct {
			Action string `json:"action"`
			Name   string `json:"name"`
		}
		if json.NewDecoder(io.LimitReader(r.Body, 4096)).Decode(&in) != nil {
			http.Error(w, "Bad request.", http.StatusBadRequest)
			return
		}
		switch in.Action {
		case "start":
			startReplicationsBackup()
		case "stop":
			replMu.Lock()
			if replState.Running {
				replStop = true
				replState.Phase = "Stopping…"
			}
			replMu.Unlock()
		case "remove":
			replIdxMu.Lock()
			idx := replLoaded()
			kept := idx.Items[:0]
			var gone *replication
			for i := range idx.Items {
				if idx.Items[i].Name == in.Name && gone == nil {
					it := idx.Items[i]
					gone = &it
					continue
				}
				kept = append(kept, idx.Items[i])
			}
			idx.Items = kept
			if gone != nil {
				idx.Removed = append(idx.Removed, gone.Name)
				os.Remove(filepath.Join(replicationsDir, "files", filepath.Base(gone.File)))
				if gone.Thumb != "" {
					os.Remove(filepath.Join(replicationsDir, "thumbs", filepath.Base(gone.Thumb)))
				}
			}
			err := replSave()
			replIdxMu.Unlock()
			if gone == nil {
				http.Error(w, "That picture isn't in the backup.", http.StatusNotFound)
				return
			}
			if err != nil {
				http.Error(w, "Couldn't save the list.", http.StatusInternalServerError)
				return
			}
		default:
			http.Error(w, "Bad request.", http.StatusBadRequest)
			return
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	replMu.Lock()
	st := replState
	replMu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(st)
}
